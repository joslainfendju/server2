# -*- coding: utf-8 -*-
{
    'name': "its_hr_payroll_attendance_summary",

    'summary': """
        Introduce the payroll variable in the employee's pay slip""",

    'description': """
        
    """,

    'author': "ITS,Mylene",
    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Test',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base',
                'its_hr_payroll_extend',
                'its_hr_attendance_summary',
                'its_hr_entity_attendance',
                ],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/hr_payslip_views.xml',
        'views/res_config_settings.xml',
        'views/hr_payslip_run_view.xml'

    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
