from odoo import fields,models,api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    include_payroll_variable = fields.Boolean(string="Include payroll variable")

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update({
            'include_payroll_variable': self.env['ir.config_parameter'].sudo().get_param('include_payroll_variable')
        })
        return res

    def set_values(self):
        res = super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('include_payroll_variable', self.include_payroll_variable)
        return res