# from my_addons_cames.its_hr_payroll_extend.models.hr_payslip import Payroll
from datetime import datetime,timedelta

from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError, Warning
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT


class Payroll(models.Model):
    _inherit = 'hr.payslip'

    employee_attendance_summary_id = fields.Many2one('hr.employee.attendance.summary',
                                                     string='Employee Attendance Summary',
                                                     domain="[('employee_id','=',employee_id),('state','=','confirmed')]",
                                                     )
    date_from = fields.Date(required=True, related='employee_attendance_summary_id.start_date')
    date_to = fields.Date(required=True, related='employee_attendance_summary_id.end_date')

    @api.model
    def create(self, vals):
        res = super().create(vals)
        return res

    @api.multi
    @api.depends('employee_id', 'month_hours', 'salary_type', 'date_from', 'date_to', 'employee_attendance_summary_id')
    def _get_prorata(self):
        include_payroll_variable = self.env['ir.config_parameter'].sudo().get_param('include_payroll_variable')
        if include_payroll_variable:
            self.prorata = self.employee_attendance_summary_id.taux_presence
        else:
            self.prorata = super(Payroll, self)._get_prorata()

    @api.onchange('employee_id')
    def _get_employee_change(self):

        return {
            'value': {'employee_attendance_summary_id': False}
        }

    @api.onchange('employee_attendance_summary_id')
    def _get_attendance_change(self):

        return {
            'value': {'date_from': False, 'date_to': False}
        }

    @api.onchange('employee_attendance_summary_id')
    def _get_period_change(self):
        if self.employee_attendance_summary_id:
            self.date_from = self.employee_attendance_summary_id.start_date
            self.date_to = self.employee_attendance_summary_id.end_date

    #TODO you can override to inclut overtimes according to the parameter set
    @api.model
    def get_worked_day_lines(self, contracts, date_from, date_to):
        """
        Override method. Recompute worked days by adding public holidays and weekends.
        """
        include_payroll_variable = self.env['ir.config_parameter'].sudo().get_param('include_payroll_variable')
        res = super(Payroll, self).get_worked_day_lines(contracts=contracts,date_from=date_from,date_to=date_to)
        if include_payroll_variable:
            for contract in contracts.filtered(lambda contract: contract.resource_calendar_id):

                d = self._get_hours_days(self.employee_attendance_summary_id)
                attendances = {
                    'name': _("Normal Working Days paid at 100%"),
                    'sequence': 1,
                    'code': 'WORK100',
                    'number_of_days': d['number_of_days'],
                    'number_of_hours': d['month_hours'],
                    'contract_id': contract.id,
                }
                res[0] = attendances
        return res


    def get_quota_hours_of_calendar(self):
        """
        Get quota hours of dayofweek of the calendar employee.
        @return dict
        """
        dayofweek_wiht_quota_hours = {'0':0,'1':0,'2':0,'3':0,'4':0,'5':0,'6':0}
        for c in self.employee_id.resource_calendar_id.attendance_ids:
            dayofweek_wiht_quota_hours[c.dayofweek] += c.hour_to - c.hour_from
        return dayofweek_wiht_quota_hours

    def _get_hours_days(self,employee_attendance_summary_obj):
        """
        Compute total month hours and number of days.
        """
        calendar_hours = self.get_quota_hours_of_calendar()
        total_hours = 0
        for att in employee_attendance_summary_obj.line_ids:
            w_date = fields.Date.from_string(att.date)
            dateofweek = self.findDay(w_date)
            if calendar_hours[dateofweek] < att.worked_hours: total_hours += calendar_hours[dateofweek]
            elif att.arrival_time and att.departure_time: total_hours += att.worked_hours

        #TODO set parameter to define the standart hours of one days like weekends or public holidays , then replace 8.
        total_hours += employee_attendance_summary_obj.total_public_holidays_days * 8
        number_of_days = employee_attendance_summary_obj.total_presence_days + employee_attendance_summary_obj.total_public_holidays_days
        return {'number_of_days':number_of_days,'month_hours':total_hours}

    @api.multi
    @api.depends('employee_attendance_summary_id')
    def _get_month_hours(self):
        for p in self:
            if not p.date_from and not p.date_to: continue
            res = self._get_hours_days(p.employee_attendance_summary_id)
            p.month_hours = res['month_hours']

    @api.multi
    def action_payslip_done(self):
        # self.ensure_one()
        # if self.prorata == 0.0:
        #     raise ValidationError(_("Cannot confirm payslip that prorata temporis is null"))
        # self.compute_sheet()
        precision = self.env['decimal.precision'].precision_get('Payroll')
        move_env = self.env['account.move']
        for slip in self:
            if slip.employee_attendance_summary_id.taux_presence == 0.0:
                raise ValidationError(_("Cannot confirm payslip that prorata temporis is null"))
            debit_sum = 0.0
            credit_sum = 0.0
            date = slip.date or slip.date_to

            name = _('Payslip of %s - %s') % (slip.employee_id.name, date)
            move_dict = {
                'narration': name,
                'ref': slip.number,
                'journal_id': slip.journal_id.id,
                'date': date,
            }

            line_ids = slip.generate_employee_move(precision, date)
            move_dict['line_ids'] = line_ids
            move = move_env.create(move_dict)
            slip.write({'move_id': move.id, 'date': date})
            move.post()

            social_line_ids, tax_line_ids = slip.generate_employer_move(precision, date)

            name = _('Payslip of %s - %s : Company Social Charges') % (slip.employee_id.name, date)
            move_dict.update({'name': name, 'line_ids': social_line_ids})
            move = move_env.create(move_dict)
            slip.write({'move_employer_social_id': move.id, 'date': date})
            move.post()

            name = _('Payslip of %s - %s : Company Tax Charges') % (slip.employee_id.name, date)
            move_dict.update({'name': name, 'line_ids': tax_line_ids})
            move = move_env.create(move_dict)
            slip.write({'move_employer_id': move.id, 'date': date})
            move.post()
            slip.write({'state': 'done'})
        return
        # return super(Payroll, self).action_payslip_done()