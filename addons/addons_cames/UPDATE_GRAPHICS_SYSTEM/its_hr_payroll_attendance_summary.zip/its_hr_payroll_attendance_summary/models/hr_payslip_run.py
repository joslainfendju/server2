from odoo import fields, api, models,_
from odoo.exceptions import UserError


class HrPayslipRun(models.Model):
    _inherit = 'hr.payslip.run'

    entity_attendance_summary_id = fields.Many2one('hr.entity.attendance.summary',
                                                   string='Entity Attendance Summary',
                                                   domain="[('entity_id','=',entity_id), ('state','=','confirmed')]", )
    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')

    state = fields.Selection([
        ('draft', 'Draft'),
        ('generate', 'Payslips Generated'),
        ('done', 'Done'),
        ('close', 'Close'),
        ('cancel', 'Rejected'),
    ], string='Status', index=True, readonly=True, copy=False, default='draft',
        help="""* When the payslip lot is created the status is \'Draft\'
                \n* If the payslip lot is under Payslips Generated, the status is \'generate\'.
                \n* If the payslip lot is Done then status is set to \'done\'.
                \n* When user cancel payslip the status is \'Rejected\'.""")


    @api.multi
    def generate_emp_payslip(self):
        """
        Generate employees payslip according to the entity_attendance_summary_id.
        """
        for r in self:
            payslips = self.env['hr.payslip']
            if not r.entity_attendance_summary_id:
                raise UserError(_('You cannot generate employees payslip if entity summary is doesn''t set.'))
            for summary in r.entity_attendance_summary_id.line_ids:
                slip_data = self.env['hr.payslip'].onchange_employee_id(summary.start_date, summary.end_date, summary.employee_id.id, contract_id=False)
                res = {
                    'employee_id': summary.employee_id.id,
                    'name': slip_data['value'].get('name'),
                    'struct_id': slip_data['value'].get('struct_id'),
                    'contract_id': slip_data['value'].get('contract_id'),
                    'payslip_run_id': r.id,
                    'employee_attendance_summary_id':summary.id,
                    'input_line_ids': [(0, 0, x) for x in slip_data['value'].get('input_line_ids')],
                    'worked_days_line_ids': [(0, 0, x) for x in slip_data['value'].get('worked_days_line_ids')],
                    'date_from': summary.start_date,
                    'date_to': summary.end_date,
                    # 'credit_note': run_data.get('credit_note'),
                    'company_id': slip_data['value'].get('company_id'),
                }
                payslips += self.env['hr.payslip'].create(res)
            payslips.compute_sheet()
            if r.entity_attendance_summary_id.line_ids : r.state = 'generate'
        return

    @api.multi
    def confirmed_payslip_lot(self):
        """
        Compute payslip generated.
        """
        self.slip_ids.action_payslip_done()
        self.state = 'done'
        return



    @api.onchange('entity_id')
    def _get_entity_change(self):
        return {
            'value': {'entity_attendance_summary_id': False}
        }

    @api.onchange('entity_attendance_summary_id')
    def _get_attendance_change(self):
        return {
            'value': {'date_start': False, 'date_end': False}
        }

    @api.onchange('entity_attendance_summary_id')
    def _get_period_change(self):
        if not self.entity_attendance_summary_id:
            # self.slip_ids = False
            self.date_start = False
            self.date_end = False
            return
        # if self.entity_attendance_summary_id:
        self.date_start = self.entity_attendance_summary_id.start_date
        self.date_end = self.entity_attendance_summary_id.end_date
        # if self.slip_ids:  # unlink all
        #     self.slip_ids.unlink()
        # line = []
        # for summary in self.entity_attendance_summary_id.line_ids:
        #     line.append((0, 0, {'employee_id': summary.employee_id.id,
        #                         'date_from': self.entity_attendance_summary_id.start_date,
        #                         'date_to': self.entity_attendance_summary_id.end_date,
        #                         'employee_attendance_summary_id': summary.id,
        #                         'entity_id': self.entity_attendance_summary_id.entity_id.id,
        #                         'name': self.entity_attendance_summary_id.name,
        #                         'journal_id': self.journal_id,
        #                         }))
        # if line:
        #     self.slip_ids = line

    # @api.one
    # @api.depends('entity_attendance_summary_id')
    # def _build_hr_payslip(self):
    #     """
    #     Set employees payslip.
    #     @param entity_attendance_summary_id: integer. Id of hr.entity.attendance.summary
    #     @return list. List of tuple
    #     """
    #     line = []
    #     for summary in self.entity_attendance_summary_id.line_ids:
    #         line.append((0, 0, {'employee_id': summary.employee_id,
    #                             'date_from': self.entity_attendance_summary_id.start_date,
    #                             'date_to': self.entity_attendance_summary_id.end_date,
    #                             'employee_attendance_summary_id': summary,
    #                             'entity_id': self.entity_attendance_summary_id.entity_id,
    #                             # 'name': self.entity_attendance_summary_id.name,
    #                             'journal_id': self.journal_id,
    #                             }))
    #     if line:
    #         self.slip_ids = line

    # def _get_slips(self, payslip_run_id, entity_attendance_summary_id):
    #     """
    #     Set employees payslip.
    #     @param entity_attendance_summary_id: integer. Id of hr.entity.attendance.summary
    #     @return list. List of tuple
    #     """
    #
    #     slip_obj = self.env['hr.payslip']
    #     entity_summary = self.env['hr.entity.attendance.summary'].browse([entity_attendance_summary_id])
    #     for summary in entity_summary.line_ids:
    #         slip = {'employee_id': summary.employee_id.id,
    #                 'date_from': summary.start_date,
    #                 'date_to': summary.end_date,
    #                 'employee_attendance_summary_id': summary.id,
    #                 'entity_id': entity_summary.entity_id.id,
    #                 'payslip_run_id': payslip_run_id,
    #                 # 'name': entity_summary.name,
    #                 # 'number': self.slip_ids.number,
    #                 # 'credit_note': self.credit_note,
    #                 'prorata': summary.taux_presence,
    #                 # 'journal_id': self.journal_id,
    #                 }
    #         slip_obj.create(slip)
    #
    #     return
