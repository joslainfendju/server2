# -*- coding: utf-8 -*-
{
    'name': "Hr Entity",

    'summary': """
       Manage customer and their datas""",

    'description': """
        Manage customer and their datas:
        - Define an entity for a customer
        - Add entity on all objects in HR Management
        - Define rights
    """,

    'author': "IT Services, Cedric FOWOUE",
    'website': "http://www.its-nh.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Human Resources',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': [
        'base',
        'its_hr_employee',
        'its_hr_job_transfer',
        'its_hr_email_handle',
        'its_hr_skill_extend',
    ],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/hr_entity_view.xml',
        'views/hr_employee_view.xml',
        'views/hr_job_view.xml',
        'views/hr_department_view.xml',
        'views/transfer_wizard_view.xml',
        'views/org_chart_entity_view.xml',
        'views/transfer_report_wizard.xml',
        'views/hr_document_template_view.xml',
        'views/document_wizard_view.xml',
        'views/hr_employee_category_view.xml',
        'views/res_config_view.xml',
        'views/menu.xml',

        # report
        'report/transfer_of_employees_report.xml',
        'report/report_menu.xml',

        # data
        'data/mail_doc_expired.xml',
        'data/mail_format_for_doc_expired.xml',
    ],
    'qweb': [
    ],
    # only loaded in demonstration mode
    'demo': [
    ]
}
