from odoo import fields, models, api, SUPERUSER_ID


class EmailHandle(models.Model):
    _inherit = 'hr.email.handle'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')
    work_email = fields.Char(related='entity_id.work_email')

    @api.model
    def create(self, vals):
        # alias = self.env['mail.alias'].sudo().search([('alias_user_id', '=', SUPERUSER_ID)], limit=1)
        # vals['alias_model_id'] = alias.alias_model_id.id
        return super(EmailHandle, self).create(vals)

    @api.multi
    def write(self, vals):
        # alias = self.env['mail.alias'].sudo().search([('alias_user_id', '=', SUPERUSER_ID)], limit=1)
        # vals['alias_model_id'] = alias.alias_model_id.id
        return super(EmailHandle, self).write(vals)
