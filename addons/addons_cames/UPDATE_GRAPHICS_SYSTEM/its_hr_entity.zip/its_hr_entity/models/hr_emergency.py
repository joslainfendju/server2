from odoo import fields, models, api


class HrEmployeeContractName(models.Model):

    _inherit = 'hr.emergency.contact'

    entity_id = fields.Many2one(comodel_name='hr.entity', related='employee_id.entity_id')
