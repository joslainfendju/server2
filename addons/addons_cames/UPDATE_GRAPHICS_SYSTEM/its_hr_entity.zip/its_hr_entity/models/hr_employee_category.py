# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrEmployeeCategory(models.Model):
    _inherit = 'hr.employee.category'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')
