from odoo import fields, models, api


class HrEmployeeLoan (models.Model):
    _inherit = 'employee.loan.details'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity', store=True)

    @api.onchange('entity_id')
    def onchange_employee(self):
        if self.entity_id:
            return {'domain': {'employee_id': [('entity_id', '=', self.entity_id.id)]}}

    # @api.multi
    # def action_applied(self):
    #     for loan in self:
    #         self.onchange_loan_type(loan.loan_type.id, loan.employee_id.id)
    #         msg = ''
    #         if loan.principal_amount <= 0.0:
    #             msg += 'Principal Amount\n '
    #         # if loan.int_payable and loan.int_rate <= 0.0:
    #         #     msg += 'Interest Rate\n '
    #         if loan.duration <= 0.0:
    #             msg += 'Duration of Loan'
    #         if msg:
    #             raise Warning(_('Please Enter values greater then zero:\n %s ') % (msg))
    #         status = self.check_employee_loan_qualification(loan)
    #         if not isinstance(status, bool):
    #             raise Warning(_('Loan Policies not satisfied :\n %s ') % (_(status)))
    #         seq_no = self.env['ir.sequence'].get('employee.loan.details')
    #         #             self.write({'state':'applied', 'name':seq_no})
    #         # loan.state = 'auth_manager'
    #         loan.state = 'auth_financial_manager'
    #         loan.name = seq_no
    #     return True
    #
    # @api.multi
    # def action_authorized(self):
    #     # date_approved = time.strftime(DEFAULT_SERVER_DATE_FORMAT)
    #     # date_approved_obj = datetime.strptime(date_approved, DEFAULT_SERVER_DATE_FORMAT)
    #     for loan in self:
    #         vals = {}
    #         # if not loan.date_approved:
    #         #     vals.update(
    #         #         date_approved=date_approved,
    #         #         state='approved')
    #         # else:
    #         #     vals.update(state='approved')
    #         vals.update(state='approved')
    #
    #         self.write(vals)
    #     return True
    


