from odoo import fields, models, api


class HrJobTransfer (models.Model):
    _inherit = 'hr.job.transfer'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity', related='employee_id.entity_id')
    


