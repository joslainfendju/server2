from odoo import fields, models, api


class ResConfigSettings (models.TransientModel):
    _inherit = 'res.config.settings'

    doc_alert_delay = fields.Integer(
        string="Alert delay Before document expired",
        help="Define number of days to alert before document expired",
        default=1
    )

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('hr_entity.doc_alert_delay',
                                                         self.doc_alert_delay)
        # self.env['ir.config_parameter'].sudo().set_param('hr_recruitment_extend.recruitment_frequency',
        #                                                  self.recruitment_frequency)

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(
            doc_alert_delay=int(self.env['ir.config_parameter'].sudo().get_param('hr_entity.doc_alert_delay'))
        )
        return res
    


