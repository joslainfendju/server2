from odoo import fields, models, api, tools, _
import base64
import os


class HrEntity (models.Model):
    _name = 'hr.entity'
    _description = 'To manage different customer data in hr module'
    # _inherit = ['mail.thread', 'resource.mixin']

    # _mail_post_access = 'read'

    name = fields.Char()
    responsible_id = fields.Many2one(comodel_name='res.users', string='Responsible')
    company_id = fields.Many2one(
        comodel_name='res.company',
        string='Company',
        default=lambda s: s.env.user.company_id.id)
    partner_id = fields.Many2one(comodel_name='res.partner', string='Partner', domain=[('customer', '=', True)])
    image = fields.Binary(related='partner_id.image', string="Company Logo")
    employee_code = fields.Char(string='ID Code')
    employee_padding = fields.Integer(string="ID Length")
    employee_next = fields.Integer(string="ID Next", default=1)
    work_email = fields.Char()
    start_work = fields.Float()
    end_work = fields.Float()
    convention_id = fields.Many2one(comodel_name='hr.convention', string='Convention')

    @api.model
    def create(self, vals):
        res = super(HrEntity, self).create(vals)
        hr_email_handle_model = self.env['ir.model'].search([('model', '=', 'hr.email.handle')])
        alias = self.env['mail.alias'].create({
            'alias_name': res.name.replace(" ", "").lower(),
            'alias_model_id': hr_email_handle_model.id,
            'alias_defaults': {},
            'alias_user_id': False,
            'alias_contact': 'everyone'
        })
        self.env['hr.email.handle'].create({
            'name': res.name,
            'entity_id': res.id,
            'alias_id': alias.id
        })
        return res
