# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrEmployeeChildren(models.Model):
    _name = 'hr.employee.children'
    _inherit = ['hr.employee.children', 'mail.thread', 'resource.mixin']

    _mail_post_access = 'read'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity', related='employee_id.entity_id')
