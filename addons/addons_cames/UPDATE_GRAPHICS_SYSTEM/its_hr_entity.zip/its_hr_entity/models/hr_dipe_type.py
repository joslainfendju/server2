from odoo import fields, models, api


class HrDipeType (models.Model):
    _name = 'hr.dipe.type'

    name = fields.Char(string='Name', required=True)
    # type = fields.Selection([
    #     ('Dipe_mensuel', 'Dipe mensuel'), ('Dipe_end', 'Dipe fin de carrière'),
    #     ('Dipe_start', 'Dipe début de carrière')
    # ], default="Dipe_mensuel", string='Dipe type', required=True)
    


