from odoo import fields, models, api


class DocumentTemplate(models.Model):
    _inherit = 'hr.document.template'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')
