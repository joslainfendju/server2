# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrDepartment(models.Model):
    _inherit = 'hr.department'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')
