# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')

    def get_domain_compute_template(self, employee):
        res = super(HrEmployee, self).get_domain_compute_template(employee)
        res.append(('entity_id', '=', employee.entity_id.id))
        return res

    def get_staff_id(self,):
        entity = self.entity_id
        if entity:
            code_length = len(str(entity.employee_next))
            code_length = entity.employee_padding - code_length
            code = ("0" * code_length) + str(entity.employee_next)
            year = fields.date.today().year
            self.identification_id = '%s%s' % (entity.employee_code, code)
            entity.employee_next += 1

    @api.model
    def create(self, vals):
        res = super(HrEmployee, self).create(vals)
        res.get_staff_id()
        return res
