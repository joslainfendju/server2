# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrJob(models.Model):
    _inherit = 'hr.job'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')
