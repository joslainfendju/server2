# -*- coding: utf-8 -*-
from odoo import models, fields, api
import base64
import tempfile


class OrgChartEmployee(models.Model):
    _inherit = 'org.chart.employee'

    def _prepare_employee_data(self, employee):
        res = super(OrgChartEmployee, self)._prepare_employee_data(employee)
        res['entity'] = employee.entity_id.name
        return res

    def get_domain(self, args):
        res = super(OrgChartEmployee, self).get_domain(args)
        if 'entity_id' in args:
            res.append(('entity_id', '=', args['entity_id']))
        else:
            employee = self.env['hr.employee'].sudo().search([('user_id', '=', self.env.user.id)], limit=1)
            res.append(('entity_id', '=', employee.entity_id.id))
        return res

    @api.model
    def get_employee_data(self):
        res = super(OrgChartEmployee, self).get_employee_data()
        res['entities'] = self.get_entities()
        return res

    def get_entities(self):
        res = [{'id': x.id, 'name': x.name} for x in self.env['hr.entity'].search([])]
        # res = [{'id': '', 'name': ""}] + res
        return res
