# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrSkill(models.Model):
    _inherit = 'hr.skill'
    # _inherit = ['hr.skill', 'mail.thread', 'resource.mixin']

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')


class EmployeeSkill(models.Model):
    _inherit = 'hr.employee.skill'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity', related='employee_id.entity_id')
