# -*- coding: utf-8 -*-

from . import hr_entity
from . import hr_employee
from . import hr_job
from . import hr_skill
from . import hr_employee_skill
from . import hr_employee_category
from . import hr_employee_children
from . import hr_department
from . import hr_job_transfer
from . import hr_document_template
from . import email_handle
from . import res_config_settings
