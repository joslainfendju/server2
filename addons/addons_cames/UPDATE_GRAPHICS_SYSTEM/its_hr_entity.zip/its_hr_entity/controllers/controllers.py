# -*- coding: utf-8 -*-
from odoo import http

# class HrEntity(http.Controller):
#     @http.route('/hr_entity/hr_entity/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hr_entity/hr_entity/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('hr_entity.listing', {
#             'root': '/hr_entity/hr_entity',
#             'objects': http.request.env['hr_entity.hr_entity'].search([]),
#         })

#     @http.route('/hr_entity/hr_entity/objects/<model("hr_entity.hr_entity"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hr_entity.object', {
#             'object': obj
#         })


