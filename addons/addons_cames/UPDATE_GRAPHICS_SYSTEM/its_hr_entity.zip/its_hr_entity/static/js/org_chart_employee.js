var employee_data = [];
var chart_object;
var emp_form_id;
var parent_id;

odoo.define("org_chart_employee_pro.org_chart_employee", function (require) {
  "use strict";

  var core = require('web.core');
  var session = require('web.session');
  var ajax = require('web.ajax');
  // var AbstractAction = require('web.AbstractAction');
  var Widget = require('web.Widget');
  var ControlPanelMixin = require('web.ControlPanelMixin');
  var Dialog = require('web.Dialog');
  var QWeb = core.qweb;
  var _t = core._t;
  var _lt = core._lt;

  var OrgChartEmployee = Widget.extend(ControlPanelMixin, {
    events: _.extend({}, Widget.prototype.events, {
          'click #btn-reload': 'reload_org_chart',
          'click #btn-export': 'export_org_chart',
          'click .add_node': 'add_noeud',
          'click .edit_node': 'edit_noeud',
          'click .delete_node': 'delete_noeud',
          'click .info_node': 'info_noeud',
          'click .entity': 'entity_filter',
          'drop .node': 'action_drop',
  	}),
    init: function(parent, context) {
      this._super(parent, context);
        var self = this;
        if (context.tag == 'org_chart_employee_pro.org_chart_employee') {
            self._rpc({
                model: 'org.chart.employee',
                method: 'get_employee_data',
            }, []).then(function(result){
                employee_data = result;
            }).done(function(){
                self.render();
                self.href = window.location.href;
            });
            // Get Form_id
            self._rpc({
                model: 'org.chart.employee',
                method: 'get_emp_form_id',
            }, []).then(function(result){
                emp_form_id = result.form_id;
            });
        }
    },
    entity_filter: function (event) {
        let self = this;
        event.stopPropagation();
        event.preventDefault();
        console.log('-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_');

        let idEntity = event.target.value;

        self._rpc({
            model: 'org.chart.employee',
            method: 'get_employee_data',
            args: [{
                'entity_id': parseInt(idEntity),
            }],
        }, [])
        .then(function(result){
            self.employee_data = result;
            self.load_chart();
        })
        .done(function(){
            //
        });
    },
    willStart: function() {
      return $.when(ajax.loadLibs(this), this._super());
    },
    start: function() {
      var self = this;
      return this._super();
    },
    render: function() {
        var super_render = this._super;
        var self = this;
        var org_chart = QWeb.render('org_chart_employee_pro.org_chart_template', {
            widget: self,
        });
        $( ".o_control_panel" ).addClass( "o_hidden" );
        $(org_chart).prependTo(self.$el);
        return org_chart;
    },
    reload: function () {
      window.location.href = this.href;
    },
    reload_org_chart: function(event) {
      $("#chart-container").remove();
      $("#btn-reload").remove();
      $("#btn-export").remove();
      $("#btn-entity").remove();
      $("#key-word").remove();

      var entity = $("#entity").val();
      $("#entity").remove();

      var orien = $("#select").val();
      $("#select").remove();

      var self = this;
      self._rpc({
          model: 'org.chart.employee',
          method: 'get_employee_data',
      }, []).then(function(result){
          employee_data = result;
          employee_data['orientation'] = orien;
          employee_data['entity'] = entity;
      }).done(function(){
          self.render();
          self.href = window.location.href;
      });
    },
    export_org_chart: function (event) {
      var that = chart_object;
      that.export(that.options.exportFilename, that.options.exportFileextension);
    },
    add_noeud: function (event){
      var self = this;
      event.stopPropagation();
      event.preventDefault();
      self.do_action({
          name: _t("Add new Employee"),
          type: 'ir.actions.act_window',
          res_model: 'hr.employee',
          view_mode: 'form',
          view_type: 'form',
          context: {'parent_id': parseInt(event.target.id)},
          views: [[emp_form_id, 'form']],
          target: 'new'
      },{on_reverse_breadcrumb: function(){ return self.reload();}})
    },
    edit_noeud: function (event){
      var self = this;
      event.stopPropagation();
      event.preventDefault();
      self.do_action({
          name: _t("Edit Employee"),
          type: 'ir.actions.act_window',
          res_model: 'hr.employee',
          view_mode: 'form',
          view_type: 'form',
          res_id: parseInt(event.target.id),
          views: [[emp_form_id, 'form']],
          target: 'new'
      },{on_reverse_breadcrumb: function(){ return self.reload();}})
    },
    delete_noeud: function (event){
      var self = this;
      var options = {
        confirm_callback: function () {
          self._rpc({
              model: 'hr.employee',
              method: 'unlink',
              args: [parseInt(event.target.id)],
          }, [])
          .done(function(){
            location.reload();
          });
        }
      };
      Dialog.confirm(this, _t("Do you Want to Delete this Employee ?"), options);
    },
    info_noeud: function (event){
      var self = this;
      var options = {
        confirm_callback: function () {
          self._rpc({
              model: 'hr.employee',
              method: 'get_info_data',
              args: [parseInt(event.target.id)],
          }, [])
          .done(function(){
            location.reload();
          });
        }
      };
      Dialog.confirm(this, _t("Validate to show Job description of employee"), options);
    },
    action_drop: function (event){
      var self = this;
      self._rpc({
          route: "/orgchart/ondrop",
          params: {
              employee_id: parseInt(parent_id),
          },
      })
      .done(function (result) {
          self.do_action(result);
      });
    },
  });

  core.action_registry.add('org_chart_employee_pro.org_chart_employee', OrgChartEmployee);

  return OrgChartEmployee;

});
