from odoo import fields, models, api, tools
from datetime import datetime, timedelta, date


class HrEmployeeWizard (models.TransientModel):
    _name = 'hr.employee.notify.wizard'

    notify_ids = fields.One2many(comodel_name='hr.employee.notify', inverse_name='employee_wizard_id')
    name = fields.Char(string='Name')
    company_id = fields.Many2one(comodel_name='res.company', default=lambda s: s.env.user.company_id.id)

    @api.model
    def mail_for_expired_document(self):
        template = self.env.ref('hr_entity.notification_remind_doc_expired')
        cr = self.env.cr
        delay = int(self.env['ir.config_parameter'].sudo().get_param('hr_entity.doc_alert_delay'))

        val_employee_notify = {}
        employee_notify = self.env['hr.employee.notify']

        val_data_notify = []
        data_notify = self.env['hr.employee.data.notify']
        datas = []
        today = date.today()

        notify = self.env['hr.employee.notify.wizard'].create({
            'name': today
        })

        entities = self.env['hr.entity'].search([])
        for entity in entities:
            employees = self.env['hr.employee'].search([('entity_id', '=', entity.id)])
            for emp in employees:
                val_employee = []
                if emp.passport_expiry_date:
                    expired_date = fields.Date.from_string(emp.passport_expiry_date)
                    if delay >= (expired_date - today).days > 0:
                        val_employee.append((0, 0, {
                            'state': 'to_expire',
                            'type': 'Passport',
                            'date': emp.passport_expiry_date,
                        }))
                    elif (expired_date - today).days < 0:
                        val_employee.append((0, 0, {
                            'state': 'expired',
                            'type': 'Passport',
                            'date': emp.passport_expiry_date,
                        }))

                if emp.expiry_date_ssnid:
                    if delay >= (fields.Date.from_string(emp.expiry_date_ssnid) - today).days > 0:
                        val_employee.append((0, 0, {
                            'state': 'to_expire',
                            'type': 'ID Card',
                            'date': emp.expiry_date_ssnid,
                        }))
                    elif (fields.Date.from_string(emp.expiry_date_ssnid) - today).days < 0:
                        val_employee.append((0, 0, {
                            'state': 'expired',
                            'type': 'ID Card',
                            'date': emp.expiry_date_ssnid,
                        }))

                if emp.visa_expire:
                    if delay >= (fields.Date.from_string(emp.visa_expire) - today).days > 0:
                        val_employee.append((0, 0, {
                            'state': 'to_expire',
                            'type': 'Visa',
                            'date': emp.visa_expire,
                        }))
                    elif (fields.Date.from_string(emp.visa_expire) - today).days < 0:
                        val_employee.append((0, 0, {
                            'state': 'expired',
                            'type': 'Visa',
                            'date': emp.visa_expire,
                        }))

                if len(val_employee):
                    val_notif = {
                        'employee_id': emp.id,
                        'employee_wizard_id': notify.id,
                        'data_ids': val_employee
                    }
                    employee_notify.create(val_notif)

        # for exp in employee_required_notify:
        template.send_mail(notify.id, force_send=True, raise_exception=True)
