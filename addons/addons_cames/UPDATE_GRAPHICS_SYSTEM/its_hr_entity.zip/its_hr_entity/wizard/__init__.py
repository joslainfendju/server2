from . import job_transfer_wizard
from ...its_hr_entity_contract.wizard import hr_reminder_contract_wizard
from . import hr_employee_transfer_wizard
from . import document_wizard
from . import hr_employee_wizard
from . import hr_employee_data_notif
from . import hr_employee_notif
from . import dipe_report_wizard
