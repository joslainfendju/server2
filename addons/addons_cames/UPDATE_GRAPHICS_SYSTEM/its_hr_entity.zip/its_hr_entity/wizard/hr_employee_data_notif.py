from odoo import fields, models, api


class HrEmployeeDataNotif (models.TransientModel):
    _name = 'hr.employee.data.notify'

    # state = fields.Selection([('to_expire', 'expire'), ('get', 'get')], default='expire')
    state = fields.Char('State', size=20)
    type = fields.Char('Document type', size=60)
    date = fields.Datetime(string="Expired date", required=True)
    notify_id = fields.Many2one('hr.employee.notify', string="Employee to notify")
    


