from odoo import fields, models, api
import base64


class HrDocumentWizard (models.TransientModel):
    _inherit = 'hr.document.wizard'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Type of document', related='employee_id.entity_id')


