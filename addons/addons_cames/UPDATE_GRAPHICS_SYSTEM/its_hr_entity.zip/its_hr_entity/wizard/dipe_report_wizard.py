from odoo import fields, models, api, osv
from datetime import datetime
import csv
import io
import os
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT

class HrDipeReportWizard (models.TransientModel):
    _name = 'hr.dipe.report.wizard'

    entity_ids = fields.Many2many(comodel_name='hr.entity', string='Entity')
    date_start = fields.Date(required=True)
    date_end = fields.Date()
    type = fields.Selection(
        string='Dipe Type',
        selection=[('mensual', 'Mensual'), ('start', 'Start'), ('end', 'End')]
    )
    name = fields.Char('Nom fichier', readonly=True)
    # data = fields.Binary('File', readonly=True)

    def get_data(self):
        ent_ids = self.env['hr.entity'].search([('id', 'in', self.entity_ids.ids)])
        return {
            'ids': self.ids,
            'model': self._name,
            'entity_ids': ent_ids and ent_ids.ids or False,
            'type': self.type,
            'date_start': self.date_start,
            'date_end': self.date_end,
        }

    @api.multi
    def print_report(self):
        self.ensure_one()
        data = self.get_data()
        employee_env = self.env['hr.employee']
        payslip_env = self.env['hr.payslip']
        worked_day_env = self.env['hr.payslip.worked_days']

        date_start = datetime.strptime(self.date_start, DEFAULT_SERVER_DATE_FORMAT)
        date_end = datetime.strptime(self.date_end, DEFAULT_SERVER_DATE_FORMAT)

        for entity in self.entity_ids:
            dipe = open("dipe_"+entity.name+".txt", "w+")
            for emp in employee_env.sudo().search([('entity_id', '=', entity.id)]):
                dipe.write('C04')
                dipe.write('     ') #numero Dipe
                dipe.write(' ') #cle numero dipe
                dipe.write(entity.tax_registration_number+'     ' or '              ')
                dipe.write(entity.employer_number+'     ' or '          ')
                dipe.write(entity.cnps_number+'     ' or ' ')
                if emp.insured_number:
                    dipe.write(entity.insured_number+'     ' or '           ')
                worked_days = float(0)
                pay = payslip_env.sudo().search([('employee_id', '=', emp.id), ('date_from', '=', date_start),
                                                 ('date_to', '=', date_end)])

                for p_id in pay:
                    for w in worked_day_env.sudo().search([('payslip_id', '=', p_id)]):
                        worked_days = float(worked_days) + float(w.number_of_hours)

                worked_days = sum([x.number_of_days for x in pay.worked_days_line_ids])

                gross = pay.line_ids.filtered(lambda l: l.salary_rule_id.gross)
                except_salary = pay.line_ids.filtered(lambda l: l.salary_rule_id.exceptional_salary)
                taxable_salary = pay.line_ids.filtered(lambda l: l.salary_rule_id.taxable_salary)
                cnps = pay.line_ids.filtered(lambda l: l.salary_rule_id.contribution)
                capped = pay.line_ids.filtered(lambda l: l.salary_rule_id.capped)
                irpp = pay.line_ids.filtered(lambda l: l.salary_rule_id.irpp)
                tdl = pay.line_ids.filtered(lambda l: l.salary_rule_id.tdl)

                dipe.write(str(gross.amount) or '          ')
                dipe.write(str(except_salary.amount) or '          ')
                dipe.write(str(taxable_salary.amount) or '          ')
                dipe.write(str(cnps.amount) or '          ')
                dipe.write(str(capped.amount) or '          ')
                dipe.write(str(irpp.amount) or '        ')
                dipe.write(str(tdl.amount) or '      ')

                dipe.write(str(worked_days)+'     ' or '  ')

                    # salaire brut à
                    # taxe communal
                if not emp.insured_number:
                    dipe.write(emp.name or '                                                            ')
                dipe.write('\n')
        return data
    

