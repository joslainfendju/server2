from odoo import fields, models, api


class HrEmployeeTransferWizard(models.TransientModel):
    _inherit = 'hr.employee.transfer.wizard'

    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')

    @api.multi
    def print_report(self):
        self.ensure_one()

        data = {
            'ids': self.ids,
            'model': self._name,
            'entity_id': self.entity_id.id if self.entity_id else None
        }

        return self.env.ref('hr_entity.transfer_of_employees_print').report_action(self, data=data)