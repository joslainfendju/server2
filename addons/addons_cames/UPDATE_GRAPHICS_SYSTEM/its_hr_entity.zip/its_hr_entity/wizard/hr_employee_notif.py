from odoo import fields, models, api


class HrEmployeeNotify (models.TransientModel):
    _name = 'hr.employee.notify'

    employee_wizard_id = fields.Many2one('hr.employee.notify.wizard', string="Wizard_employee")
    employee_id = fields.Many2one('hr.employee', string="Employee")
    data_ids = fields.One2many(comodel_name='hr.employee.data.notify', inverse_name="notify_id", string="")
    


