from odoo import fields, models, api


class HrJobTransferWizard (models.TransientModel):
    _inherit = 'hr.job.transfer.wizard'

    # name = fields.Char()
    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity', related='employee_id.entity_id')
