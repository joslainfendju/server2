# -*- coding: utf-8 -*-
from odoo import models, fields, api


class TransferOfEmployees(models.AbstractModel):
    _name = 'report.its_hr_entity.report_transfer_report_view'

    def get_domain(self, args):
        return [('entity_id', '=', args.id)]

    def get_movement_of_employee(self, domain):
        my_data = []
        employees = self.env['hr.employee'].search(domain)
        for emp in employees:
            t_emp = dict()
            t_emp['name'] = emp.name
            t_emp['transfers'] = [{
                'transfer_date': '',
                'job': emp.job_id.name
            }]
            transfers = self.env['hr.job.transfer'].search([('employee_id', '=', emp.id)])
            for transfer in transfers:
                t_transfer = dict(transfer_date=transfer.transfer_date, job=transfer.job_id.name)
                t_emp['transfers'].append(t_transfer)
            my_data.append(t_emp)
        return my_data

    @api.model
    def get_report_values(self, docids, data=None):
        result = []
        if data['entity_id']:
            entity = self.env['hr.entity'].sudo().search([('id', '=', data['entity_id'])])
            result_dict = dict(entity=dict(name=entity.name))
            domain = self.get_domain(entity)
            my_data = self.get_movement_of_employee(domain)
            result_dict.update({'data': my_data})
            result.append(result_dict)
        else:
            entities = self.env['hr.entity'].sudo().search([])
            for entity in entities:
                result_dict = dict(entity=dict(name=entity.name))
                domain = self.get_domain(entity)
                my_data = self.get_movement_of_employee(domain)
                result_dict.update({'data': my_data})
                result.append(result_dict)

        return {
            'doc_ids': data['ids'],
            'doc_model': data['model'],
            'data': result,
        }
