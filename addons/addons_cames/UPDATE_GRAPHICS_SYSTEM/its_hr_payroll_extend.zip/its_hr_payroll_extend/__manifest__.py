# -*- coding: utf-8 -*-
{
    'name': "Payroll Extend",

    'summary': """
        Manage Payroll""",

    'description': """
        This module permit to manage payroll
    """,

    'author': "IT Services, Cedric FOWOUE",
    'website': "http://www.its-nh.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Human Resources',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': [
        'base',
        'hr',
        'its_hr_required_document_reminder',
        'hr_recruitment',
        'hr_employee_seniority',
        'its_hr_employee',
        'hr_payroll',
        'hr_payroll_account',
        'hr_contract',
        'its_hr_contract_extend',
        'its_hr_convention',
        'hr_overtime_request',
        'its_hr_overtime_extend',
        'its_hr_attendance_extend',
        'hr_employee_loan',
        'l10n_syscohada',
    ],

    # always loaded
    'data': [
        'data/contributor_register_data.xml',
        # 'Data Category'
        'data/salary_rule_category_trade_data.xml',
        'data/salary_rule_category_freight_data.xml',
        'data/salary_rule_category_industry_data.xml',
        'data/salary_rule_category_security_comp_data.xml',
        'data/salary_rule_category_agriculture_data.xml',
        'data/salary_rule_category_construction_data.xml',
        'data/salary_rule_category_pharmacy_data.xml',
        'data/salary_rule_category_polygraph_data.xml',

        # 'Data Rule'
        'data/salary_rule_trade_data.xml',
        'data/salary_rule_freight_data.xml',
        'data/salary_rule_industry_data.xml',
        'data/salary_rule_security_comp_data.xml',
        'data/salary_rule_agriculture_data.xml',
        'data/salary_rule_construction_data.xml',
        'data/salary_rule_pharmacy_data.xml',
        'data/salary_rule_polygraph_data.xml',

        # 'security/ir.model.access.csv',
        # 'views/hr_job_grade_view.xml',
        'views/hr_document_template_view.xml',
        'views/hr_contract_form_view.xml',
        'views/hr_employee_view.xml',
        'views/hr_payslip_view.xml',
        'views/hr_salary_rule_categ_view.xml',
        'views/hr_salary_rule_view.xml',
        'views/hr_payroll_structure_view.xml',
        'views/res_config_view.xml',

        # 'Data salary struture'
        'data/salary_struct_237_polygraph_data.xml',

        # wizard

        # report
        'report/report_payslip_templates.xml',
        'report/hr_payroll_report.xml',

        # menu
        'views/menu.xml',

        # reports
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'installable': True,
    'auto_install': False
}
