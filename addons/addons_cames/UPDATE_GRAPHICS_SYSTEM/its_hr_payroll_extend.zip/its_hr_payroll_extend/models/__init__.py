# -*- coding: utf-8 -*-

# from . import hr_job_grade
from . import hr_document_template
from . import hr_contract
from . import hr_payslip
from . import hr_employee_rule
from . import hr_employee
from . import hr_salary_rule
from . import hr_salary_rule_category
from . import hr_payroll_structure
from . import res_config_settings
