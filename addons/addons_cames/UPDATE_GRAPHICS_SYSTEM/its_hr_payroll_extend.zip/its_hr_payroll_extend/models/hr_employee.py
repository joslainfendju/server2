from odoo import fields, models, api, _
import calendar
from dateutil.relativedelta import relativedelta


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    convention_id = fields.Many2one(comodel_name='hr.convention', string="Convention", track_visibility='always')
    rule_ids = fields.One2many(comodel_name='hr.employee.rule', inverse_name='employee_id')
    initial_employment_date = fields.Date(
        string='Initial Date of Employment',
        help='Date of first employment if it was before the start of the '
             'first contract in the system.',
        compute='_compute_init_date',
    )
    bank_id = fields.Many2one(
        comodel_name='account.journal',
        string="Bank",
        domain=[('type', '=', 'bank')],
        track_visibility='always')

    def get_overtime(self, rate, date_from, date_to=None):
        if date_to is None:
            date_to = fields.Datetime.now().strftime('%Y-%m-%d')
        self._cr.execute("SELECT sum(o.number_of_hours) \
            FROM hr_overtime AS o \
            INNER JOIN hr_overtime_type AS t \
                ON t.id=o.overtime_type_id \
            WHERE o.include_payroll IS TRUE \
                AND o.employee_id = %s \
                AND o.state='validate' AND to_char(o.date_to, 'YYYY-MM-DD') >= %s \
                AND to_char(o.date_to, 'YYYY-MM-DD') <= %s \
                AND t.code = '%s' ", (self.id, date_from, date_to, rate))
        res = self._cr.fetchone()
        return res and res[0] or 0.0

    @api.depends('contract_ids')
    def _compute_init_date(self):
        for employee in self:
            first_contract = employee._first_contract()
            employee.initial_employment_date = first_contract.date_start

    def get_rule_value(self, rule, date_from, date_to):
        result = self.env['hr.employee.rule'].search([
            ('employee_id', '=', self.id),
            ('code', '=', rule),
            '|',
            '&',
            ('date_start', '>=', date_from),
            ('date_start', '<=', date_to),
            '&',
            ('date_start', '<=', date_from),
            '|',
            ('date_end', '>=', date_from),
            ('date_end', '=', False)

        ])
        if result:
            return result.value
        else:
            return 0.0

    @api.multi
    def get_average_wage(self, date_from):
        payslips = self.env['hr.payslip'].search([('date_to', '<', date_from)], order="date_to desc", limit=12)
        result = list()
        for payslip in payslips:
            for line in payslip.line_ids.filtered(lambda l: l.salary_rule_id.net):
                result.append(line.amount)
        return sum(result)

    @api.multi
    def get_employee_to_unlink(self):
        to_delete = super(HrEmployee, self).get_employee_to_unlink()
        to_ids = list()
        for emp in to_delete:
            if not emp.slip_ids:
                to_ids.append(emp.id)
        to_delete = self.env['hr.employee'].search([("id", 'in', to_ids)])
        return to_delete

    @api.multi
    def get_seniority(self, date_end):
        hr_contract = self.env['hr.contract'].sudo()
        nb_month = 0
        if self.initial_employment_date:
            first_contract = self._first_contract()
            if first_contract:
                to_dt = fields.Date.from_string(first_contract.date_start)
            else:
                to_dt = fields.Date.from_string(date_end)

            from_dt = fields.Date.from_string(
                self.initial_employment_date)

            nb_month += relativedelta(to_dt, from_dt).years * 12 + \
                        relativedelta(to_dt, from_dt).months + \
                        self.check_next_days(to_dt, from_dt)

        contracts = hr_contract.search([('employee_id', '=', self.id)],
                                       order='date_start asc')
        for contract in contracts:
            from_dt = fields.Date.from_string(contract.date_start)
            if contract.date_end and contract.date_end < date_end:
                to_dt = fields.Date.from_string(contract.date_end)
            else:
                to_dt = fields.Date.from_string(date_end)
            nb_month += relativedelta(to_dt, from_dt).years * 12 + \
                        relativedelta(to_dt, from_dt).months + \
                        self.check_next_days(to_dt, from_dt)

        return nb_month
