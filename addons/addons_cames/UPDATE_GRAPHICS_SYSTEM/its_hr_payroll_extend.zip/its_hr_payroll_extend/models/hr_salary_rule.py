from odoo import fields, models, api


class Payroll(models.Model):
    _inherit = 'hr.salary.rule'

    convention_id = fields.Many2one(comodel_name='hr.convention', string='Convention')
    net = fields.Boolean(string='Net ?')
    accessory = fields.Boolean(string='Accessory ?')
    charge = fields.Boolean(string='Charge salary ?')
    charge_employer = fields.Boolean(string='Charge Employer ?')
    tax = fields.Boolean(string='Tax charge ?')
    social = fields.Boolean(string='Social charge ?')
    retain = fields.Boolean(string='Retain ?')
    contribution = fields.Boolean(string='Salary Contribution ?')
    capped = fields.Boolean(string='Salary Capped ?', help='Salary Contribution Capped')
    tdl = fields.Boolean(string='Tax Development Communal ?')
    gross = fields.Boolean(string='Gross Salary ?')
    irpp = fields.Boolean(string='Personal Income Tax ?')
    exceptional_salary = fields.Boolean(string='Exceptional Salary ?')
    taxable_salary = fields.Boolean(string='Salary Dutiable ?', help='Gross Salary Dutiable')
