from odoo import fields, models, api


class Payroll(models.Model):
    _inherit = 'hr.salary.rule.category'
    
    convention_id = fields.Many2one(comodel_name='hr.convention', string='Convention')
