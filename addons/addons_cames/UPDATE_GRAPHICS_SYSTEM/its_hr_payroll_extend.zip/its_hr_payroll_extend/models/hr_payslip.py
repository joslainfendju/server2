from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError, Warning
from odoo.tools import float_compare, float_is_zero, DEFAULT_SERVER_DATE_FORMAT
import calendar
from datetime import timedelta


class Payroll(models.Model):
    _inherit = 'hr.payslip'

    move_employer_id = fields.Many2one('account.move', 'Accounting Entry Employer', readonly=True, copy=False)
    move_employer_social_id = fields.Many2one('account.move', 'Accounting Entry Employer', readonly=True, copy=False)
    salary_type = fields.Selection(selection=[('normal', 'Normal'), ('holiday', 'Holiday')], default='normal')

    def get_payslip_period_days(self):
        date_from = fields.Date.from_string(self.date_from)
        date_to = fields.Date.from_string(self.date_to)
        total_day = (date_to - date_from).days + 1
        return total_day

    @api.multi
    def get_coefficient_prorata(self):
        for p in self:
            date_from = fields.Date.from_string(p.date_from)
            total_day = p.get_payslip_period_days()
            last_day = calendar.monthrange(date_from.year, date_from.month)[1]
            print('Total day ::', total_day, 'Last day ::', last_day)
            return total_day / last_day

    @api.multi
    def findDay(self, date):
        born = date.weekday()
        return str(born)

    @api.multi
    def find_days(self, work_day_quota, date_start, date_end):
        day_code = work_day_quota.keys()
        work_days = []
        date_start = fields.Date.from_string(date_start)
        date_end = fields.Date.from_string(date_end)
        days = (date_end - date_start).days + 1
        for day in range(days):
            date_ = date_start + timedelta(days=day)
            date_day = date_.strftime(DEFAULT_SERVER_DATE_FORMAT)
            week_day = self.findDay(date_)
            if week_day.lower() in day_code:
                work_days.append(date_day)
        return work_days

    @api.multi
    def _get_month_hours(self):
        for p in self:
            if not p.date_from and not p.date_to: continue
            dayofweek = list(set(p.employee_id.resource_calendar_id.attendance_ids.mapped('dayofweek')))

            work_day_quota = {x: sum([y.hour_to - y.hour_from for y in
                                      p.employee_id.resource_calendar_id.attendance_ids.filtered(lambda att: att.dayofweek == x)])
                              for x in dayofweek}
            work_day_in_period = self.find_days(work_day_quota, p.date_from, p.date_to)
            month_hours = 0.0
            for w in work_day_in_period:
                w_date = fields.Date.from_string(w)
                key = self.findDay(w_date)
                month_hours += work_day_quota[key]
            p.month_hours = month_hours

    @api.multi
    @api.depends('employee_id', 'month_hours', 'salary_type', 'date_from', 'date_to')
    def _get_prorata(self):
        for p in self:
            if p.salary_type == 'normal':
                if not p.date_from and not p.date_to: continue
                absences = p.employee_id.get_employee_absence(p.date_from, p.date_to)
                month_hours = p.month_hours
                if month_hours > 0:
                    coefficient = p.get_coefficient_prorata()
                    print('Coef day ::', coefficient)
                    print('Absence hours ::', absences, 'month hours ::', month_hours)
                    p.prorata = coefficient * (1 - (absences / month_hours))
                    print(p.prorata)
                else:
                    p.prorata = 0.0
                # p.prorata = 1
            elif p.salary_type == 'holiday':
                quota = p.struct_id.convention_id.quota_annual_leave
                date_from = fields.Date.from_string(p.date_from)
                date_to = fields.Date.from_string(p.date_to)

                # days = date_to - date_from
                # val = date_from.weekday()
                # val_ = date_to.weekday()
                days = (date_to - date_from).days + 1
                all_days_leaves = days

                for day in range(days):
                    date_ = date_from + timedelta(days=day)
                    if date_.weekday() == 6:
                        all_days_leaves = all_days_leaves - 1
                # print('--------- all_days_leaves : ', all_days_leaves)
                self._cr.execute("""
                    SELECT
                        sum(h.number_of_days) AS days,
                        h.employee_id
                    FROM
                        hr_holidays h
                        join hr_holidays_status s ON (s.id=h.holiday_status_id)
                    WHERE
                        h.state='validate' AND
                        s.limit=False AND
                        s.nature='conventional' AND
                        h.employee_id in %s
                    GROUP BY h.employee_id""", (tuple([p.employee_id.id]),))
                result_conventional = {row['employee_id']: row['days'] for row in self._cr.dictfetchall()}

                if not result_conventional:
                    # raise ValidationError("You don't have request for leave")
                    p.message = _("You don't have request for leave")
                    p.prorata = 0.0
                else:
                    # due_days = result_conventional.get(p.employee_id.id)
                    # if all_days_leaves > due_days:
                    #     p.message = _("The number of days requested is greater than the number of days to which you "
                    #                   "are entitled")
                    #     p.prorata = 0.0
                    p.message = ""
                    p.prorata = all_days_leaves/quota
                # p.prorata = result_conventional[str(p.employee_id.id)]

    prorata = fields.Float(string='Prorata', compute='_get_prorata',digits=(10,5))
    message = fields.Text(compute='_get_prorata')
    month_hours = fields.Float(string='Month Hours', compute='_get_month_hours')

    def get_line_accessories(self):
        lines = self.line_ids.filtered(lambda l: l.salary_rule_id.accessory and l.total != 0)
        lines = lines.sorted(key=lambda l: l.sequence, reverse=False)
        return lines

    @api.multi
    def compute_sheet(self):
        for payslip in self:
            if payslip.employee_id.temp_ids:
                template = self.env.ref(
                    'its_hr_required_document_reminder.notification_email_reminder_required_documents')
                template.send_mail(payslip.employee_id.id, force_send=True, raise_exception=True)
        return super(Payroll, self).compute_sheet()

    def generate_employee_move(self, precision, date):
        line_ids = list()
        lines = self.line_ids.filtered(lambda l: not l.salary_rule_id.charge_employer)
        # lines = self.line_ids
        # .filtered(lambda l: not l.salary_rule_id.charge_employer and not l.salary_rule_id.is_loan_payment)
        for line in lines:
            amount = self.credit_note and -line.total or line.total
            if float_is_zero(amount, precision_digits=precision):
                continue
            debit_account_id = line.salary_rule_id.account_debit.id
            credit_account_id = line.salary_rule_id.account_credit.id

            if debit_account_id:
                debit_line = (0, 0, {
                    'name': line.name,
                    'partner_id': line._get_partner_id(credit_account=False),
                    'account_id': debit_account_id,
                    'journal_id': self.journal_id.id,
                    'date': date,
                    'debit': amount > 0.0 and amount or 0.0,
                    'credit': amount < 0.0 and -amount or 0.0,
                    'analytic_account_id': line.salary_rule_id.analytic_account_id.id,
                    'tax_line_id': line.salary_rule_id.account_tax_id.id,
                })
                line_ids.append(debit_line)
                # debit_sum += debit_line[2]['debit'] - debit_line[2]['credit']

            if credit_account_id:
                credit_line = (0, 0, {
                    'name': line.name,
                    'partner_id': line._get_partner_id(credit_account=True),
                    'account_id': credit_account_id,
                    'journal_id': self.journal_id.id,
                    'date': date,
                    'debit': amount < 0.0 and -amount or 0.0,
                    'credit': amount > 0.0 and amount or 0.0,
                    'analytic_account_id': line.salary_rule_id.analytic_account_id.id,
                    'tax_line_id': line.salary_rule_id.account_tax_id.id,
                })
                line_ids.append(credit_line)
                # credit_sum += credit_line[2]['credit'] - credit_line[2]['debit']
        return line_ids

    def get_account_employer_charge(self):
        charge_id = self.env['ir.config_parameter'].sudo().get_param('hr_payroll_extend.charge_id')
        social_charge_id = self.env['ir.config_parameter'].sudo().get_param('hr_payroll_extend.social_charge_id')
        return charge_id, social_charge_id

    def generate_employer_move(self, precision, date):
        tax_credit_sum = 0.0
        tax_debit_sum = 0.0
        social_credit_sum = 0.0
        social_debit_sum = 0.0
        tax_line_ids = []
        social_line_ids = []
        lines = self.line_ids.filtered(lambda l: l.salary_rule_id.charge_employer)
        tax_lines = lines.filtered(lambda l: l.salary_rule_id.tax)
        social_lines = lines.filtered(lambda l: l.salary_rule_id.social)
        for line in tax_lines:
            amount = self.credit_note and -line.total or line.total
            if float_is_zero(amount, precision_digits=precision):
                continue
            debit_account_id = line.salary_rule_id.account_debit.id
            credit_account_id = line.salary_rule_id.account_credit.id

            if debit_account_id:
                debit_line = (0, 0, {
                    'name': line.name,
                    'partner_id': line._get_partner_id(credit_account=False),
                    'account_id': debit_account_id,
                    'journal_id': self.journal_id.id,
                    'date': date,
                    'debit': amount > 0.0 and amount or 0.0,
                    'credit': amount < 0.0 and -amount or 0.0,
                    'analytic_account_id': line.salary_rule_id.analytic_account_id.id,
                    'tax_line_id': line.salary_rule_id.account_tax_id.id,
                })
                tax_line_ids.append(debit_line)
                tax_debit_sum += debit_line[2]['debit'] - debit_line[2]['credit']

            if credit_account_id:
                credit_line = (0, 0, {
                    'name': line.name,
                    'partner_id': line._get_partner_id(credit_account=True),
                    'account_id': credit_account_id,
                    'journal_id': self.journal_id.id,
                    'date': date,
                    'debit': amount < 0.0 and -amount or 0.0,
                    'credit': amount > 0.0 and amount or 0.0,
                    'analytic_account_id': line.salary_rule_id.analytic_account_id.id,
                    'tax_line_id': line.salary_rule_id.account_tax_id.id,
                })
                tax_line_ids.append(credit_line)
                tax_credit_sum += credit_line[2]['credit'] - credit_line[2]['debit']

        for line in social_lines:
            amount = self.credit_note and -line.total or line.total
            if float_is_zero(amount, precision_digits=precision):
                continue
            debit_account_id = line.salary_rule_id.account_debit.id
            credit_account_id = line.salary_rule_id.account_credit.id

            if debit_account_id:
                debit_line = (0, 0, {
                    'name': line.name,
                    'partner_id': line._get_partner_id(credit_account=False),
                    'account_id': debit_account_id,
                    'journal_id': self.journal_id.id,
                    'date': date,
                    'debit': amount > 0.0 and amount or 0.0,
                    'credit': amount < 0.0 and -amount or 0.0,
                    'analytic_account_id': line.salary_rule_id.analytic_account_id.id,
                    'tax_line_id': line.salary_rule_id.account_tax_id.id,
                })
                social_line_ids.append(debit_line)
                social_debit_sum += debit_line[2]['debit'] - debit_line[2]['credit']

            if credit_account_id:
                credit_line = (0, 0, {
                    'name': line.name,
                    'partner_id': line._get_partner_id(credit_account=True),
                    'account_id': credit_account_id,
                    'journal_id': self.journal_id.id,
                    'date': date,
                    'debit': amount < 0.0 and -amount or 0.0,
                    'credit': amount > 0.0 and amount or 0.0,
                    'analytic_account_id': line.salary_rule_id.analytic_account_id.id,
                    'tax_line_id': line.salary_rule_id.account_tax_id.id,
                })
                social_line_ids.append(credit_line)
                social_credit_sum += credit_line[2]['credit'] - credit_line[2]['debit']

        charge_id, social_charge_id = self.get_account_employer_charge()

        if float_compare(tax_credit_sum, tax_debit_sum, precision_digits=precision) == -1:
            # acc_id = self.journal_id.default_credit_account_id.id
            # if not acc_id:
            #     raise UserError(_('The Expense Journal "%s" has not properly configured the Credit Account!') % (
            #         self.journal_id.name))
            adjust_credit = (0, 0, {
                'name': _('Employer charges entry'),
                'partner_id': False,
                'account_id': charge_id,
                'journal_id': self.journal_id.id,
                'date': date,
                'debit': 0.0,
                'credit': tax_debit_sum - tax_credit_sum,
            })
            tax_line_ids.append(adjust_credit)

        elif float_compare(tax_debit_sum, tax_credit_sum, precision_digits=precision) == -1:
            # acc_id = self.journal_id.default_debit_account_id.id
            # if not acc_id:
            #     raise UserError(_('The Expense Journal "%s" has not properly configured the Debit Account!') % (
            #         self.journal_id.name))
            adjust_debit = (0, 0, {
                'name': _('Adjustment Entry'),
                'partner_id': False,
                'account_id': charge_id,
                'journal_id': self.journal_id.id,
                'date': date,
                'debit': tax_credit_sum - tax_debit_sum,
                'credit': 0.0,
            })
            tax_line_ids.append(adjust_debit)

        if float_compare(social_credit_sum, social_debit_sum, precision_digits=precision) == -1:
            # acc_id = self.journal_id.default_credit_account_id.id
            # if not acc_id:
            #     raise UserError(_('The Expense Journal "%s" has not properly configured the Credit Account!') % (
            #         self.journal_id.name))
            adjust_credit = (0, 0, {
                'name': _('Employer charges entry'),
                'partner_id': False,
                'account_id': charge_id,
                'journal_id': self.journal_id.id,
                'date': date,
                'debit': 0.0,
                'credit': social_debit_sum - social_credit_sum,
            })
            social_line_ids.append(adjust_credit)

        elif float_compare(social_debit_sum, social_credit_sum, precision_digits=precision) == -1:
            # acc_id = self.journal_id.default_debit_account_id.id
            # if not acc_id:
            #     raise UserError(_('The Expense Journal "%s" has not properly configured the Debit Account!') % (
            #         self.journal_id.name))
            adjust_debit = (0, 0, {
                'name': _('Adjustment Entry'),
                'partner_id': False,
                'account_id': charge_id,
                'journal_id': self.journal_id.id,
                'date': date,
                'debit': social_credit_sum - social_debit_sum,
                'credit': 0.0,
            })
            social_line_ids.append(adjust_debit)
        return social_line_ids, tax_line_ids

    @api.multi
    def action_payslip_done(self):
        self.ensure_one()
        if self.prorata == 0.0:
            raise ValidationError(_("Cannot confirm payslip that prorata temporis is null"))
        self.compute_sheet()
        precision = self.env['decimal.precision'].precision_get('Payroll')
        move_env = self.env['account.move']
        for slip in self:
            debit_sum = 0.0
            credit_sum = 0.0
            date = slip.date or slip.date_to

            name = _('Payslip of %s - %s') % (slip.employee_id.name, date)
            move_dict = {
                'narration': name,
                'ref': slip.number,
                'journal_id': slip.journal_id.id,
                'date': date,
            }

            line_ids = slip.generate_employee_move(precision, date)
            move_dict['line_ids'] = line_ids
            move = move_env.create(move_dict)
            slip.write({'move_id': move.id, 'date': date})
            move.post()

            social_line_ids, tax_line_ids = slip.generate_employer_move(precision, date)

            name = _('Payslip of %s - %s : Company Social Charges') % (slip.employee_id.name, date)
            move_dict.update({'name': name, 'line_ids': social_line_ids})
            move = move_env.create(move_dict)
            slip.write({'move_employer_social_id': move.id, 'date': date})
            move.post()

            name = _('Payslip of %s - %s : Company Tax Charges') % (slip.employee_id.name, date)
            move_dict.update({'name': name, 'line_ids': tax_line_ids})
            move = move_env.create(move_dict)
            slip.write({'move_employer_id': move.id, 'date': date})
            move.post()
        return self.write({'state': 'done'})
        # return super(Payroll, self).action_payslip_done()
