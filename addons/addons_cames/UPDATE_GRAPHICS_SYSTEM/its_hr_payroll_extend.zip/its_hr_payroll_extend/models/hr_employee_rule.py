from odoo import fields, models, api, _
import calendar
from dateutil.relativedelta import relativedelta


class HrEmployeeRule(models.Model):
    _name = 'hr.employee.rule'

    employee_id = fields.Many2one(
        comodel_name='hr.employee',
        string="Employee",
        required=True,
        track_visibility='always')
    convention_id = fields.Many2one(
        comodel_name='hr.convention',
        string="Convention",
        required=True,
        related='employee_id.convention_id',
        track_visibility='always')
    rule_id = fields.Many2one(
        comodel_name='hr.salary.rule',
        string="Salary rule",
        required=True,
        track_visibility='always')
    code = fields.Char(related='rule_id.code')
    date_start = fields.Date(required=True)
    date_end = fields.Date()
    # type = fields.Selection([('factor', 'Factor'), ('amount', 'Amount'),], required=True, default='amount')
    value = fields.Float(required=True, string='Value')
