from odoo import fields, models, api


class PayrollStructure(models.Model):
    _inherit = 'hr.payroll.structure'

    convention_id = fields.Many2one(comodel_name='hr.convention', string='Convention')
