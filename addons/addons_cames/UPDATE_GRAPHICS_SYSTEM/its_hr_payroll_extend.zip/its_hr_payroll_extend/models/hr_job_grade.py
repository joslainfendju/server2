from odoo import fields, models, api


class HrJobGrade(models.Model):
    _name = 'hr.job.grade'

    name = fields.Char(string="Name", required=True)
