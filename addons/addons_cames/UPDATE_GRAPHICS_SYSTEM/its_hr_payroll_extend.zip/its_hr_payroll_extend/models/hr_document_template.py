from odoo import fields, models, api


class HrDocumentTemplate(models.Model):
    _inherit = 'hr.document.template'

    grade_ids = fields.Many2many(
        comodel_name='hr.payslip.category',
        relation='hr_document_template_hr_job_grade_rel',
        column1='hr_document_template_id',
        column2='hr_job_grade_id',
        string="Grades")
