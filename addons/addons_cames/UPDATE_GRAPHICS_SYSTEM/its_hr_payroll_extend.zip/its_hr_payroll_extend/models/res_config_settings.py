from odoo import fields, models, api


class ResConfigSettings (models.TransientModel):
    _inherit = 'res.config.settings'

    charge_id = fields.Many2one(
        string="Charge tax Account",
        comodel_name="account.account", required=True
    )
    social_charge_id = fields.Many2one(
        string="Charge social Account",
        comodel_name="account.account", required=True
    )

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('hr_payroll_extend.charge_id',
                                                         self.charge_id.id)
        self.env['ir.config_parameter'].sudo().set_param('hr_payroll_extend.social_charge_id',
                                                         self.social_charge_id.id)
        # self.env['ir.config_parameter'].sudo().set_param('hr_payroll_extend.week_days',
        #                                                  self.week_days)

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(
            charge_id=int(self.env['ir.config_parameter'].sudo().get_param('hr_payroll_extend.charge_id')),
            social_charge_id=int(self.env['ir.config_parameter'].sudo().get_param('hr_payroll_extend.social_charge_id')),
            # week_days=int(self.env['ir.config_parameter'].sudo().get_param('hr_payroll_extend.week_days'))
        )
        return res
    


