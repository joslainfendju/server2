from odoo import fields, models, api



class LoanInstallmentDetail(models.Model):
    _inherit = 'loan.installment.details'

    @api.multi
    def pay_installment(self, payslip=False):
        # ok
        # probuse todo when call from form view of opening balance
        ctx = dict(self._context or {})
        move_pool = self.env['account.move']
        for installment in self:
            if installment.loan_id.state != 'disburse':
                raise Warning( _('Loan is not Disbursed yet !'))
            timenow = time.strftime('%Y-%m-%d')
            address_id = installment.loan_id.employee_id.address_home_id or False
            partner_id = address_id and address_id.id or False

            if not partner_id:
                raise Warning( _('Please configure Home Address for Employee !'))

            if installment.loan_id.loan_type.payment_method == 'cash':
                move = {
                    'narration': installment.loan_id.name,
                    'date': installment.date_from,
                    'ref': installment.install_no,
                    'journal_id': installment.loan_id.journal_id1.id,
                }
                if not installment.loan_id.journal_id1.default_debit_account_id:
                    raise Warning(_('Please configure Debit/Credit accounts on the Journal %s ') % (self.journal_id1.name))
                debit_line = (0, 0, {
                    'name': _('EMI of loan %s') % (installment.loan_id.name),
                    'date': installment.date_from,
                    'partner_id': partner_id,
                    'account_id': installment.loan_id.journal_id1.default_debit_account_id.id,
                    'journal_id': installment.loan_id.journal_id1.id,
                    'debit': installment.total,
                    'credit': 0.0,
                })
                credit_line = (0, 0, {
                    'name': _('EMI of loan %s') % (installment.loan_id.name),
                    'date': installment.date_from,
                    'partner_id': partner_id,
                    'account_id': installment.loan_id.employee_loan_account.id,
                    'journal_id':  installment.loan_id.journal_id1.id,
                    'debit': 0.0,
                    'credit':installment.total,
                })
                move.update({'line_ids': [debit_line, credit_line]})
                move_id = move_pool.create(move)
                installment.write({'state':'paid', 'move_id':move_id.id})
                installment.loan_id.compute_installments()
                if ctx.get('recompute'):
                    ctx.pop('recompute')
            else:
                if not installment.loan_id.journal_id1.default_debit_account_id:
                    raise Warning(_('Please configure Debit/Credit accounts on the Journal %s ') % (self.journal_id1.name))
                if not payslip:
                    raise Warning(_('Sorry this installment cannot be counted'))
                move = {
                    'narration': installment.loan_id.name,
                    'date': installment.date_from,
                    'ref': installment.install_no,
                    'journal_id': installment.loan_id.journal_id1.id,
                }
                salary_net = payslip.line_ids.filtered(lambda l:l.salary_rule_id.net)
                debit_line = (0, 0, {
                    'name': _('EMI of loan %s') % (installment.loan_id.name),
                    'date': installment.date_from,
                    'partner_id': partner_id,
                    'account_id': installment.loan_id.journal_id1.default_debit_account_id.id,
                    'journal_id': installment.loan_id.journal_id1.id,
                    'debit': installment.total,
                    'credit': 0.0,
                })
                credit_line = (0, 0, {
                    'name': _('EMI of loan %s') % (installment.loan_id.name),
                    'date': installment.date_from,
                    'partner_id': partner_id,
                    'account_id': installment.loan_id.employee_loan_account.id,
                    'journal_id':  installment.loan_id.journal_id1.id,
                    'debit': 0.0,
                    'credit':installment.total,
                })
                move.update({'line_ids': [debit_line, credit_line]})
                move_id = move_pool.create(move)
                installment.write({'state':'paid', 'move_id':move_id.id})
        return True