import datetime

DATE_TIME_FORMAT = '%Y-%m-%d %H:%M:%S'
DATE_FORMAT = '%Y-%m-%d'
_SATURDAY = 5
_SUNDAY = 6

WEEKENDS = [_SATURDAY, _SUNDAY]


class WeekendManager:


    def weekend_between_two_date(start, end):

        start_date = datetime.datetime.strptime(start, DATE_TIME_FORMAT)
        end_date = datetime.datetime.strptime(end, DATE_TIME_FORMAT)
        res = []
        for i in range((end_date - start_date).days+1):
            current_date = start_date + datetime.timedelta(days=i + 1)
            if current_date.weekday() in WEEKENDS:
                res.append(current_date)
        return res

    def weekend_between_two_date_v02(start, end):
        res = []
        cur_date = datetime.datetime.strptime(start, DATE_TIME_FORMAT)
        end_date = datetime.datetime.strptime(end, DATE_TIME_FORMAT)
        while cur_date <= end_date:
            if cur_date.weekday() in WEEKENDS:
                res.append(cur_date)
            cur_date = cur_date + datetime.timedelta(days=1)
        return res

    def weekend_between_two_date_str_format(start, end):

        start_date = datetime.datetime.strptime(start, DATE_TIME_FORMAT)
        end_date = datetime.datetime.strptime(end, DATE_TIME_FORMAT)
        res = []
        for i in range((end_date - start_date).days+1):
            current_date = start_date + datetime.timedelta(days=i + 1)
            if current_date.weekday() in WEEKENDS:
                res.append(datetime.datetime.strftime(current_date, DATE_TIME_FORMAT))
        return res

    def check_weekend_f_date(date_chech):

        d = datetime.datetime.strptime(date_chech, DATE_TIME_FORMAT)
        if d.weekday() in WEEKENDS: return True
        else: return False

    def exclud_sunday_days_f_period(start,end,with_saturday=True):
        """
        Exclud sunday and saturday days from period.
        """
        start_date = datetime.datetime.strptime(start, DATE_TIME_FORMAT)
        end_date = datetime.datetime.strptime(end, DATE_TIME_FORMAT)
        res = []
        for i in range((end_date - start_date).days+1):
            current_date = start_date + datetime.timedelta(days=i + 1)
            if current_date.weekday() in WEEKENDS:
                if with_saturday:# exclud sunday and saturday
                    res.append(current_date)
                else:# exclud only sunday days
                    if current_date.weekday() == _SUNDAY:res.append(current_date)
        return res

    def exclud_sun_sat_days_f_list_of_date(list_date,with_saturday=True):
        """
        Exclud sunday and saturday days from list of date.
        """
        res = list_date
        for i in list_date:
            current_date = datetime.datetime.strptime(i, DATE_FORMAT)
            if current_date.weekday() in WEEKENDS:
                if with_saturday:# exclud sunday and saturday
                    res.remove(i)
                else:# exclud only sunday days
                    if current_date.weekday() == _SUNDAY:res.remove(i)
        return res
