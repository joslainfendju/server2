# -*- coding: utf-8 -*-

import pytz
from datetime import datetime, timedelta
from odoo import fields, models, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

DATE_FORMAT = '%Y-%m-%d'


class HrEmployeeAttendanceSummaryItem(models.Model):
    _name = 'hr.employee.attendance.summary.item'

    summary_id = fields.Many2one('hr.employee.attendance.summary',
                                 string=_('Parent Summary'))
    date = fields.Date('Date')
    arrival_time = fields.Datetime(string=_("Arrival Time"))
    departure_time = fields.Datetime(string=_("Departure Time"))
    hours_late = fields.Float(_("Hours late"), compute='_get_hours_late', store=True)
    earlier_exit = fields.Float(_("Earlier Exit"), compute='_get_earlier_exit', store=True)
    overtime = fields.Float(_("Overtimes hours"), compute='_get_overtimes', store=True, default=0)
    total_working_hours_for_day = fields.Float(_('Total working hours for the day'),compute='_get_shift_timing')
    worked_hours = fields.Float(_("Worked Hours"))
    shift_time = fields.Char(_('Shift Timing'),compute='_get_shift_timing')


    @api.one
    @api.depends('arrival_time')
    def _get_hours_late(self):
        """
        Get hours late.
        """
        if not self.arrival_time: return True
        date_time = datetime.strptime(self.arrival_time, '%Y-%m-%d %H:%M:%S')
        d = str(date_time.weekday())
        working_h = self.env['resource.calendar.attendance'].search(
            [('calendar_id', '=', self.summary_id.employee_id.entity_id.resource_calendar_id.id),
             ('dayofweek', '=', d),
             ('name', 'like', 'Morning')])
        if working_h:
            date_time = self.datetime_formatted_to_local_tz(datetime_no_formatted=self.arrival_time)
            date_time_normal = self.arrival_time.split(' ')[0] + ' ' + timedelta(hours=working_h[0].hour_from).__str__()
            delta = datetime.strptime(date_time, DEFAULT_SERVER_DATETIME_FORMAT) - datetime.strptime(
                date_time_normal, DEFAULT_SERVER_DATETIME_FORMAT)
            self.hours_late = max(delta.total_seconds() / 3600.0, 0)
        return

    @api.one
    @api.depends('departure_time')
    def _get_earlier_exit(self):
        """
        Get earlier exit.
        """
        if not self.departure_time: return True
        date_time = datetime.strptime(self.departure_time, '%Y-%m-%d %H:%M:%S')
        d = str(date_time.weekday())
        working_h = self.env['resource.calendar.attendance'].search(
            [('calendar_id', '=', self.summary_id.employee_id.entity_id.resource_calendar_id.id),
             ('dayofweek', '=', d),
             ('name', 'like', 'Evening')])
        if working_h:
            date_time = self.datetime_formatted_to_local_tz(datetime_no_formatted=self.departure_time)
            date_time_normal = self.departure_time.split(' ')[0] + ' ' + timedelta(hours=working_h[0].hour_to).__str__()
            delta = datetime.strptime(date_time_normal, DEFAULT_SERVER_DATETIME_FORMAT) - datetime.strptime(
                date_time, DEFAULT_SERVER_DATETIME_FORMAT)
            self.earlier_exit = max(delta.total_seconds() / 3600.0, 0)
        return

    @api.one
    @api.depends('summary_id', 'date', 'worked_hours')
    def _get_overtimes(self):
        """
        Get overtimes.
        """
        if self.summary_id and self.date and self.worked_hours:
            total_working_hours_of_day = self.get_total_working_hours_of_day(date=self.date,
                                                                             employee_id=self.summary_id.employee_id.id)
            if total_working_hours_of_day != 0:
                if self.worked_hours > total_working_hours_of_day:
                    self.overtime = self.worked_hours - total_working_hours_of_day
            else:
                self.overtime = self.worked_hours
        return

    @api.one
    @api.depends('date', 'summary_id')
    def _get_shift_timing(self):
        """
        Onchange Shift Timing.
        """
        if not self.date or not self.summary_id:
            return

        hours_work_day_obj = self.get_hours_work_day_obj(date=self.date, employee_id=self.summary_id.employee_id.id)
        if hours_work_day_obj:
            morning = ''
            evining = ''
            hours_work_day = 0
            for h in hours_work_day_obj:
                hours_work_day += h.hour_to - h.hour_from
                if h.name.__contains__('Morning'):
                    morning = self.get_format_time_f_decimal(h.hour_from)
                else:
                    evining = self.get_format_time_f_decimal(h.hour_to)
            if morning != '' and evining != '':
                self.shift_time = morning + '-' + evining
                self.total_working_hours_for_day = hours_work_day
        return

    def get_format_time_f_decimal(self, decimal_number):
        """
        Return the string time format from decimal.
        """
        entiere = str(int(decimal_number)) + ':'
        decimal = str(int(decimal_number % 1 * 60))
        str_h = '0' + entiere if len(entiere) == 2 else entiere
        str_h += '0' + decimal if len(decimal) == 1 else decimal
        return str_h

    def get_hours_work_day_obj(self, employee_id, date):
        """
        Get records of calendar hours work day of date.
        """
        emp = self.env['hr.employee'].browse([employee_id])
        d = str(datetime.strptime(date, DATE_FORMAT).weekday())
        hours_work_day_obj = self.env['resource.calendar.attendance'].search(
            [('calendar_id', '=', emp.resource_calendar_id.id),
             ('dayofweek', '=', d)])
        return hours_work_day_obj

    def get_total_working_hours_of_day(self, date, employee_id):
        """
        Set total working hours of day to dict_value.
        """
        hours_work_day_obj = self.get_hours_work_day_obj(employee_id=employee_id, date=date)
        hours_work_day = 0
        for h in hours_work_day_obj:  # TODO, we have to correct the value of column type in resource.calendar.attendance records in database.
            hours_work_day += h.hour_to - h.hour_from
        # timedelta_day = timedelta(hours=hours_work_day)
        total_working_hours_of_day = hours_work_day

        return total_working_hours_of_day

    def datetime_formatted_to_local_tz(self,datetime_no_formatted):
        """
        Format datetime to local timezone of current user.
        @param datetime_no_formatted:str formatted %Y-%m-%d %H:%M:%S
        """
        current_date_time_formatted = datetime.strptime(datetime_no_formatted, '%Y-%m-%d %H:%M:%S')
        local_tz = pytz.timezone(self.env.user.partner_id.tz or 'GMT')
        local_dt = local_tz.localize(current_date_time_formatted, is_dst=True)
        local_utc = local_dt.utcoffset()
        current_date_time_formatted = local_dt + local_utc
        current_date_time_formatted = fields.Datetime.to_string(current_date_time_formatted)
        return current_date_time_formatted