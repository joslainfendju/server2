from datetime import datetime, timedelta

from odoo import fields, models, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

DATE_FORMAT = '%Y-%m-%d'


class EntityHrAttendance(models.Model):
    _name = 'hr.entity.attendance.summary'

    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']
    _description = "Entity Attendance summary"
    _order = 'id desc'

    name = fields.Char(string='Number', required=True, copy=False, default='/', readonly=True)
    entity_id = fields.Many2one(comodel_name='hr.entity', string='Entity')
    state = fields.Selection(
        [('draft', 'Draft'), ('cancel', 'Cancel'), ('to approve', 'Approved'), ('confirmed', 'Confirmed')],
        string='Status',
        required=True, readonly=True, copy=False, default='draft',
        help=_('New entry is  at draft state then, approved before confirmed'))
    total_days = fields.Float(string=_("Total Period days"), compute='_compute_total_days')
    total_weekend_days = fields.Float(string="Total Weekend days", compute='_compute_total_days')
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", default=fields.Date.today(), required=True)
    line_ids = fields.One2many('hr.employee.attendance.summary', 'summary_id', string='Lines', copy=True)
    line_m_ids = fields.One2many('hr.employee.attendance.summary', 'summary_m_id', string='Lines', copy=True)

    @api.multi
    def name_get(self):
        res = []
        for att in self:
            res.append((att.id, _("%s [%s - %s]") % (att.name, att.start_date, att.end_date
                                                     )))
        return res

    @api.multi
    def action_cancel(self):
        self.write({
            'state': 'cancel',
        })
        for rec in self:
            rec.line_ids.action_cancel()

    @api.multi
    def action_draft(self):
        self.write({
            'state': 'draft',
        })
        for rec in self:
            rec.line_ids.action_draft()

    @api.multi
    def action_submit(self):
        self.write({
            'state': 'to approve',
        })
        for rec in self:
            rec.line_ids.action_submit()

    @api.multi
    def action_approve(self):
        self.write({
            'state': 'confirmed',
        })
        for rec in self:
            rec.line_ids.action_approve()

    @api.model
    def create(self, vals):
        result = super(EntityHrAttendance, self).create(vals)
        if 'company_id' in vals:
            result.write({'name': self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                'hr.entity.attendance.summary') or _('New')})
        else:
            result.write({'name': self.env['ir.sequence'].next_by_code(
                'hr.entity.attendance.summary') or _('New')})
        return result

    @api.one
    @api.depends('start_date','end_date')
    def _compute_total_days(self):
        if self.start_date and self.end_date:
            delta = datetime.strptime(self.end_date,
                                      DATE_FORMAT) - datetime.strptime(
                self.start_date, DATE_FORMAT) + timedelta(days=1)
            self.total_days = delta.total_seconds() / 86400.0
