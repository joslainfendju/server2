from datetime import date, datetime, timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class HrEmpAttendanceSummaryGeneration(models.TransientModel):
    _name = 'hr.employee.attendance.summary.gen.wizard'

    start_date = fields.Date(string=_("Date de début"))
    end_date = fields.Date(string=_("Date fin"), default=fields.Datetime.now)
    hr_entity_id = fields.Many2one("hr.entity", string="Entité")
    hr_employee_ids = fields.Many2many("hr.employee", string="Employée", domain="[('entity_id','=',hr_entity_id)]")

    @api.multi
    def generate_payroll_var_foreach_emp(self):
        if self.end_date < self.start_date:
            raise UserError(_('La date de début ne peut être supérieur à la date de fin.'))
        if not self.hr_entity_id:
            raise UserError(_("Veuillez renseigner l'entité"))

        summary = self.env['hr.entity.attendance.summary'].create({
            'entity_id': self.hr_entity_id.id,
            'start_date': self.start_date,
            'end_date': self.end_date,
        })
        employee_att_sum_obj = self.env['hr.employee.attendance.summary']
        for emp in self.hr_employee_ids:
            employee_att_sum_obj.create({'summary_id': summary.id,
                                          'start_date': self.start_date,
                                          'end_date': self.end_date,
                                          'employee_id': emp.id})

        return self.action_view_hr_entity_summary(hr_entity_summray_ids=[summary.id])

    @api.multi
    def action_view_hr_entity_summary(self, hr_entity_summray_ids):
        '''
        This function returns an action that display hr_entity_summary of given hr_entity_summray_ids.
        When only one found, show the attendance request immediately.
        '''
        action = self.env.ref('its_hr_attendance_summary.action_entity_attendance_summary')
        result = action.read()[0]

        # override the context to get rid of the default filtering on operation type
        result['context'] = {}
        # choose the view_mode accordingly
        if not hr_entity_summray_ids or len(hr_entity_summray_ids) > 1:
            result['domain'] = "[('id','in',%s)]" % (hr_entity_summray_ids)
        elif len(hr_entity_summray_ids) == 1:
            res = self.env.ref('its_hr_attendance_summary.view_entity_attendance_summary_form', False)
            result['views'] = [(res and res.id or False, 'form')]
            result['res_id'] = hr_entity_summray_ids[0]
        return result

