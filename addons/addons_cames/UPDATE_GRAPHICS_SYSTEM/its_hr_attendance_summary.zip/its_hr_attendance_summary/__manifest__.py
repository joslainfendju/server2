# -*- coding: utf-8 -*-
{
    'name': "Hr Attendance Summary",

    'summary': """
       Prepare a summary state of attendance.""",

    'description': """
        Prepare a summary state of attendance.:
        - Summary for an employee
        - Summary for an entity
        - Approve or Reject the summary
    """,

    'author': "IT Services, Patrick Tzorneu",
    'website': "http://www.its-nh.com",

    'category': 'Human Resources',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': [
        'hr_attendance',
        'its_hr_entity_holidays',
    ],

    # always loaded
    'data': [
        # 'views/hr_entity_view.xml',
        'wizard/hr_employee_attendance_summary_gen_view.xml',
        'views/hr_entity_attendance_summary.xml',
        'views/hr_employee_attendance_summary.xml',
        'views/leave_type.xml',
        'views/leave.xml',
        'views/action.xml',
        'views/menu.xml',
        'data/ir_sequence_data.xml',
    ],
    'qweb': [

    ],
    # only loaded in demonstration mode
    'demo': [

    ],
    'auto_install': True,
}
