# -*- coding: utf-8 -*-
###################################################################################
#
#    Cybrosys Technologies Pvt. Ltd.
#    Copyright (C) 2018-TODAY Cybrosys Technologies(<http://www.cybrosys.com>).
#    Author: cybrosys(<https://www.cybrosys.com>)
#
#    This program is free software: you can modify
#    it under the terms of the GNU Affero General Public License (AGPL) as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
###################################################################################
import os

import pytz
# import sys
from datetime import date, datetime,timedelta
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
import logging
import binascii
from os import path, mkdir
import pickle
import glob

from . import zklib
from .zkconst import *
from struct import unpack
from odoo import api, fields, models
from odoo import _
from odoo.exceptions import UserError, ValidationError

from collections import defaultdict

from odoo.tools.config import config

# from odoo.tools.misc import profile

_logger = logging.getLogger(__name__)

DATE_TIME_FORMAT = '%Y-%m-%d %H:%M:%S'
DATE_FORMAT = '%Y-%m-%d'
START_TIME = "00:00:00"
END_TIME = "23:59:59"


class ZkMachine(models.Model):
    _inherit = 'zk.machine'

    state = fields.Selection([('draft', 'Initialize'), ('done', 'Ready')], string='State', default="draft")
    location_id = fields.Many2one('zk.machine.location', _('Location of the device'))

    @api.model
    def cron_download(self):
        """
        Cron d'importation des données.
        """
        _logger.info("++++++++++++Cron download attendance date started ++++++++++++++++++++++")
        machines = self.env['zk.machine'].search([])
        start_date = end_date = date.today().__str__()
        for machine in machines:
            machine.download_and_filter_att_data(end_date=end_date, start_date=start_date)
        _logger.info("++++++++++++Cron download attendance date end ++++++++++++++++++++++")

    def _get_date_now(self):
        """
        Get the current datetime.
        """
        current_date_time_formatted = datetime.now()
        current_date_time_formatted = datetime.strptime(
            current_date_time_formatted.strftime('%Y-%m-%d %H:%M:%S'), '%Y-%m-%d %H:%M:%S')
        local_tz = pytz.timezone(
            self.env.user.partner_id.tz or 'GMT')
        local_dt = local_tz.localize(current_date_time_formatted, is_dst=None)
        utc_dt = local_dt.astimezone(pytz.utc)
        utc_dt = utc_dt.strftime("%Y-%m-%d %H:%M:%S")
        current_date_time_formatted = datetime.strptime(
            utc_dt, "%Y-%m-%d %H:%M:%S")
        current_date_time_formatted = fields.Datetime.to_string(current_date_time_formatted)
        return current_date_time_formatted

    @api.model
    def cron_process_data(self):
        """
        Cron de traitement des fichiers.
        """

        _logger.info("++++++++++++Cron process attendance file data started ++++++++++++++++++++++")
        machines = self.env['zk.machine'].search([])
        for machine in machines:
            key = "*" + str(machine.name).replace(".", "") + str(machine.port_no) + ".tmp"
            machine.laod_att_from_file_tmp(key=key)
        _logger.info("++++++++++++Cron process attendance file data end ++++++++++++++++++++++")

    @api.model
    def cron_structured_attendances_logs(self):
        """
        Cron which structured th attendances logs datas.
        """
        _logger.info("++++++++++++Cron Structured Attendances Logs: STARTED ++++++++++++++++++++++")
        machines = self.env['zk.machine'].search([])
        start_date = date.today() + timedelta(days=-1)
        start_date = start_date.__str__()
        end_date = date.today().__str__()
        for machine in machines:
            machine.build_hr_attendance_datas(start_date=start_date,end_date=end_date)
        _logger.info("++++++++++++Cron Structured Attendances Logs: END++++++++++++++++++++++")
        return

    # @profile("/temp/zkm_import_data.profile")
    @api.multi
    def import_data(self, start_date, end_date):
        """
        Methode invoquée au clic du bouton d'importation des données.
        Invoque la méthode de téléchargement des données de présences et en suite de traitement des données
        """
        file_name_save_date = self.download_and_filter_att_data(end_date=end_date, start_date=start_date)
        self.laod_att_from_file_tmp(file_name_data=file_name_save_date)
        self.build_hr_attendance_datas(start_date=start_date, end_date=end_date)
        return

    @api.multi
    def processing_files_data(self):
        """
        Méthode invoquée au clic du bouton de traitement des fichiers.
        Invoque la méthode de traitement des fichiers de la machine correspondante.
        """
        key = "*" + str(self.name).replace(".", "") + str(self.port_no) + ".tmp"
        path_files = self.env['ir.config_parameter'].search([('key', '=', 'path_file_att_download')])
        if path.exists(path_files.value):
            if not glob.glob(path.join(path_files.value, key)):
                raise ValidationError(_("Pas de données trouvées!"))
            else:
                self.laod_att_from_file_tmp(key=key)
        return

    @api.multi
    def download_and_filter_att_data(self, start_date, end_date):
        """
        Methode invoquée par le cron de téléchargement des données de présences.
        Télécharge les données de présences , en suite filtre et sauvegarde dans un fichier.
        """
        file_name = False
        attendance = self.download_attendance()
        if attendance:
            start_d = datetime.strptime(start_date, DATE_FORMAT)
            end_d = datetime.strptime(end_date + " " +END_TIME, DEFAULT_SERVER_DATETIME_FORMAT)
            attendances_filter = list(
                filter(lambda att: att[2] >= start_d and end_d >= att[2], attendance))
            file_name = self.save_data_att_in_file(attendances_filter)
        return file_name

    @api.multi
    def action_open_period_form(self):
        """
            This function opens a window to indicate the period.
        """
        ir_model_data = self.env['ir.model.data']
        try:
            periode_form_id = \
                ir_model_data.get_object_reference('its_hr_zk_attendance_extend', 'its_hr_zk_mach_wizard_form')[1]
        except ValueError:
            periode_form_id = False

        ctx = dict(self.env.context or {})
        ctx.update({
            'default_model': 'zk.machine',
            'default_zk_machine_id': self.ids[0],
        })
        return {
            'name': _("Période d'importation"),
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'its.hr.zk.machine.wizard',
            'views': [(periode_form_id, 'form')],
            'view_id': periode_form_id,
            'target': 'new',
            'context': ctx,
        }

    # @api.multi
    def download_attendance(self):
        # _logger.info("++++++++++++Cron Executed++++++++++++++++++++++")
        for info in self:
            machine_ip = info.name
            port = info.port_no
            zk = zklib.ZKLib(machine_ip, port)
            _logger.info("Try to connect to this machine %s on the port  %s" % (info.name, info.port_no))
            conn = self.device_connect(zk)
            _logger.info("The connection result is %s" % conn)
            if conn:
                zk.enableDevice()
                command = CMD_ATTLOG_RRQ
                command_string = ''
                chksum = 0
                session_id = zk.session_id
                reply_id = unpack('HHHH', zk.data_recv[:8])[3]
                buf = zk.createHeader(command, chksum, session_id,
                                      reply_id, command_string)
                zk.zkclient.sendto(buf, zk.address)
                try:
                    zk.data_recv, addr = zk.zkclient.recvfrom(1024)
                    command = unpack('HHHH', zk.data_recv[:8])[0]
                    if command == CMD_PREPARE_DATA:
                        size = unpack('I', zk.data_recv[8:12])[0]
                        zk_size = size
                    else:
                        zk_size = False
                    if zk_size:
                        bytes = zk_size
                        while bytes > 0:
                            data_recv, addr = zk.zkclient.recvfrom(1032)
                            zk.attendancedata.append(data_recv)
                            bytes -= 1024
                        zk.session_id = unpack('HHHH', zk.data_recv[:8])[2]
                        # data_recv = zk.zkclient.recvfrom(8)
                        attendance = []
                        if len(zk.attendancedata) > 0:
                            # The first 4 bytes don't seem to be related to the user
                            for x in xrange(len(zk.attendancedata)):
                                if x > 0:
                                    zk.attendancedata[x] = zk.attendancedata[x][8:]
                            attendancedata = b''.join(zk.attendancedata)
                            attendancedata = attendancedata[14:]
                            while len(attendancedata) > 0:
                                uid, state, timestamp, space = unpack('24s1s4s11s', attendancedata.ljust(40)[:40])
                                pls = unpack('c', attendancedata[29:30])
                                uid = uid.split(b'\x00', 1)[0].decode('utf-8')
                                tmp = ''
                                for i in reversed(range(int(len(binascii.hexlify(timestamp)) / 2))):
                                    tmp += binascii.hexlify(timestamp).decode('utf-8')[i * 2:(i * 2) + 2]
                                attendance.append((uid, int(binascii.hexlify(state), 16),
                                                   decode_time(int(tmp, 16)), unpack('HHHH', space[:8])[0]))

                                attendancedata = attendancedata[40:]
                    else:
                        raise UserError(_('Echec lors du téléchargement, veuillez reéssayer.'))
                except Exception as e:
                    _logger.info("++++++++++++Exception++++++++++++++++++++++", e)
                    attendance = False
                    raise UserError(_('Une erreur est survenue, veuillez reéssayer.'))
                finally:
                    zk.enableDevice()
                    zk.disconnect()

                return attendance
            else:
                raise UserError(_('Unable to connect, please check the parameters and network connections.'))

    def save_data_att_in_file(self, attendance):
        """
        Sauvegarder dans un fichier les données de présences télécharger.
        """
        # create folder if not exists
        param_sys_config_folder = self.env['ir.config_parameter'].search([('key', '=', 'path_file_att_download')])
        if not path.exists(param_sys_config_folder.value) and param_sys_config_folder.value:
            try:
                mkdir(param_sys_config_folder.value)
            except FileNotFoundError:
                raise UserError(_("Dossier de sauvegarde de données introuvable"))

        file_name = str("att_%s" % (datetime.now())).replace(" ", "_").replace(".", "_").replace(":",
                                                                                                 "") + "_" + str(
            self.name).replace(
            ".", "") + str(self.port_no) + ".tmp"
        with open(path.join(param_sys_config_folder.value, file_name), 'wb') as f:
            pickle.dump(attendance, f)
        return file_name

    def laod_att_from_file_tmp(self, file_name_data=None, key=None):
        """
        Recuperer les données dans les fichiers temp de sauvegarde puis lance le traitement.
        """

        filter_str = file_name_data
        if not file_name_data:
            filter_str = "*.tmp"
            if key: filter_str = key

        param_sys_config_folder = self.env['ir.config_parameter'].search([('key', '=', 'path_file_att_download')])
        if path.exists(param_sys_config_folder.value):
            users = self.get_user()
            for f in glob.glob(path.join(param_sys_config_folder.value, filter_str)):
                att_data = False
                with open(f, "rb") as fb:
                    att_data = pickle.load(fb)
                if att_data:
                    if self.process_data_attendance(attendance=att_data, user=users):
                        try:
                            os.remove(f)
                            _logger.info("File {}: remove successfuly!".format(f))
                        except OSError as e:
                            _logger.info("{}".format(e))
        else:
            raise UserError(_("Dossier de sauvegarde de données introuvable"))
        return

    def get_user(self):
        """
        Recupere les utilisateurs de la machine.
        """
        zk = zklib.ZKLib(self.name, self.port_no)
        _logger.info("Try to connect to this machine %s on the port  %s" % (self.name, self.port_no))
        conn = self.device_connect(zk)
        _logger.info("The connection result is %s" % conn)
        if conn:
            zk.enableDevice()
            user = self.zkgetuser(zk)
            zk.enableDevice()
            zk.disconnect()
            return user
        else:
            raise UserError(_('Veuillez réessayer, une erreur s''est produite.'))

    def import_employee_data(self):
        """
        Import only employees data.
        """
        users = self.get_user()
        for uid in users:
            current_user_data = users[uid]
            c = current_user_data[1].split(";")
            current_user_name = c[1] if len(c) > 1 else ''
            device_id = c[0]
            get_user_id = self.env['hr.employee'].search(
                [('device_id', '=', device_id)])
            if not get_user_id:
                self.env['hr.employee'].create({
                    'device_id': device_id,
                    'name': current_user_name
                })
        if users:
            self.write({'state': "done"})
        else:
            UserError(_("Something wrong, please try again"))
        return

    @api.multi
    def clear_all_data(self):
        """
        Vide toutes les données de présences et les employés liées a cette machine.
        """
        # rechercher tous les employés ayant pointé sur cette machine
        zk_attendance = self.env['zk.machine.attendance'].search([('machine_id', '=', self.ids[0])])
        emp_ids = tuple(set([zk.employee_id.id for zk in zk_attendance]))
        if emp_ids: self._cr.execute("""delete from hr_employee where id in %s""", (emp_ids,))
        return True

    @api.multi
    def process_data_attendance(self, attendance, user):
        """
        Effectuer les enregistrements des présences non encore existentes dans la base de données.
        """
        if not attendance: return False
        zk_attendance = self.env['zk.machine.attendance']
        # att_obj = self.env['hr.attendance']
        # query_insert_hr_emp = """INSERT INTO hr_employee (device_id,name,create_uid,write_uid,create_date,write_date,identification_id) VALUES(%s,%s,%s,%s,%s,%s,%s)"""
        if user:
            for uid in user:
                current_user_data = user[uid]
                current_user_name = current_user_data[1].split(";")[1]
                device_id = current_user_data[1].split(";")[0]
                att_uid = list(filter(lambda att: att[0] == user[uid][0], attendance))

                if att_uid:
                    get_user_id = self.env['hr.employee'].search(
                        [('device_id', '=', device_id)])
                    is_new_emp = False
                    if not get_user_id:  # create new employee
                        self.env['hr.employee'].create({
                            'device_id': device_id,
                            'name': current_user_name
                        })
                        is_new_emp = True
                        get_user_id = self.env['hr.employee'].search(
                            [('device_id', '=', device_id)])
                    for each in sorted(att_uid, key=lambda a: a[2]):
                        atten_time = each[2]
                        atten_time = datetime.strptime(
                            atten_time.strftime('%Y-%m-%d %H:%M:%S'), '%Y-%m-%d %H:%M:%S')
                        local_tz = pytz.timezone(
                            self.env.user.partner_id.tz or 'GMT')
                        local_dt = local_tz.localize(atten_time, is_dst=None)
                        utc_dt = local_dt.astimezone(pytz.utc)
                        utc_dt = utc_dt.strftime("%Y-%m-%d %H:%M:%S")
                        atten_time = datetime.strptime(
                            utc_dt, "%Y-%m-%d %H:%M:%S")
                        atten_time = fields.Datetime.to_string(atten_time)
                        if not is_new_emp:
                            duplicate_atten_ids = zk_attendance.search(
                                [('device_id', '=', device_id), ('punching_time', '=', atten_time)])
                            if duplicate_atten_ids:
                                continue
                            else:
                                try:
                                    zk_attendance.create({'employee_id': get_user_id.id,
                                                          'device_id': device_id,
                                                          'machine_id': self.id,
                                                          'attendance_type': str(each[1]),
                                                          'punch_type': str(each[3]),
                                                          'punching_time': atten_time,
                                                          'source': 'device',
                                                          'address_id': self.address_id.id})

                                except Exception as e:
                                    _logger.info("++++++++++++++++++++++ Exception ", e)
                        else:
                            is_new_emp = False
                            zk_attendance.create({'employee_id': get_user_id.id,
                                                  'device_id': device_id,
                                                  'machine_id': self.id,
                                                  'attendance_type': str(each[1]),
                                                  'punch_type': str(each[3]),
                                                  'source': 'device',
                                                  'punching_time': atten_time,
                                                  'address_id': self.address_id.id})

            return True
        else:
            raise UserError(_("Echec d'importation des données, veuillez reessayer"))

    def build_hr_attendance_datas(self, start_date, end_date):
        """
        Build hr_attendance datas and save it.
        @param start_date: date, start date.
        @param end_date: date, end date.
        """
        start = start_date + " " + START_TIME
        end = end_date + " " + END_TIME
        query = """SELECT  
                    zka.punching_time::timestamp::date as date, 
                    zka.employee_id,
                    zka.punching_time, 
                    case 
                    when zka.punch_type = '0' then 'check_in' 
                    when zka.punch_type = '1' then 'check_out'
                    when zka.punch_type = '2' then 'break_out' 
                    when zka.punch_type = '3' then 'break_in' 
                    when zka.punch_type = '4' then 'overtime_in' 
                    when zka.punch_type = '5' then 'overtime_out' end as punch_type, 
                    emp.entity_id,
                    zkmloc.location_name as location_device,
                    zka.device_id
                    FROM zk_machine_attendance zka, hr_employee emp,zk_machine zkm,zk_machine_location zkmloc
                    where zka.employee_id = emp.id
                    and zka.punching_time <= '%s'
                    and zka.punching_time >= '%s'
                    and zka.machine_id = zkm.id
                    and zkm.location_id = zkmloc.id
                    order by date asc,employee_id,punching_time asc
                """ % (end, start)
        grouped = defaultdict(list)
        self._cr.execute(query)
        for date, employee_id, punching_time, punch_type, entity_id, location_device, device_id in self._cr.fetchall():
            grouped[date].append({
                'date': date,
                'punching_time': punching_time,
                'punch_type': punch_type,
                'entity_id': entity_id,
                'employee_id': employee_id,
                'location_device': location_device,
                'device_id': device_id
            })

        self.create_hr_attendance_datas(datas=grouped)
        return

    def create_hr_attendance_datas(self, datas):
        """
        Create hr_attendances.
        @param datas: list of dict.
        """
        res = {}
        group = defaultdict(list)
        for value in datas:
            for attendance in datas[value]:
                group[attendance["employee_id"]].append((attendance['punching_time'], attendance['punch_type'],
                                                         attendance['location_device'], attendance['device_id']))
            res[value] = dict(group)
            group.clear()

        for date in res:
            for val in res[date]:
                self.create_or_update_one_hr_attendance(date, employee_id=val, values=res[date][val])
        return

    def create_or_update_one_hr_attendance(self, date, employee_id, values):
        """
        Create or update  hr.attendance.
        @param date: str format to Date.
        @param employee_id: integer
        @param: values: list
        @return
        """
        att_obj = self.env['hr.attendance']
        hours_work_day_obj = self.get_hours_work_day_obj(employee_id=employee_id, date=date)
        dict_value = {'employee_id': employee_id, 'source': 'device', 'break_in': False, 'break_out': False,
                      'device_id': values[0][3],
                      'check_in': False, 'device_location_check_in': False, 'check_out': False,
                      'device_location_check_out': False, 'return_1': False, 'exit_1': False, 'return_2': False,
                      'exit_2': False}

        self.set_arrival_departure_time(values, dict_value=dict_value, hours_work_of_day=hours_work_day_obj)
        self.set_breacks_times(list_att_emp_of_date=values, dict_value=dict_value)
        hr_att = att_obj.search(['&','&',('employee_id', '=', employee_id),
                                 ('device_location_check_in', '=', dict_value['device_location_check_in']),
                                 '|','&',('check_in', '=', dict_value['check_in']),('check_out','<',dict_value['check_out']),
                                 '&',('check_in', '=', dict_value['check_in']),('check_out', '=', False)])
        if hr_att and dict_value['check_out']: # update attendance
                hr_att.write({'check_out': dict_value['check_out'],
                              'device_location_check_out': dict_value['device_location_check_out'],
                              'break_in': dict_value['break_in'], 'break_out': dict_value['break_out'],
                              'return_1': dict_value['return_1'], 'exit_1': dict_value['exit_1'],
                              'return_2': dict_value['return_2'], 'exit_2': dict_value['exit_2']})
        else:
            hr_att_duplicate = att_obj.search([('employee_id', '=', employee_id),
                                     ('device_location_check_in', '=', dict_value['device_location_check_in']),
                                     ('check_in', '=', dict_value['check_in']),('check_out','=',dict_value['check_out'])
                                     ])
            if not hr_att_duplicate:
                att_obj.create(dict_value)

        return

    def set_arrival_departure_time(self, list_att_emp_of_date, dict_value, hours_work_of_day):
        """
        Get arrival and departure time.

        @param list_att_emp_of_date : list of tuple. Represent the list of datetime shift.
        @param dict_value: dict. reference of dict value to return
        @param hours_work_of_day: object resource.calendar.attendance
        @return
        """
        if len(list_att_emp_of_date) > 1:
            arrival_datetime_and_localisation = min(list_att_emp_of_date, key=lambda x: x[0])
            dict_value['check_in'] = arrival_datetime_and_localisation[0]
            dict_value['device_location_check_in'] = arrival_datetime_and_localisation[2]
            departure_datetime_and_localisation = max(list_att_emp_of_date, key=lambda x: x[0])
            dict_value['check_out'] = departure_datetime_and_localisation[0]
            dict_value['device_location_check_out'] = departure_datetime_and_localisation[2]
        elif len(list_att_emp_of_date) == 1:
            if hours_work_of_day:
                midtime = hours_work_of_day[0].hour_to
                punching_hour = datetime.strptime(list_att_emp_of_date[0][0],
                                                  DEFAULT_SERVER_DATETIME_FORMAT).time().hour
                if midtime > punching_hour:
                    dict_value['check_in'] = list_att_emp_of_date[0][0]
                    dict_value['device_location_check_in'] = list_att_emp_of_date[0][2]
                else:
                    dict_value['check_out'] = list_att_emp_of_date[0][0]
                    dict_value['device_location_check_out'] = list_att_emp_of_date[0][2]
            else:
                dict_value['check_in'] = list_att_emp_of_date[0][0]
                dict_value['device_location_check_in'] = list_att_emp_of_date[0][2]

        return

    def set_breacks_times(self, list_att_emp_of_date, dict_value):
        """
        Get break in and break out time.
        Parameters
        ---------
        list_att_emp_of_date : list of tuple. Represent the list of datetime shift.
        dict_value: dict. reference of dict value to return

        """

        if len(list_att_emp_of_date) > 2 and (dict_value['check_in'] or dict_value['check_out']):
            list_break_time = list(filter(lambda x: x[0] != dict_value['check_in'] and dict_value['check_out'] != x[0],
                                          list_att_emp_of_date))
            if len(list_break_time) > 1:
                dict_value['break_out'] = min(list_break_time, key=lambda x: x[0])[0]
                dict_value['break_in'] = max(list_break_time, key=lambda x: x[0])[0]
            elif len(list_break_time) == 1:
                if list_break_time[0][1] == 'break_in':
                    dict_value['break_in'] = list_break_time[0][0]
                elif list_break_time[0][1] == 'break_out':
                    dict_value['break_out'] = list_break_time[0][0]

        return

    def get_hours_work_day_obj(self, employee_id, date):
        """
        Get records of calendar hours work day of date.
        """
        emp = self.env['hr.employee'].browse([employee_id])
        d = str(datetime.strptime(date, DATE_FORMAT).weekday())
        hours_work_day_obj = self.env['resource.calendar.attendance'].search(
            [('calendar_id', '=', emp.resource_calendar_id.id),
             ('dayofweek', '=', d)])
        return hours_work_day_obj
