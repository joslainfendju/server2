# -*- coding: utf-8 -*-

from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from datetime import datetime,timedelta
from odoo import models,fields,api,_

class HrAttendance(models.Model):
    _inherit = "hr.attendance"

    source = fields.Selection([('odoo', _('Odoo')),
                               ('device', _('Device')),
                               ('request', _('Request'))],
                              string=_('Source of attendance'),default='odoo')
    check_in = fields.Datetime(string="Check In",required=False)
    device_location_check_in = fields.Char(_('Location of Device of Check In'))
    device_location_check_out = fields.Char(_('Location of Device of Check Out'))
    break_in = fields.Datetime(string=_('Break In'))
    break_out = fields.Datetime(string=_('Break Out'))
    return_1 = fields.Datetime(string=_('Return 1'))
    exit_1 = fields.Datetime(string=_('Exit 1'))
    return_2 = fields.Datetime(string=_('Return 2'))
    exit_2 = fields.Datetime(string=_('Exit 1'))

    @api.depends('check_in', 'check_out')
    def _compute_worked_hours(self):
        for attendance in self:
            if attendance.check_out and attendance.check_in:
                delta = datetime.strptime(attendance.check_out, DEFAULT_SERVER_DATETIME_FORMAT) - datetime.strptime(
                    attendance.check_in, DEFAULT_SERVER_DATETIME_FORMAT)
                attendance.worked_hours = delta.total_seconds() / 3600.0

    @api.constrains('check_in', 'check_out', 'employee_id')
    def _check_validity(self): # ignore the original behavior
        pass