# -*- coding: utf-8 -*-

from odoo import models


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    _sql_constraints = [
        ('device_id_uniq', 'unique (device_id)','duplicate device ID!')
    ]