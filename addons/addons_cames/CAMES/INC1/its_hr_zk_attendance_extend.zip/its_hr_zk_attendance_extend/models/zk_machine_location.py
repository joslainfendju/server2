# -*- coding: utf-8 -*-

import logging

from odoo import api, fields, models,_


_logger = logging.getLogger(__name__)

class ZkMachineLocation(models.Model):
    _name = 'zk.machine.location'
    _rec_name = 'location_name'

    location_name = fields.Char(_("Location Name"))
    description = fields.Char(_('Description of location'))

    _sql_constraints = [
        ('location_name_uniq', 'unique (location_name)',_('duplicate location_name!'))
    ]