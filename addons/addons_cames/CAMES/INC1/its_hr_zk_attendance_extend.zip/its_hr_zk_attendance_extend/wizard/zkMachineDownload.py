from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ZkMachineDownload(models.TransientModel):
    _name = 'its.hr.zk.machine.wizard'

    start_date = fields.Date(string=_("Date de début"))
    end_date = fields.Date(string=_("Date de fin"),default=fields.Datetime.now)
    zk_machine_id = fields.Many2one("zk.machine", string="Machine")

    @api.multi
    def import_attendance_data(self):
        if self.end_date < self.start_date:
            raise UserError(_('La date de début ne peut être supérieur à la date de fin.'))

        machine_obj = self.env['zk.machine'].browse(self.zk_machine_id.id)
        machine_obj.import_data(self.start_date,self.end_date)
        return True