Biometric Device Integration v11
================================
This ITS services module extend and depends the Cybrosys's  Biometric Device Integration module.

Features
========
* Ingrates biometric device(Face+Thumb) with HR attendance.
* Managing attendance automatically
* Keeps zk machine history in Odoo
* Option to configure multiple zk devices
* Option to clear all zk history from both device and Odoo

Author
=======
* ITS services <https://its-nh.com/>

Credits
=======
Developer: Loic Medou @ Its services, loic.medou@its-nh.com

