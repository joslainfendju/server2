## Module <hr_zk_attendance>

#### 24.04.2019
#### Version 11.0.1.0.0
##### ADD
- Initial commit
