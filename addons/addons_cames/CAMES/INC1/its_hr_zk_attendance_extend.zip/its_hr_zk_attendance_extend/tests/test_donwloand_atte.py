# -*- coding: utf-8 -*-
from datetime import datetime
from odoo.tests.common import TransactionCase

class TestDownloadAndSaveAttendanceData(TransactionCase):
    """
    """
    def setUp(self):
        super(TestDownloadAndSaveAttendanceData, self).setUp()
        self.zk_machine_model = self.env['zk.machine']
        self.zk_machine_attendance_model = self.env['zk.machine.attendance']
        self.hr_attendance_model = self.env['hr.attendance']