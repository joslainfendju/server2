# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class AddValidationHr(models.Model):
    _inherit = 'hr.applicant'

    stage_check = fields.Char(related='stage_id.name')

    @api.multi
    def write(self, data):
        res = super(AddValidationHr, self).write(data)
        if 'stage_id' in data and 'last_stage_id' in data:
            last_stage = self.env['hr.recruitment.stage'].search([('id', '=', data['last_stage_id'])])
            stage = self.env['hr.recruitment.stage'].search([('id', '=', data['stage_id'])])
            if last_stage.sequence > stage.sequence:
                raise UserError(_("Invalid movement!!!"))
        return res
