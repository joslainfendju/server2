# -*- coding: utf-8 -*-
{
    'name': 'Advanced HR Recruitment',
    'version': '10.0.1.0.0',
    'summary': 'Creates validations In HR Recruitment Workflow'
               '(Eg: An application stage cannot be moved to its previous one)',
    'description': """ Once Application stage is set as Contract signed then Users cannot change its value
    """,
    'author': 'Cybrosys Techno Solutions',
    'company': 'Cybrosys Techno Solutions',
    'category': 'Generic Modules/Human Resources',
    'website': 'https://www.cybrosys.com',
    'depends': [
        'base',
        'hr_recruitment'
    ],
    'data': ['views/hr_form_extend.xml'],
    'images': ['static/description/banner.jpg'],
    'installable': True,
    'license': 'LGPL-3',
    'installable': True,
    'auto_install': False,
}
