## Module <hr_linkedin_recruitment>

#### 1.05.2019
#### Version 11.0.1.0.0
##### ADD
- Initial commit (linkedin api v2)
