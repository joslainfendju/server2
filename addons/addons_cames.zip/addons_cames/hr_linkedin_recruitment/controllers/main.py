# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import logging

import json

import werkzeug.urls
import werkzeug.utils
from odoo.http import request

from odoo.addons.auth_oauth.controllers.main import OAuthLogin as Home


_logger = logging.getLogger(__name__)


class OAuthLogin(Home):

    def list_providers(self):
        providers = super(OAuthLogin, self).list_providers()
        for provider in providers:
            return_url = request.httprequest.url_root + 'auth_oauth/signin'
            state = self.get_state(provider)
            params = dict(
                response_type='token',
                client_id=provider['client_id'],
                redirect_uri=return_url,
                scope=provider['scope'],
                state=json.dumps(state),
            )
            if provider['client_secret']:
                params.update({'client_secret': provider['client_secret']})
            provider['auth_link'] = "%s?%s" % (provider['auth_endpoint'], werkzeug.url_encode(params))
        return providers
