from odoo import fields, models, api


class AttendanceReport(models.Model):
    _name = 'report.hr_attendance_extend.attendance_recap_report_view'
    _description = 'Description'

    name = fields.Char()
