# -*- coding: utf-8 -*-
{
    'name': "Attendance Extend",

    'summary': """
        """,

    'description': """
        Long description of module's purpose
    """,

    'author': "IT Services, Corneille OMBANG",
    'website': "http://www.its-nh.com", 
    'application': False,
    'installable': True,
    'auto_install': False,
    'depends': [
        'base',
        'hr_attendance',
        'hr_zk_attendance',
        'mail',
        'contacts',
        'resource',
        'its_hr_entity',
    ],

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Human Resources',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'external_dependencies': {
        'python': [],
        'bin': [],
    },

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/resource_data_attendance_req_sub.xml',
        'views/resource_view.xml',
        'views/attendance_recap.xml',
        'wizard/wizard_attendance_recap.xml',
        'wizard/attendance_import_view.xml',
        'wizard/attendance_request_generation_view.xml',
        # 'security/ir.model.access.csv',
        'views/hr_attendance_request_view.xml',
        'views/hr_attendance_request_subject_view.xml',
        'views/menu.xml',
        # 'views/attendance_report_wizard.xml',

        # reports
        # 'report/report_menu.xml',
        # 'report/attendance_by_entity_report.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        # 'demo/demo.xml',
    ],
}
