# -*- coding: utf-8 -*-

from odoo import models, fields
from xlrd import open_workbook
import base64
import datetime
import xlrd
import pytz


def _read_element(sheet, row, col):
    try:
        value = str(sheet.cell_value(row, col)).encode('utf-8').strip()
    except:
        value = str(sheet.cell_value(row, col)).strip()
    return value or False


class AttendanceImport(models.Model):
    _name = 'hr.attendance.import'
    _description = 'Export information for the bank reconciliation'

    excel_file = fields.Binary('File')

    def validate(self):
        wb = open_workbook(file_contents=base64.b64decode(self.excel_file))
        sheet = wb.sheet_by_index(0)
        row = 1

        tz = pytz.timezone(self.env.user.tz or 'UTC')

        while row < sheet.nrows:
            id = _read_element(sheet, row, 0)
            employee = self.env['hr.employee'].search([('identification_id', '=', id)])

            start_date = _read_element(sheet, row, 1)
            bdate = float(start_date)
            y, m, d, h, mn, s = xlrd.xldate_as_tuple(bdate, wb.datemode)
            start_date = datetime.datetime(y, m, d, h, mn, s, 0, tz)

            end_date = _read_element(sheet, row, 2)
            bdate = float(end_date)
            y, m, d, h, mn, s = xlrd.xldate_as_tuple(bdate, wb.datemode)
            end_date = datetime.datetime(y, m, d, h, mn, s, 0, tz)

            # start_date = fields.Datetime.from_string(start_date)
            # end_date = fields.Datetime.from_string(end_date)
            delta = end_date - start_date
            delta_hours = delta.total_seconds() / (60*60)

            self.env['hr.attendance'].create({
                'employee_id': employee.id,
                'check_in': start_date,
                'check_out': end_date,
                'worked_hours': delta_hours,
            })

            row += 1
        return True
