from odoo import models, fields, api
from xlwt import easyxf, Workbook
import base64

try:
    from BytesIO import BytesIO
except ImportError:
    from io import BytesIO
from odoo.exceptions import UserError, Warning
import logging

_logger = logging.getLogger(__name__)


class WizardFilter(models.TransientModel):
    
    _name = 'hr.attendance.extend'

    start_date = fields.Datetime(string="Start Date", required=True)
    end_date = fields.Datetime(string="End Date", default=fields.Datetime.now, required=True)

    state = fields.Selection([('choose', 'choose'), ('get', 'get')], default='choose')
    file_name = fields.Char('File Name', size=60)
    excel_file = fields.Binary('File', )

    # @api.multi
    # def get_pdf(self):
    #     _res = self.env['hr.attendance.extend.line']
    #
    #     employee = self.env['hr.employee'].search([('entity_id', '=', self.entity_id.id)])
    #
    #     for attendance in self.env['hr.attendance'].search([('create_date', '<=', self.end_date),
    #                                                         ('create_date', '>=', self.start_date),
    #                                                         ('employee_id', 'in', employee and employee.ids or [])]):
    #         val = {
    #             'name': attendance.employee_id.name,
    #             'create_date': attendance.create_date,
    #             'check_in': attendance.check_in,
    #             'check_out': attendance.check_out,
    #             'worked_hours': attendance.worked_hours,
    #             'extend_id': self.id
    #         }
    #         # res.append(val)
    #         _res.create(val)
    #
    #     template = self.env.ref('hr_attendance_extend.template_mail_attendance_view')
    #     template.send_mail(self.id, force_send=True, raise_exception=True)
    #
    #     return True
 
    def get_excel(self):
        start_date = self.start_date
        end_date = self.end_date

        header_style = easyxf('font:height 200;pattern: pattern solid, fore_color gray25;'
                              'align: horiz center;font: color black; font:bold True;'
                              "borders: top thin,left thin,right thin,bottom thin")
        obj = self
        workbook = Workbook()
        filename = 'Attendance.xls'
        worksheet = workbook.add_sheet('Attendance')
        worksheet.write(1, 2, 'Date Range', header_style)

        worksheet.write(2, 2, 'Employe', header_style)
        worksheet.write(2, 3, 'Date', header_style)
        worksheet.write(2, 4, 'Check-In', header_style)
        worksheet.write(2, 5, 'Check-Out', header_style)
        worksheet.write(2, 6, 'Worked Hours', header_style)
        row = 5

        employee = self.env['hr.employee'].search([])
        worksheet.write(1, 3, start_date)
        worksheet.write(1, 4, end_date)

        for attendance in self.env['hr.attendance'].search([('create_date', '<=', end_date),
                                                            ('create_date', '>=', start_date),
                                                            ('employee_id', 'in', employee and employee.ids or [])]):
            workday = attendance.employee_id.resource_calendar_id

            worksheet.write(row, 2, attendance.employee_id.name)
            worksheet.write(row, 3, attendance.create_date)
            worksheet.write(row, 4, attendance.check_in)
            worksheet.write(row, 5, attendance.check_out)
            worksheet.write(row, 6, attendance.worked_hours)
            row += 1

        fp = BytesIO()
        workbook.save(fp)
        obj.write({'excel_file': base64.encodestring(fp.getvalue()), 'file_name': filename})
        fp.close()

        return {
            'view_mode': 'form',
            'res_id': obj.id,
            'res_model': 'hr.attendance.extend',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
            'target': 'new',
        }

# class ReportEntityRecap(models.AbstractModel):
#     _name = 'report.hr_attendance_extend.attendance_recap_report_view'

#     @api.model
#     def get_report_values(self, docids, data=None):
#         # entity_id = data['entity_id']
#         # start_date = data['start_date']
        # end_date = data['end_date']
        # res = []
        # _res = []

        # employee = self.env['hr.employee'].search([('entity_id', '=', entity_id)])
        
        # for attendance in self.env['hr.attendance'].search([('create_date', '<=', end_date),
        #                                                     ('create_date', '>=', start_date),
        #                                                     ('employee_id', 'in', employee and employee.ids or [])]):
            
        #    res.append({
        #         'name': attendance.employee_id.name,
        #         'create_date': attendance.create_date,
        #         'check_in' : attendance.check_in,
        #         'check_out' : attendance.check_out,
        #         'worked_hours' : attendance.worked_hours,
        #    })
        # _res.append({
        #     'entity': self.env['hr.entity'].search([('id', '=', entity_id)]).name,
        #     'start_date': start_date,
        #     'end_date': end_date,
        #     'data' : res,
        # })
           
           

        # return {
        #     'doc_ids': data['ids'],
        #     'doc_model': data['model'],
        #     'start_date': start_date,
        #     'end_date': end_date,
        #     'docs': _res,
        # }
