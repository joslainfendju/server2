from datetime import date, datetime, timedelta

from odoo import models, fields, api, _
from odoo.exceptions import UserError


class HrAttendanceRequestGeneration(models.TransientModel):
    _name = 'hr.attendance.request.gen.wizard'

    start_date = fields.Date(string=_("Start date"))
    end_date = fields.Date(string=_("End date"), default=fields.Datetime.now)
    hr_entity_id = fields.Many2one("hr.entity", string="Entity")

    @api.multi
    def generate_attendance_request(self):
        """
        Méthode invoquée pour la génération des requetes de présences.
        """
        if self.end_date < self.start_date:
            raise UserError(_('La date de début ne peut être supérieur à la date de fin.'))

        if not self.hr_entity_id:
            raise UserError(_("Veuillez renseigner l'entité"))
        new_hr_attendance_ids = []
        cur_date = self.start_date
        calendar_id = self.hr_entity_id.resource_calendar_id.id
        default_subject_att_req = self.env['hr.attendance.request.subject'].search([('key', '=', 'missing')])
        employees_entity = self.env['hr.employee'].search([('entity_id', '=', self.hr_entity_id.id)])
        hr_att_request_obj = self.env['hr.attendance.request']
        while cur_date <= self.end_date:
            day_of_week = self.get_day_of_week_f_date(cur_date)
            working_hours = self.get_working_hours_of_day_of_week(day_of_week=day_of_week, calander_id=calendar_id)
            if working_hours:
                for emp in employees_entity:
                    if not self.check_att_emp_from_date(emp_id=emp.id, date=cur_date):
                        val = self.create_val_attendance_request(emp=emp, date=cur_date,
                                                                 working_hours_day=working_hours,
                                                                 att_req_subject=default_subject_att_req)
                        new_att_req = hr_att_request_obj.create(val)
                        new_hr_attendance_ids.append(new_att_req.id)
            cur_date = self.get_next_date_of(date=cur_date)

        return self.action_view_attendance_request_list(att_request_ids=new_hr_attendance_ids)

    def get_next_date_of(self, date):
        """
        Get the next date of .
        """
        next_date = datetime.strptime(date, '%Y-%m-%d') + timedelta(days=1)
        return datetime.strftime(next_date, '%Y-%m-%d')

    def get_day_of_week_f_date(self, date):
        """
        Get day of week from date.
        """
        date_time = datetime.strptime(date, '%Y-%m-%d')
        return date_time.weekday()

    def get_working_hours_of_day_of_week(self, day_of_week, calander_id):
        """
        Get working hours of day of week in calendar template.
        """
        working_h = self.env['resource.calendar.attendance'].search(
            [('calendar_id', '=', calander_id), ('dayofweek', '=', str(day_of_week))])
        val = {}
        for h in working_h:
            if h.name.__contains__('Morning'):
                val['morning'] = [h.hour_from, h.hour_to]
            else:
                val['evining'] = [h.hour_from, h.hour_to]
        return val

    def check_att_emp_from_date(self, emp_id, date):
        """
        Check attendance of employee from date. return True if yes else False.
        """

        start_day_time = fields.Datetime.to_string(datetime.strptime(date, '%Y-%m-%d'))
        end_day_time = fields.Datetime.to_string(datetime.strptime(date + " 23:59:59", '%Y-%m-%d %H:%M:%S'))
        attendance = self.env['hr.attendance'].search(
            [('check_in', '>=', start_day_time), ('check_out', '<=', end_day_time), ('employee_id', '=', emp_id)])
        return True if attendance else False

    def create_val_attendance_request(self, emp, date, working_hours_day, att_req_subject):
        """
        Create dict val for create hr_attendance.
        """
        start_day_time = date + " " + self.get_format_time_f_decimal(working_hours_day['morning'][0])
        end_day_time = date + " " + self.get_format_time_f_decimal(working_hours_day['evining'][1])
        return {'employee_id': emp.id,
                'att_req_subject_id': att_req_subject.id,
                'entity_id': self.hr_entity_id.id,
                'name': att_req_subject.description,
                'type': 'both',
                'date_attendance_in': datetime.strptime(start_day_time, '%Y-%m-%d %H:%M:%S'),
                'date_attendance_out': datetime.strptime(end_day_time, '%Y-%m-%d %H:%M:%S')
                }

    def get_format_time_f_decimal(self, decimal_number):
        """
        Return the string time format from decimal.
        """
        entiere = str(int(decimal_number)) + ':'
        decimal = str(int(decimal_number % 1 * 60)) + ':00'
        str_h = '0' + entiere if len(entiere) == 2 else entiere
        str_h += '0' + decimal if len(decimal) == 4 else decimal
        return str_h

    @api.multi
    def action_view_attendance_request_list(self, att_request_ids):
        '''
        This function returns an action that display attendance request of given attendance request ids.
        When only one found, show the attendance request immediately.
        '''
        action = self.env.ref('its_hr_attendance_extend.hr_attendance_request_action_window')
        result = action.read()[0]

        # override the context to get rid of the default filtering on operation type
        result['context'] = {}
        # choose the view_mode accordingly
        if not att_request_ids or len(att_request_ids) > 1:
            result['domain'] = "[('id','in',%s)]" % (att_request_ids)
        elif len(att_request_ids) == 1:
            res = self.env.ref('its_hr_attendance_extend.hr_attendance_request_view_form', False)
            result['views'] = [(res and res.id or False, 'form')]
            result['res_id'] = att_request_ids[0]
        return result
