from odoo import fields, models, api


class ResourceCalendar(models.Model):
    _inherit = "resource.calendar"

    @api.multi
    def get_week_hours(self):
        for res in self:
            res.week_hours = sum([att.hour_to - att.hour_from for att in res.attendance_ids])

    week_hours = fields.Float(string='Week hours', compute=get_week_hours)
