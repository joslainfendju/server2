from odoo import fields, models, api, _


class ResourceCalendarAttendance(models.Model):
    _inherit = 'resource.calendar.attendance'

    @api.model
    def create(self, vals):
        res = super(ResourceCalendarAttendance, self).create(vals)
        print(res)
        return res

    def _get_default_attendance_ids(self):
        return [
            (0, 0, {'name': _('Monday Morning'), 'dayofweek': '0',
                    'type': 'morning', 'hour_from': 8, 'hour_to': 12}),
            (0, 0, {'name': _('Monday Evening'), 'dayofweek': '0',
                    'type': 'evening', 'hour_from': 13, 'hour_to': 17}),
            (0, 0, {'name': _('Tuesday Morning'), 'dayofweek': '1',
                    'type': 'morning', 'hour_from': 8, 'hour_to': 12}),
            (0, 0, {'name': _('Tuesday Evening'), 'dayofweek': '1',
                    'type': 'evening', 'hour_from': 13, 'hour_to': 17}),
            (0, 0, {'name': _('Wednesday Morning'), 'dayofweek': '2',
                    'type': 'morning', 'hour_from': 8, 'hour_to': 12}),
            (0, 0, {'name': _('Wednesday Evening'), 'dayofweek': '2',
                    'type': 'evening', 'hour_from': 13, 'hour_to': 17}),
            (0, 0, {'name': _('Thursday Morning'), 'dayofweek': '3',
                    'type': 'morning', 'hour_from': 8, 'hour_to': 12}),
            (0, 0, {'name': _('Thursday Evening'), 'dayofweek': '3',
                    'type': 'evening', 'hour_from': 13, 'hour_to': 17}),
            (0, 0, {'name': _('Friday Morning'), 'dayofweek': '4',
                    'type': 'morning', 'hour_from': 8, 'hour_to': 12}),
            (0, 0, {'name': _('Friday Evening'), 'dayofweek': '4',
                    'type': 'evening', 'hour_from': 13, 'hour_to': 17})
        ]

    @api.multi
    def get_part_hours(self):
        for att in self:
            att.day_hours = att.hour_to - att.hour_from

    part_hours = fields.Float(string='Day hours', compute=get_part_hours)
    type = fields.Selection([('morning', 'Morning'), ('evening', 'Evening')], default='morning')
    attendance_ids = fields.One2many(
        'resource.calendar.attendance', 'calendar_id', 'Working Time',
        copy=True,  ondelete='cascade')
