# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrAttendanceRequestObjet(models.Model):
    _name = "hr.attendance.request.subject"
    _rec_name = "key"

    key = fields.Char(string="Attendance Request Subject",required=True)
    description = fields.Text(string="Description")

    _sql_constraints = [
        ('unique_key', 'UNIQUE (key)', 'Subject must be unique!')
    ]



class HrAttendanceRequest(models.Model):
    _name = 'hr.attendance.request'

    name = fields.Char(string='Reason')
    att_req_subject_id = fields.Many2one('hr.attendance.request.subject','Subject')
    date_attendance_in = fields.Datetime()
    date_attendance_out = fields.Datetime()
    description = fields.Text()
    employee_id = fields.Many2one(
        comodel_name='hr.employee',
        string='Employee',
        default=lambda s: s.env['hr.employee'].search([('user_id', '=', s.env.user.id)]).id or False)
    attendance_id = fields.Many2one(
        comodel_name='hr.attendance',
        string='Attendance')
    type = fields.Selection(
        string='Type',
        selection=[('checkin', 'Check In'),
                   ('checkout', 'Check Out'),
                   ('both', 'both'),],
        required=True)
    state = fields.Selection(
        string='State',
        selection=[('draft', 'Draft'),
                   ('submit', 'Submit'),
                   ('validate', 'Validate'),
                   ('cancel', 'Cancelled'), ],
        required=False, default='draft')

    @api.multi
    def set_to_draft(self):
        self.write({'state': 'draft'})

    @api.multi
    def set_to_submit(self):
        self.write({'state': 'submit'})

    @api.multi
    def set_to_validate(self):
        attendance_env = self.env['hr.attendance']
        for req in self:
            val = {'employee_id': req.employee_id.id}
            if req.type == 'checkin':
                req.attendance_id.check_in = req.date_attendance_in
            elif req.type == 'checkout':
                req.attendance_id.check_out = req.date_attendance_out
            elif req.type == 'both':
                val.update({'check_in': req.date_attendance_in, 'check_out': req.date_attendance_out})
            attendance_env.create(val)
        self.write({'state': 'validate'})

    @api.multi
    def set_to_cancel(self):
        self.write({'state': 'cancel'})


