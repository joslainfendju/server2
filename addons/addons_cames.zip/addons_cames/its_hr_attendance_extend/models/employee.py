from odoo import fields, models, api
from datetime import datetime, timedelta
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT, DEFAULT_SERVER_DATETIME_FORMAT
import collections, functools, operator
import calendar


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    request_attend_ids = fields.One2many(comodel_name='hr.attendance.request', inverse_name='employee_id')

    @api.multi
    def get_employee_to_unlink(self):
        to_delete = list()
        employees = super(HrEmployee, self).get_employee_to_unlink()
        for emp in employees:
            if not len(emp.attendance_ids) and not len(emp.request_attend_ids):
                to_delete.append(emp.id)
        to_delete = self.env['hr.employee'].search([("id", 'in', to_delete)])
        return to_delete

    def findDay(self, date):
        born = date.weekday()
        return str(born)

    @api.multi
    def find_days(self, work_day_quota, date_start, date_end):
        # day_code = [self.dayNameFromWeekday(code) for code in work_day_quota.keys()]
        day_code = work_day_quota.keys()
        work_days = []
        date_start = fields.Date.from_string(date_start)
        date_end = fields.Date.from_string(date_end)
        days = (date_end - date_start).days + 1
        for day in range(days):
            date_ = date_start + timedelta(days=day)
            # print(date_)
            date_day = date_.strftime(DEFAULT_SERVER_DATE_FORMAT)
            week_day = self.findDay(date_)
            if week_day.lower() in day_code:
                work_days.append(date_day)
        return work_days

    def get_employee_absence(self, date_start, date_end):
        delay_abs = 0.00
        # print(delay_abs)

        dayofweek = list(set(self.resource_calendar_id.attendance_ids.mapped('dayofweek')))

        work_day_quota = {x: sum([y.hour_to - y.hour_from for y in self.resource_calendar_id.attendance_ids.filtered(lambda att: att.dayofweek == x)]) for x in dayofweek}
        work_day_in_period = self.find_days(work_day_quota, date_start, date_end)
        # print('Work day ::', work_day_in_period)
        for w in work_day_in_period:
            attendance_ids = self.env['hr.attendance'].search([('employee_id', '=', self.id),
                                                               ('check_in', '>=', w + ' 00:00:00'),
                                                               ('check_in', '<=', w + ' 23:59:59')])

            week_day = self.findDay(fields.Date.from_string(w))
            attendance_day = sum([x.worked_hours for x in attendance_ids])

            if attendance_day <= work_day_quota[week_day]:
                delay_abs = delay_abs + (work_day_quota[week_day] - attendance_day)

        # print("delay_abs : ", delay_abs/8)

        return delay_abs
