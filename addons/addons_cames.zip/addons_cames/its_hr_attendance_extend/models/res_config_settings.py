# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models,api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    format_hour_work = fields.Selection(
        string='Hour format',
        selection=[('12', 'AM/PM'),
                   ('24', '24H')],
        default="24",implied_group="its_hr_attendance_extend.group_generate_attendance_req"
    )
    start_hour_work = fields.Char(string='Start hour work',implied_group="its_hr_attendance_extend.group_generate_attendance_req")
    end_hour_work = fields.Char(string='End hour work',implied_group="its_hr_attendance_extend.group_generate_attendance_req")


    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(
            format_hour_work = self.env['ir.config_parameter'].sudo().get_param('its_hr_attendance_extend.format_hour_work'),
            start_hour_work = self.env['ir.config_parameter'].sudo().get_param('its_hr_attendance_extend.start_hour_work'),
            end_hour_work = self.env['ir.config_parameter'].sudo().get_param('its_hr_attendance_extend.end_hour_work'),
        )
        return res

    @api.multi
    def set_values(self):
        super(ResConfigSettings, self).set_values()
        param = self.env['ir.config_parameter'].sudo()

        format_hour_work = self.format_hour_work
        start_hour_work = self.start_hour_work
        end_hour_work = self.end_hour_work

        param.set_param('its_hr_attendance_extend.format_hour_work', format_hour_work)
        param.set_param('its_hr_attendance_extend.start_hour_work', start_hour_work)
        param.set_param('its_hr_attendance_extend.end_hour_work', end_hour_work)
