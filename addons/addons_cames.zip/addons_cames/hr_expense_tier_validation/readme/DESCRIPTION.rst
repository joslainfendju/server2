This module extends the functionality of Expense Reports to support a tier validation process.
