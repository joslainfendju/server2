from odoo import fields, models, api
import logging


class DisciplinaryFolderAbstract(models.AbstractModel):
    _name = 'report.hr_disciplinary_extend.report_disciplinary_folder'

    @api.model
    def get_report_values(self, docids, data=None):
        cr = self.env.cr

        query = "SELECT hd.name as department_name, " \
                "dc.name as discipline_reason, ac.name as action, state, " \
                "da.name as name, da.joined_date as joined_date " \
                "FROM disciplinary_action da " \
                "INNER JOIN hr_department hd ON da.department_name=hd.id " \
                "INNER JOIN discipline_category dc ON dc.id=da.discipline_reason " \
                "INNER JOIN action_category ac ON ac.id=da.action " \
                "WHERE employee_name=%s;"
        cr.execute(query, (data['employee_id'],))
        disciplines = cr.dictfetchall()

        query = "SELECT * " \
                "FROM hr_employee " \
                "WHERE id=%s;"
        cr.execute(query, (data['employee_id'],))
        employee = cr.dictfetchall()[0]
        is_data = True
        if not disciplines:
            is_data = False

        docargs = {
            'employee': employee,
            'data': data,
            'disciplines': disciplines,
            'doc_ids': data['ids'],
            'doc_model': data['model'],
            'is_data': is_data,
        }
        return docargs
