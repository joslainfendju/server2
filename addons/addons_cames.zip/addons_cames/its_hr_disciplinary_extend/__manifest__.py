# -*- coding: utf-8 -*-
{
    'name': "Disciplinary Extend",

    'summary': """
        """,

    'description': """
        
    """,

    'author': "IT services, Cedric FOWOUE",
    'website': "https://www.its-nh.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Human Resources',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': [
        'base',
        'hr_disciplinary_tracking',
        'its_hr_recruitment_extend',
    ],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'data/disciplinary_data.xml',
        'wizard/disciplinary_folder_wizard.xml',
        'data/disciplinary_category_data.xml',
        'data/disciplinary_risk_data.xml',

        # 'views/templates.xml',
        'views/hr_disciplinary_view.xml',
        'views/hr_disciplinary_risk_view.xml',
        'views/hr_employee_view.xml',
        'views/res_config_view.xml',
        'views/menu.xml',

        'report/disciplinary_folder_report.xml',
        'report/report_menu.xml',
    ],
    # only loaded in demonstration mode
    'demo': [],
}
