# -*- coding: utf-8 -*-

from odoo import models, fields, api


class HrDisciplinaryExtend(models.Model):
    _inherit = 'disciplinary.action'

    state = fields.Selection([
        ('draft', 'Draft'),
        ('invest', 'Investigation'),
        ('suspense', 'Suspension'),
        ('explain', 'Explanation Letter'),
        ('response', 'Response'),
        ('action', 'Sanction'),
        ('cancel', 'Cancelled'),

    ], default='draft', track_visibility='onchange')
    invest_result = fields.Text()
    is_terminable = fields.Boolean(string='Terminable', related='employee_name.is_terminable')

    @api.multi
    def set_to_draft(self):
        self.write({'state': 'draft'})

    @api.multi
    def set_to_invest(self):
        self.write({'state': 'invest'})

    @api.multi
    def set_to_suspense(self):
        self.write({'state': 'suspense'})

    @api.multi
    def set_to_explain(self):
        self.write({'state': 'explain'})

    @api.multi
    def set_to_response(self):
        self.write({'state': 'response'})

    @api.multi
    def set_to_action(self):
        self.write({'state': 'action'})

    @api.multi
    def set_to_cancel(self):
        self.write({'state': 'cancel'})
