from odoo import fields, models, api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    fire_quota = fields.Integer(
        string="Alert recruitment delay",
        help="Define number of days to alert about end of recruitment process",
        default=5
    )

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param('hr_disciplinary_extend.fire_quota',
                                                         self.fire_quota or 5)

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        res.update(
            fire_quota=int(self.env['ir.config_parameter'].sudo().get_param('hr_disciplinary_extend.fire_quota') or 5)
        )
        return res
