from odoo import fields, models, api


class HrDisciplinaryRisk (models.Model):
    _name = 'hr.disciplinary.risk'
    name = fields.Char('name', required=True)

    


