# -*- coding: utf-8 -*-

from . import hr_disciplinary
from . import hr_disciplinary_risk
from . import hr_employee
# from . import hr_applicant
from . import res_config_settings
