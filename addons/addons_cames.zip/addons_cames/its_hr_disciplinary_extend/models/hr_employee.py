from odoo import fields, models, api


class HrEmployee (models.Model):
    _inherit = 'hr.employee'

    category_risk_ids = fields.Many2many(comodel_name='hr.disciplinary.risk', string='Disciplinary Risks')
    is_terminable = fields.Boolean(string='Terminable', compute='_get_terminable')
    is_fire = fields.Boolean(string='Fire ?', compute='_get_fire')

    @api.multi
    def _get_fire(self):
        action = self.env.ref('hr_disciplinary_tracking.action_category_term')
        disc_action_env = self.env['disciplinary.action']
        for employee in self:
            res = disc_action_env.search([
                ('employee_name', '=', employee.id),
                ('state', '=', 'action'), ('action', '=', action.id)])
            if res:
                employee.is_fire = True
            else:
                employee.is_fire = False

    @api.multi
    def _get_terminable(self):
        disc_action_env = self.env['disciplinary.action']
        no_action = self.env.ref('hr_disciplinary_tracking.action_category_noact')
        quota = int(self.env['ir.config_parameter'].sudo().get_param('hr_disciplinary_extend.fire_quota'))
        for employee in self:
            res = disc_action_env.search_count([
                ('employee_name', '=', employee.id),
                ('state', '=', 'action'), ('action', '!=', no_action.id)])
            if res >= quota:
                employee.is_terminable = True
            else:
                employee.is_terminable = False
