from odoo import fields, models, api


class HrApplicant (models.Model):
    _inherit = 'hr.applicant'

    @api.model
    def create(self, vals):
        res = super(HrApplicant, self).create(vals)
        stage_reject = self.env.ref('hr_recruitment.stage_job10')
        employee = self.env['hr.employee'].search([('address_home_id', '=', res.partner_id.id), ('is_fire', '=', True)])
        if employee:
            res.stage_id = stage_reject
        return res
