from odoo import fields, models, api, exceptions, _
import logging


class HrApplicantRecruiter(models.TransientModel):
    _name = 'disciplinary.folder'

    employee_id = fields.Many2one(comodel_name='hr.employee', string='Employee')

    @api.multi
    def print_report(self):
        self.ensure_one()
        data = dict()
        data['ids'] = self.ids
        data['model'] = self._name
        data['employee_id'] = self.employee_id.id
        return self.env.ref('hr_disciplinary_extend.report_disciplinary_folder_print').report_action(self, data=data)
