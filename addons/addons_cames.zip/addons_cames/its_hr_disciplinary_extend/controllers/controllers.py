# -*- coding: utf-8 -*-
from odoo import http

# class HrDisciplinaryExtend(http.Controller):
#     @http.route('/hr_disciplinary_extend/hr_disciplinary_extend/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hr_disciplinary_extend/hr_disciplinary_extend/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('hr_disciplinary_extend.listing', {
#             'root': '/hr_disciplinary_extend/hr_disciplinary_extend',
#             'objects': http.request.env['hr_disciplinary_extend.hr_disciplinary_extend'].search([]),
#         })

#     @http.route('/hr_disciplinary_extend/hr_disciplinary_extend/objects/<model("hr_disciplinary_extend.hr_disciplinary_extend"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hr_disciplinary_extend.object', {
#             'object': obj
#         })