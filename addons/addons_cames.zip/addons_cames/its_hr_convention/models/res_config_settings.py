# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    convention_id = fields.Many2one('hr.convention', required=True, string='Convention', related='company_id.convention_id')

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        # ONLY FOR v11. DO NOT FORWARD-PORT
        IrDefault = self.env['ir.config_parameter'].sudo()
        convention = int(IrDefault.get_param('hr_convention.convention'))
        res.update(
            convention_id=convention,
        )
        return res

    @api.multi
    def set_values(self):
        super(ResConfigSettings, self).set_values()
        IrDefault = self.env['ir.config_parameter']
        IrDefault.sudo().set_param('hr_convention.convention', self.convention_id.id)
