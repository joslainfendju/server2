from odoo import fields, models, api,_


class PayslipCategory(models.Model):
    _name = 'hr.payslip.category'
    _description = _('Legal category use to define basic salary employee for employee')

    @api.multi
    def get_name(self):
        for category in self:
            category.name = '%s-%s' % (category.category, category.echelon)

    @api.model
    def name_search(self, name='', args=None, operator='ilike', limit=100):
        args = args or []
        domain_name = ['|', ('echelon', 'ilike', name), ('category', 'ilike', name)]
        recs = self.search(domain_name + args, limit=limit)
        return recs.name_get()

    @api.multi
    def name_get(self):
        return [(category.id, '%s-%s' % (category.category, category.echelon)) for category in self]

    # name = fields.Char(compute=get_name)
    echelon = fields.Selection([
        ('A', 'A'),
        ('B', 'B'),
        ('C', 'C'),
        ('D', 'D'),
        ('E', 'E'),
        ('F', 'F'),
    ], default='A', required=True)
    type = fields.Selection([
        ('SM', _('Monthly pay')),
        ('SH', _('Hourly pay')),
        ('SA', _('Annualy pay')),
    ], default='SM', required=True)
    category = fields.Selection([
        ('I', 'I'),
        ('II', 'II'),
        ('III', 'III'),
        ('IV', 'IV'),
        ('V', 'V'),
        ('VI', 'VI'),
        ('VII', 'VII'),
        ('VIII', 'VIII'),
        ('IX', 'IX'),
        ('X', 'X'),
        ('XI', 'XI'),
        ('XII', 'XII'),
        ('XIII', 'XIII'),
    ], default='I', required=True)
    salary = fields.Float(required=True,string=_('Salaire'))
    description = fields.Text()
    convention_id = fields.Many2one(comodel_name='hr.convention', required=True, string='Convention')
