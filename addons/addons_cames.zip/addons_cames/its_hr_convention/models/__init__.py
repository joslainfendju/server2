# -*- coding: utf-8 -*-

from . import convention
from . import hr_employee
from . import company
from . import hr_payslip_category
from . import hr_contract
from . import res_config_settings
