# -*- coding: utf-8 -*-
from odoo import http

# class HrConvention(http.Controller):
#     @http.route('/hr_convention/hr_convention/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/hr_convention/hr_convention/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('hr_convention.listing', {
#             'root': '/hr_convention/hr_convention',
#             'objects': http.request.env['hr_convention.hr_convention'].search([]),
#         })

#     @http.route('/hr_convention/hr_convention/objects/<model("hr_convention.hr_convention"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('hr_convention.object', {
#             'object': obj
#         })