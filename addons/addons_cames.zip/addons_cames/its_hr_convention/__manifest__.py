# -*- coding: utf-8 -*-
{
    'name': "HR Convention",

    'summary': """
        Manage settings of particular convention""",

    'description': """
        Manage settings of particular convention
    """,

    'author': "IT Services, Cedric FOWOUE",
    'website': "http://www.its-nh.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Human Resources',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'hr_payroll', 'hr_contract'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'data/convention_data.xml',
        'data/category_trade_data.xml',
        'views/convention_view.xml',
        'views/hr_employee_view.xml',
        'views/category_view.xml',
        'views/company_view.xml',
        'views/contract_view.xml',
        'views/menu.xml',
        'views/res_config_settings_views.xml',
    ],
    # only loaded in demonstration mode
    'demo': [

    ],
}
