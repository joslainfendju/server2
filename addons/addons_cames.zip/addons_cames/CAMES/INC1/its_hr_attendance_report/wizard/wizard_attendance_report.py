import pytz

from collections import defaultdict
# from tests.external.axis1 import array
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo import models, fields, api, _
from xlwt import easyxf, Workbook, Alignment
from datetime import datetime, timedelta
import base64

try:
    from BytesIO import BytesIO
except ImportError:
    from io import BytesIO
from odoo.exceptions import UserError, Warning
import logging
from datetime import datetime

DATE_TIME_FORMAT = '%Y-%m-%d %H:%M:%S'
DATE_FORMAT = '%Y-%m-%d'
START_TIME = "00:00:00"
END_TIME = "23:59:59"
REMARKS = {
    'arrival_or_departure_missing': _("Manuel intervention required"),
    'arrival_after_midtime': _("Manuel intervention required"),
    'departure_before_midtime': _("Manuel intervention required"),
    'break_in_passed_normal_time': _("Breaktime justification required")
}


class HrAttendanceCames(models.TransientModel):
    _name = 'wizard.attendance.report'
    entity_id = fields.Many2one('hr.entity', string="Entity", required=True)
    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", default=fields.Date.today(), required=True)

    state = fields.Selection([('choose', 'choose'), ('get', 'get')], default='choose')
    file_name = fields.Char('File Name', size=60)
    excel_file = fields.Binary('File', )

    @api.multi
    def write_title(self, worksheet, header_style, style, company_name=None):
        worksheet.write_merge(1, 1, 4, 9, company_name, style)
        worksheet.write_merge(2, 2, 4, 9, _('Employee Daily Timesheet'), style)
        worksheet.write(4, 0, _('N°'), header_style)
        worksheet.write(4, 1, _('Employee Name'), header_style)
        worksheet.write(4, 2, _('Date'), header_style)
        worksheet.write(4, 3, _('Arrival Time'), header_style)
        worksheet.write(4, 4, _('Location of the Device'), header_style)
        worksheet.write(4, 5, _('Start Break Time'), header_style)
        worksheet.write(4, 6, _('End Break Time'), header_style)
        worksheet.write(4, 7, _('Exit 1'), header_style)
        worksheet.write(4, 8, _('Return 1'), header_style)
        worksheet.write(4, 9, _('Exit 2'), header_style)
        worksheet.write(4, 10, _('Return 2'), header_style)
        worksheet.write(4, 11, _('Departure Time'), header_style)
        worksheet.write(4, 12, _('Location of the Device'), header_style)
        worksheet.write(4, 13, _('hours worked'), header_style)
        worksheet.write(4, 14, _('Total working hours for the day'), header_style)
        worksheet.write(4, 15, _('Hours late'), header_style)
        worksheet.write(4, 16, _('Overtime hours'), header_style)
        worksheet.write(4, 17, _('Hours spent in break'), header_style)
        worksheet.write(4, 18, _('Remarks'), header_style)

    @api.multi
    def write_title_attendance_log(self, worksheet, header_style, style, company_name=None):
        worksheet.write_merge(1, 1, 4, 9, company_name, style)
        worksheet.write_merge(2, 2, 4, 9, _('Attendance Log'), style)
        worksheet.write(4, 0, _('N°'), header_style)
        worksheet.write(4, 1, _('Employee Name'), header_style)
        worksheet.write(4, 2, _('Date'), header_style)
        worksheet.write(4, 3, _('Punching Time'), header_style)
        worksheet.write(4, 4, _('Punching Type'), header_style)
        worksheet.write(4, 5, _('Location of the device'), header_style)
        return

    @api.multi
    def write_one_daily_attendance(self, worksheet, position, line, number):
        worksheet.write(position, 0, number)
        for i in range(len(line)):
            if i > 0:
                worksheet.write(position, i, line[i])

    @api.multi
    def write_all_daily_attendance(self, worksheet, start_position, datas):
        number = 1
        for i in range(len(datas)):
            self.write_one_daily_attendance(worksheet, start_position, datas[i], number)
            start_position += 1
            number += 1

    @api.multi
    def print_report(self):
        entity_id = self.entity_id.id
        start_date = self.start_date + " " + START_TIME
        end_date = self.end_date + " " + END_TIME
        query = """SELECT  
                    zka.punching_time::timestamp::date as date, 
                    zka.employee_id,
                    zka.punching_time, 
                    case 
                    when zka.punch_type = '0' then 'check_in' 
                    when zka.punch_type = '1' then 'check_out'
                    when zka.punch_type = '2' then 'break_out' 
                    when zka.punch_type = '3' then 'break_in' 
                    when zka.punch_type = '4' then 'overtime_in' 
                    when zka.punch_type = '5' then 'overtime_out' end as punch_type, 
                    emp.entity_id,
                    zkmloc.location_name as location_device
                    FROM zk_machine_attendance zka, hr_employee emp,zk_machine zkm,zk_machine_location zkmloc
                    where zka.employee_id = emp.id
                    and zka.punching_time <= '%s'
                    and zka.punching_time >= '%s' and emp.entity_id = %s
                    and zka.machine_id = zkm.id
                    and zkm.location_id = zkmloc.id
                    order by date desc,employee_id,punching_time asc
                """ % (end_date, start_date, entity_id)
        header_style = easyxf('font:height 200;pattern: pattern solid, fore_color gray25;'
                              'align: horiz center;font: color black; font:bold True;'
                              "borders: top thin,left thin,right thin,bottom thin")
        style = easyxf()
        obj = self
        alignment = Alignment()
        alignment.horz = Alignment.HORZ_CENTER
        style.alignment = alignment
        workbook = Workbook()
        filename = 'attendance_summary.xls'
        worksheet = workbook.add_sheet('Attendance Analysis', cell_overwrite_ok=True)
        worksheet_logs = workbook.add_sheet('Attendance Logs', cell_overwrite_ok=True)
        self.write_title(worksheet, header_style, style, company_name=self.entity_id.name)
        self.write_title_attendance_log(worksheet_logs, header_style, style, company_name=self.entity_id.name)
        row = 5
        row_sheet_2 = 5
        grouped = defaultdict(list)
        self._cr.execute(query)
        for date, employee_id, punching_time, punch_type, entity_id, location_device in self._cr.fetchall():
            puching_time_formatted = self.datetime_formatted_to_local_tz(punching_time)
            grouped[date].append({
                'date': date,
                'punching_time': puching_time_formatted,
                'punch_type': punch_type,
                'entity_id': entity_id,
                'employee_id': employee_id,
                'location_device': location_device
            })

        daily_attendances = self.build_attendance_analysis(datas=grouped)
        daily_attendances_logs = self.build_attendance_logs(datas=grouped)

        if daily_attendances:
            daily_attendances.sort(key=lambda x: x[2], reverse=False)
        if daily_attendances_logs:
            daily_attendances_logs.sort(key=lambda x: x[2], reverse=False)
        self.write_all_daily_attendance(worksheet, row, daily_attendances)
        self.write_all_daily_attendance(worksheet_logs, row_sheet_2, daily_attendances_logs)

        fp = BytesIO()
        workbook.save(fp)
        obj.write({'excel_file': base64.encodestring(fp.getvalue()), 'file_name': filename})
        fp.close()

        return {
            'view_mode': 'form',
            'res_id': obj.id,
            'res_model': 'wizard.attendance.report',
            'view_type': 'form',
            'type': 'ir.actions.act_window',
            'target': 'new',
        }

    def build_attendance_analysis(self, datas):
        """
        Build attendances analysis.
        """
        n = 1
        res = {}
        group = defaultdict(list)
        for value in datas:
            for attendance in datas[value]:
                group[attendance["employee_id"]].append(
                    (attendance['punching_time'], attendance['punch_type'], attendance['location_device']))
            res[value] = dict(group)
            group.clear()
        daily_attendances = []
        for date in res:
            for val in res[date]:
                daily_line = self.handle_line_report(date=date, row_number=n, employee_id=val, values=res[date][val])
                daily_attendances.append(daily_line)
                n += 1
        return daily_attendances

    def build_attendance_logs(self, datas):
        """
        Attendances logs, for second worksheet.
        """
        n = 1
        daily_attendance_logs = []
        for value in datas:
            for attendance in datas[value]:
                employee_name = self.env['hr.employee'].browse([attendance['employee_id']]).name
                daily_attendance_logs.append(
                    [n, employee_name, value, attendance['punching_time'], attendance['punch_type'],
                     attendance['location_device']])
                n += 1
        return daily_attendance_logs

    def handle_line_report(self, date, row_number, employee_id, values):
        """
        Build one line of the report.
        """
        line = []
        hours_work_day_obj = self.get_hours_work_day_obj(employee_id=employee_id, date=date)
        dict_value = {'break_out': '', 'break_in': '', 'hours_spent_break': '', 'overtimes': '', 'working_hours': '',
                      'hours_late': '',
                      'arrival_time': '', 'location_device_arrival_time': '', 'departure_time': '',
                      'location_device_departure_time': '', 'total_working_hours_of_day': '', 'remark': '', 'exit1': '',
                      'return1': '', 'exit2': '', 'return2': ''}
        line.append(row_number)
        line.append(self.env['hr.employee'].search([('id', '=', employee_id)]).name)
        line.append(date)
        self.set_total_working_hours_of_day(date=date, employee_id=employee_id, dict_value=dict_value)
        self.set_arrival_departure_time(values, dict_value=dict_value, hours_work_of_day=hours_work_day_obj)
        self.set_working_hours(dict_value=dict_value)
        self.set_overtimes_hours(dict_value=dict_value)
        self.set_hours_late(date=date, employee_id=employee_id, dict_value=dict_value)
        self.set_breacks_times(list_att_emp_of_date=values, dict_value=dict_value)
        self.set_exit1_return1_times(list_att_emp_of_date=values, dict_value=dict_value)
        self.set_exit2_return2_times(list_att_emp_of_date=values, dict_value=dict_value)
        self.set_remarks(dict_value=dict_value, hours_work_of_day=hours_work_day_obj)
        line = line + [dict_value['arrival_time'], dict_value['location_device_arrival_time'], dict_value['break_out'],
                       dict_value['break_in'], dict_value['exit1'], dict_value['return1'], dict_value['exit2'],
                       dict_value['return2'],
                       dict_value['departure_time'], dict_value['location_device_departure_time'],
                       str(dict_value['working_hours']),
                       str(dict_value['total_working_hours_of_day']), str(dict_value['hours_late']),
                       str(dict_value['overtimes']), dict_value['hours_spent_break'],
                       dict_value['remark']]

        return line

    def set_arrival_departure_time(self, list_att_emp_of_date, dict_value, hours_work_of_day):
        """
        Get arrival and departure time.
        Parameters
        ---------
        list_att_emp_of_date : list of tuple. Represent the list of datetime shift.
        dict_value: dict. reference of dict value to return

        """
        if len(list_att_emp_of_date) > 1:
            arrival_datetime_and_localisation = min(list_att_emp_of_date, key=lambda x: x[0])
            dict_value['arrival_time'] = arrival_datetime_and_localisation[0]
            dict_value['location_device_arrival_time'] = arrival_datetime_and_localisation[2]
            departure_datetime_and_localisation = max(list_att_emp_of_date, key=lambda x: x[0])
            dict_value['departure_time'] = departure_datetime_and_localisation[0]
            dict_value['location_device_departure_time'] = departure_datetime_and_localisation[2]
        elif len(list_att_emp_of_date) == 1:
            if hours_work_of_day:
                midtime = hours_work_of_day[0].hour_to
                punching_hour = datetime.strptime(list_att_emp_of_date[0][0],
                                                  DEFAULT_SERVER_DATETIME_FORMAT).time().hour
                if midtime > punching_hour:
                    dict_value['arrival_time'] = list_att_emp_of_date[0][0]
                    dict_value['location_device_arrival_time'] = list_att_emp_of_date[0][2]
                else:
                    dict_value['departure_time'] = list_att_emp_of_date[0][0]
                    dict_value['location_device_departure_time'] = list_att_emp_of_date[0][2]
            else:
                dict_value['arrival_time'] = list_att_emp_of_date[0][0]
                dict_value['location_device_arrival_time'] = list_att_emp_of_date[0][2]

        return

    def set_breacks_times(self, list_att_emp_of_date, dict_value):
        """
        Set breaks times to dict_value dict.
        @param list_att_emp_of_date:List , list of tuples
        @param dict_value: dict avec keys : 'departure_time','arrival_time','break_out' and 'break_in'.
        """
        if len(list_att_emp_of_date) > 2:
            list_break_time = list(
                filter(lambda x: x[0] != dict_value['arrival_time'] and dict_value['departure_time'] != x[0],
                       list_att_emp_of_date))
            if len(list_break_time) > 1:
                dict_value['break_out'] = min(list_break_time, key=lambda x: x[0])[0]
                list_break_time = list(filter(lambda x: x[0] != dict_value['break_out'], list_break_time)) if len(
                    list_break_time) > 1 else list_break_time
                dict_value['break_in'] = min(list_break_time, key=lambda x: x[0])[0] if len(list_break_time) > 1 else \
                list_break_time[0][0]
            elif len(list_break_time) == 1:
                    dict_value['break_out'] = list_break_time[0][0]
        return

    def set_exit1_return1_times(self, list_att_emp_of_date, dict_value):
        """
        Set exit1 and return1 times to dict_value dict.
        @param list_att_emp_of_date:List , list of tuples
        @param dict_value: dict avec keys : 'departure_time','arrival_time','break_out','break_in','exit1','return1'.
        """
        if len(list_att_emp_of_date) > 2:
            list_exit_return_times = list(filter(
                lambda x: x[0] != dict_value['arrival_time'] and dict_value['departure_time'] != x[0] and dict_value[
                    'break_out'] != x[0]
                          and dict_value['break_in'] != x[0], list_att_emp_of_date))
            if len(list_exit_return_times) > 1:
                dict_value['exit1'] = min(list_exit_return_times, key=lambda x: x[0])[0]
                list_exit_return_times = list(filter(lambda x: x[0] != dict_value['exit1'], list_exit_return_times))
                dict_value['return1'] = min(list_exit_return_times, key=lambda x: x[0])[0]
            elif len(list_exit_return_times) == 1:
                dict_value['exit1'] = list_exit_return_times[0][0]
        return

    def set_exit2_return2_times(self, list_att_emp_of_date, dict_value):
        """
        Set exit2 and return2 times to dict_value dict.
        @param list_att_emp_of_date:List , list of tuples
        @param dict_value: dict avec keys : 'departure_time','arrival_time','break_out','break_in','exit1','return1','exit2' and 'return2'.
        """
        if len(list_att_emp_of_date) > 2:
            list_exit_return_times = list(filter(
                lambda x: x[0] != dict_value['arrival_time'] and dict_value['departure_time'] != x[0] and dict_value[
                    'break_out'] != x[0]
                          and dict_value['break_in'] != x[0] and
                          dict_value['exit1'] != x[0] and dict_value['return1'] != x[0], list_att_emp_of_date))
            if len(list_exit_return_times) > 1:
                dict_value['exit2'] = min(list_exit_return_times, key=lambda x: x[0])[0]
                dict_value['return2'] = max(list_exit_return_times, key=lambda x: x[0])[0]
            elif len(list_exit_return_times) == 1:
                dict_value['exit2'] = list_exit_return_times[0][0]
        return

    def set_remarks(self, dict_value, hours_work_of_day):
        """
        Set remarks to dict_value dict.
        @param dict_value: dict, with keys: 'departure_time','arrival_time','break_out' and 'break_in'.
        @param hours_work_of_day: resource.calendar.attendance
        """

        # midtime = hours_work_of_day[0].hour_to
        # midtime2 = hours_work_of_day[0].hour_from
        arrival = datetime.strptime(dict_value['arrival_time'], DEFAULT_SERVER_DATETIME_FORMAT).time().hour if \
        dict_value['arrival_time'] != '' else False
        departure = datetime.strptime(dict_value['departure_time'], DEFAULT_SERVER_DATETIME_FORMAT).time().hour if \
        dict_value['departure_time'] != '' else False
        if not arrival or not departure:
            dict_value['remark'] = REMARKS['arrival_or_departure_missing']
        elif hours_work_of_day:
            if arrival >= hours_work_of_day[0].hour_to:
                dict_value['remark'] = REMARKS['arrival_after_midtime']
            elif hours_work_of_day[1].hour_from >= departure:
                dict_value['remark'] = REMARKS['departure_before_midtime']
            elif dict_value['break_out'] or dict_value['break_in']:
                diff_departure_breakin = departure - datetime.strptime(dict_value['break_in'],
                                                                       DEFAULT_SERVER_DATETIME_FORMAT).time().hour if \
                dict_value['break_in'] != '' else 0
                diff_departure_breakout = departure - datetime.strptime(dict_value['break_out'],
                                                                        DEFAULT_SERVER_DATETIME_FORMAT).time().hour if \
                dict_value['break_out'] != '' else 0
                if 2 >= diff_departure_breakout or 2 >= diff_departure_breakin:
                    dict_value['remark'] = REMARKS['break_in_passed_normal_time']
        return

    def set_working_hours(self, dict_value):
        """
        Set working hours to dict_value.
        """
        if dict_value['arrival_time'] and dict_value['departure_time']:
            timedelta_result = datetime.strptime(dict_value['departure_time'], DEFAULT_SERVER_DATETIME_FORMAT) - \
                               datetime.strptime(dict_value['arrival_time'], DEFAULT_SERVER_DATETIME_FORMAT) if dict_value[
                                                                                                                    'departure_time'] >= \
                                                                                                                dict_value[
                                                                                                                    'arrival_time'] else ''
            if timedelta_result != '':
                dict_value['working_hours'] = timedelta_result
        return


    def set_total_working_hours_of_day(self, date, employee_id, dict_value):
        """
        Set total working hours of day to dict_value.
        """
        hours_work_day_obj = self.get_hours_work_day_obj(employee_id=employee_id, date=date)
        hours_work_day = 0
        for h in hours_work_day_obj:  # TODO, we have to correct the value of column type in resource.calendar.attendance records in database.
            hours_work_day += h.hour_to - h.hour_from
        timedelta_day = timedelta(hours=hours_work_day)
        dict_value['total_working_hours_of_day'] = timedelta_day

        return


    def set_overtimes_hours(self, dict_value):
        """
        Set overtimes to dict_value.
        """
        dict_value['overtimes'] = '00:00:00'
        if dict_value['working_hours']:
            if dict_value['total_working_hours_of_day']:
                if dict_value['working_hours'] > dict_value['total_working_hours_of_day']:
                    dict_value['overtimes'] = dict_value['working_hours'] - dict_value['total_working_hours_of_day']
            else:
                dict_value['overtimes'] = dict_value['working_hours']

        return


    def set_hours_late(self, date, employee_id, dict_value):
        """
        Set hours late to dict_value.
        """
        hours_work_day_obj = self.get_hours_work_day_obj(employee_id=employee_id, date=date)
        hours_late = 0
        hours_earlier = 0
        for h in hours_work_day_obj:  # TODO, we have to correct the value of column type in resource.calendar.attendance records in database, to use them.
            if h.name.__contains__('Morning') and dict_value['arrival_time']:
                arrival_time = datetime.strptime(dict_value['arrival_time'], DEFAULT_SERVER_DATETIME_FORMAT).time()
                arrival_time = arrival_time.hour + (arrival_time.minute / 60) + (arrival_time.second / 3600)
                hours_late = arrival_time - h.hour_from if arrival_time >= h.hour_from else 0
            elif dict_value['departure_time']:
                departure_time = datetime.strptime(dict_value['departure_time'], DEFAULT_SERVER_DATETIME_FORMAT).time()
                departure_time = departure_time.hour + (departure_time.minute / 60) + (departure_time.second / 3600)
                hours_earlier = h.hour_to - departure_time if h.hour_to >= departure_time else 0
        dict_value['hours_late'] = timedelta(hours=hours_late + hours_earlier)

        return


    def get_hours_work_day_obj(self, employee_id, date):
        """
        Get records of calendar hours work day of date.
        """
        emp = self.env['hr.employee'].browse([employee_id])
        d = str(datetime.strptime(date, DATE_FORMAT).weekday())
        hours_work_day_obj = self.env['resource.calendar.attendance'].search(
            [('calendar_id', '=', emp.resource_calendar_id.id),
             ('dayofweek', '=', d)])
        return hours_work_day_obj


    def datetime_formatted_to_local_tz(self, datetime_no_formatted):
        """
        Format datetime to local timezone of current user.
        @param datetime_no_formatted:str formatted %Y-%m-%d %H:%M:%S
        """
        current_date_time_formatted = datetime.strptime(datetime_no_formatted, '%Y-%m-%d %H:%M:%S')
        local_tz = pytz.timezone(self.env.user.partner_id.tz or 'GMT')
        local_dt = local_tz.localize(current_date_time_formatted, is_dst=True)
        local_utc = local_dt.utcoffset()
        current_date_time_formatted = local_dt + local_utc
        current_date_time_formatted = fields.Datetime.to_string(current_date_time_formatted)
        return current_date_time_formatted
