This permits to keep track of employees' length of service in number of months.
