# -*- coding: utf-8 -*-
# Part of Browseinfo. See LICENSE file for full copyright and licensing details.

from . import kra
from . import inherit_job_hr
from . import employee_kra
from . import employee_value_rating

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: