# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

{
    "name" : "HR Employee Performance report KRA/KPA in Odoo",
    "version" : "11.0.0.2",
    "category" : "Human Resources",
    'summary': 'Employee Performance Evaluation by KRA/Value Rating',
    "description": """
    
   Description of the module. 
   Employee Performance Evaluation by KRA/Value Rating
    KRA report 
    kPA
    Value Rating
    Human Resource KRA report
    Human Resource productivity report
    hr employee efficiency report
    employee efficiency report
    Performance Evaluation report
    employee Performance Evaluation report
    hr report employee efficiency report
    hr employee Performance Evaluation report
    hr employee Evaluation report
    employee Evaluation report
    hr KRA report
    kra report 
    employee efficiency report
    staff performance report
    employee productivity report
    hr staff productivity report
    staff efficiency report 
    kra hr report
    employee value rating report
    kra value rating report
    hr kra value rating report
    
    """,
    "author": "BrowseInfo",
    "website" : "www.browseinfo.in",
    "price": 000,
    "currency": 'EUR',
    "depends" : ['base','hr'],
    "data": [
        'security/ir.model.access.csv',
        'security/groups.xml',
        'wizard/wizard_kra_view.xml',
        'views/kra_views.xml',
        'views/job_inherit_views.xml',
        'views/employee_kra_view.xml',
        'views/value_rating_views.xml',
        'views/report_views.xml',
        'report/kra_report.xml',
        'report/report_views.xml',
        'report/value_report.xml',
    ],
    'qweb': [
    ],
    "auto_install": False,
    "installable": True,
    "live_test_url":'https://youtu.be/GNj-HJhoEkU',
    "images":["static/description/Banner.png"],
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
