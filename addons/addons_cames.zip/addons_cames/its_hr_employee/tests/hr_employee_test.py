from odoo.tests import common
import logging


class TestHrEmployee(common.TransactionCase):

    def setUp(self):
        super(TestHrEmployee, self).setUp()

    def test_get_employee_to_unlink(self):
        record = self.env['hr.employee'].create({'name': 'test 1'})
        # record.some_action()
        result = record.get_employee_to_unlink()
        self.assertEqual(result, 1)


