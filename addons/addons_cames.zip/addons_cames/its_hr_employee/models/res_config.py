from odoo import fields, models, api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    max_age = fields.Integer(default=60)
    delay_max_age = fields.Integer(string='Delay for notification of retirement (Day)', default=377)
    frequency_max_age = fields.Integer(string='Frequency for notification of retirement (Day)', default=3)

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        ir_config = self.env['ir.config_parameter']
        ir_config.sudo().set_param('hr_employee.max_age', self.max_age or 60)
        ir_config.sudo().set_param('hr_employee.frequency_max_age', self.frequency_max_age or 3)
        ir_config.sudo().set_param('hr_employee.delay_max_age', self.delay_max_age or 377)
        cron = self.env.ref('its_hr_employee.reminder_old_employee_cron')
        cron.interval_number = self.frequency_max_age or 3

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        ir_config = self.env['ir.config_parameter']
        res.update(
            max_age=int(ir_config.sudo().get_param('hr_employee.max_age')) or 60,
            frequency_max_age=int(ir_config.sudo().get_param('hr_employee.frequency_max_age')) or 3,
            delay_max_age=int(ir_config.sudo().get_param('hr_employee.delay_max_age')) or 377,
        )
        return res
