# -*- coding: utf-8 -*-

from . import hr_document_template
from . import hr_document
from . import hr_employee
from . import hr_employee_notif
from . import hr_emergency
from . import res_config
