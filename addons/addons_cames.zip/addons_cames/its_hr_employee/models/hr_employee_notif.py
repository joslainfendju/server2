from odoo import fields, models, api


class HrEmployeeOld(models.TransientModel):
    _name = 'hr.employee.old'
    _description = 'Description'

    name = fields.Char()
    email = fields.Char()
    line_ids = fields.One2many(comodel_name='hr.employee.old.line', inverse_name='old_id')


class HrEmployeeOldLine(models.TransientModel):
    _name = 'hr.employee.old.line'
    _description = 'Description'

    old_id = fields.Many2one(comodel_name='hr.employee.old')
    employee_id = fields.Many2one(comodel_name='hr.employee')
    duration = fields.Integer()
