from odoo import fields, models, api


class HrDocumentTemplate (models.Model):
    _name = 'hr.document.template'
    _inherit = ['mail.thread', 'resource.mixin']

    _mail_post_access = 'read'

    name = fields.Char(required=True)
    required = fields.Boolean(default=False)
    job_ids = fields.Many2many(
        comodel_name='hr.job',
        relation='hr_document_template_hr_job_rel',
        column1='hr_document_template_id',
        column2='hr_job_id',
        string="Jobs")

    # @api.multi
    # def update_required_document(self):
    #     self.ensure_one()
    #     cr = self.env.cr
    #     if not self.job_ids:
    #         return
    #     query = """SELECT id FROM hr_employee
    #                 WHERE job_id in %s"""
    #     cr.execute(query, (tuple(self.job_ids.ids),))
    #     employees = cr.dictfetchall()
    #     query = """DELETE FROM hr_document_template_employee
    #                 WHERE template_id = %s"""
    #     cr.execute(query, (self.id,))
    #     query = "INSERT INTO hr_document_template_employee (template_id, employee_id) VALUES"
    #     result = []
    #     for emp in employees:
    #         result.append(' (%d, %d)' % (self.id, emp['id']))
    #     if employees:
    #         query += ','.join(result)
    #         cr.execute(query)

    @api.model
    def create(self, vals):
        result = super(HrDocumentTemplate, self).create(vals)
        # result.update_required_document()
        return result

    @api.multi
    def write(self, vals):
        result = super(HrDocumentTemplate, self).write(vals)
        # for temp in self:
        #     temp.update_required_document()
        return result
