from odoo import fields, models, api, _, exceptions, tools
from datetime import datetime, timedelta, date
import logging


class HrEmployee (models.Model):
    _inherit = 'hr.employee'

    @api.constrains('user_id')
    def check_user(self):
        query = """SELECT user_id FROM hr_employee"""
        self.env.cr.execute(query)
        for row in self.env.cr.dictfetchall():
            if row['user_id'] is not None and int(row['user_id']) == self.env.user.id:
                return False
        return True

    @api.multi
    @api.depends('attach_ids')
    def _compute_attachments(self):
        for emp in self:
            emp.attach_count = len(emp.attach_ids)

    def mail_reminder(self):
        """Sending expiry date notification for ID and Passport"""

        now = datetime.now() + timedelta(days=1)
        date_now = now.date()
        match = self.search([])
        for i in match:
            if i.id_expiry_date:
                exp_date = fields.Date.from_string(i.id_expiry_date) - timedelta(days=14)
                if date_now >= exp_date:
                    mail_content = "  Hello  " + i.name + ",<br>Your ID " + i.identification_id + "is going to expire on " + \
                                   str(i.id_expiry_date) + ". Please renew it before expiry date"
                    main_content = {
                        'subject': _('ID-%s Expired On %s') % (i.identification_id, i.id_expiry_date),
                        'author_id': self.env.user.partner_id.id,
                        'body_html': mail_content,
                        'email_to': i.work_email,
                    }
                    self.env['mail.mail'].sudo().create(main_content).send()
        match1 = self.search([])
        for i in match1:
            if i.passport_expiry_date:
                exp_date1 = fields.Date.from_string(i.passport_expiry_date) - timedelta(days=180)
                if date_now >= exp_date1:
                    mail_content = "  Hello  " + i.name + ",<br>Your Passport " + i.passport_id + "is going to expire on " + \
                                   str(i.passport_expiry_date) + ". Please renew it before expiry date"
                    main_content = {
                        'subject': _('Passport-%s Expired On %s') % (i.passport_id, i.passport_expiry_date),
                        'author_id': self.env.user.partner_id.id,
                        'body_html': mail_content,
                        'email_to': i.work_email,
                    }
                    self.env['mail.mail'].sudo().create(main_content).send()

    def get_domain_compute_template(self, employee):
        return [('job_ids', 'in', [employee.job_id.id]), ('required', '=', True)]

    @api.multi
    def _compute_template(self):
        temp_env = self.env['hr.document.template']
        ir_env = self.env['ir.attachment']
        for emp in self:
            temps = temp_env.search(self.get_domain_compute_template(emp))
            temp_ids = temps and [x.id for x in temps] or []

            attachs = ir_env.search([('res_id', 'in', [emp.id])])
            attach_ids = attachs and [x.document_template_id.id for x in attachs] or []

            temp_ids = set(temp_ids)
            attach_ids = set(attach_ids)
            res = temp_ids.difference(attach_ids)
            res = list(res)
            res = temp_env.search([('id', 'in', res)])
            res = res and '||'.join([x.name for x in res]) or ''
            emp.temp_ids = res

    ssnid = fields.Char('ID Card No', help='National ID Number', groups="hr.group_hr_user", track_visibility='always')
    sinid = fields.Char('SIN No', help='Social Insurance Number', groups="hr.group_hr_user", track_visibility='always')
    expiry_date_ssnid = fields.Date('Date of ID Card No', track_visibility='always')
    key_sinid = fields.Char('Key SIN', track_visibility='always', help='Key of Social Insurance Number')
    identification_id = fields.Char(string='Identification No', groups="hr.group_hr_user", track_visibility='always')
    passport_id = fields.Char('Passport No', groups="hr.group_hr_user", track_visibility='always')
    passport_expiry_date = fields.Date(string='Passport Expiry Date', help='Expiry date of Passport ID', track_visibility='always')
    permit_no = fields.Char('Work Permit No', groups="hr.group_hr_user", track_visibility='always')
    visa_no = fields.Char('Visa No', groups="hr.group_hr_user", track_visibility='always')
    visa_expire = fields.Date('Visa Expire Date', groups="hr.group_hr_user", track_visibility='always')
    job_id = fields.Many2one('hr.job', 'Job Position', track_visibility='always')
    department_id = fields.Many2one('hr.department', 'Department', track_visibility='always')
    parent_id = fields.Many2one('hr.employee', 'Manager', track_visibility='always')
    personal_mobile = fields.Char(string='Mobile', related='address_home_id.mobile', store=True)
    emergency_ids = fields.One2many(
        comodel_name='hr.emergency.contact',
        inverse_name='employee_id',
        string='Emergency Contact'
    )
    joining_date = fields.Date(string='Joining Date')
    attach_ids = fields.One2many(
        comodel_name='ir.attachment',
        inverse_name='employee_id',
        string='Attachments'
    )
    attach_count = fields.Integer(string='Attach number', compute='_compute_attachments')
    rib = fields.Char('Bank Identification Statement', track_visibility='always')
    # bic = fields.Char('Bank Identifier Code')
    bank_code = fields.Char('Bank Code', track_visibility='always')
    # iban = fields.Char('International Banking Account Number')
    account_number = fields.Char('Account Number', track_visibility='always')
    swift = fields.Char('Swift Code', track_visibility='always')
    counter_code = fields.Char('Counter Code', track_visibility='always')
    rib_key = fields.Char('RIB Key', track_visibility='always')
    temp_ids = fields.Char(compute=_compute_template)
    tax_registration_number = fields.Char('Tax Registration Number', track_visibility='always')

    @api.multi
    def show_attachments(self):
        self.ensure_one()
        return {
            'name': _('List of attachments'),
            'type': 'ir.actions.act_window',
            'res_model': 'ir.attachment',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'domain': [('res_id', '=', self.id), ('res_model', '=', 'hr.employee')]
        }

    @api.multi
    def get_employee_to_unlink(self):
        to_delete = list()
        for emp in self:
            if not emp.attach_count and emp.employee_skill_ids \
                    and not emp.emergency_ids and not emp.fam_children_ids:
                to_delete.append(emp.id)
        to_delete = self.env['hr.employee'].search([("id", 'in', to_delete)])
        return to_delete

    @api.multi
    def unlink(self):
        to_delete = self.get_employee_to_unlink()
        if to_delete:
            return super(HrEmployee, to_delete).unlink()
        return True

    @api.multi
    def add_document(self):
        self.ensure_one()
        context = self.env.context.copy()
        view_id = self.env.ref('hr_employee.document_wizard_form_view')
        res = self.env['hr.document.wizard'].create({'employee_id': self.id})
        return {
            'name': _('Add document'),
            'type': 'ir.actions.act_window',
            'res_model': 'hr.document.wizard',
            'target': 'new',
            'view_type': 'form',
            'view_mode': 'form',
            'views': [(view_id.id, 'form')],
            'res_id': res.id,
            'nodestroy': True,
            'domain': [],
            'context': context
        }

    # @api.multi
    # def update_required_document(self):
    #     self.ensure_one()
    #     cr = self.env.cr
    #     query_attachment_emp = """SELECT template_id FROM ir_attachment
    #                 WHERE res_model = 'hr.employee'
    #                 AND res_id = %s"""
    #     cr.execute(query_attachment_emp, (self.id,))
    #     attachments = cr.dictfetchall()
    #
    #     query_required_docs_job_emp = """SELECT doc.id as id
    #                 FROM hr_document_template_hr_job_rel as docrel
    #                 JOIN hr_document_template as doc
    #                 ON doc.id = docrel.hr_document_template_id
    #                 WHERE docrel.hr_job_id = %s
    #                 AND doc.required = true"""
    #     if not self.job_id:
    #         raise exceptions.Warning('You must define an job for this employee')
    #     cr.execute(query_required_docs_job_emp, (self.job_id.id,))
    #     required_docs_job_emp = cr.dictfetchall()
    #
    #     attach_ids = [x['template_id'] for x in attachments]
    #     val_attchs = set(attach_ids)
    #     required_ids = [x['id'] for x in required_docs_job_emp]
    #     val_required = set(required_ids)
    #
    #     vals = list(val_required.difference(val_attchs))
    #
    #     query = "DELETE FROM hr_document_template_employee WHERE employee_id = %s"
    #     cr.execute(query, (self.id,))
    #     query = "INSERT INTO hr_document_template_employee (template_id, employee_id) VALUES"
    #     result = []
    #     for val in vals:
    #         result.append(' (%d, %d)' % (self.id, val))
    #     query += ','.join(result)
    #     if vals:
    #         cr.execute(query)

    @api.multi
    def create_user(self):
        self.ensure_one()
        if not self.work_email:
            raise exceptions.Warning(_('There\'s not work email define for this employee. Please check an retry. '))
        user = self.env['res.users'].sudo().search([('login', '=', self.work_email)])
        if not user:
            vals = dict(login=self.work_email, name=self.name, notification_type='email',  password='password')
            user = self.env['res.users'].sudo().create(vals)
        user.partner_id.email = self.work_email
        self.user_id = user

    @api.model
    def create(self, vals):
        vals['identification_id'] = self.env['ir.sequence'].next_by_code('hr.employee')
        emp = super(HrEmployee, self).create(vals)
        # emp.update_required_document()
        if emp.work_email and not emp.user_id:
            emp.create_user()
        return emp

    @api.multi
    def write(self, vals):
        res = super(HrEmployee, self).write(vals)
        for emp in self:
            if not emp.user_id and emp.work_email:
                emp.create_user()
        return res

    # def get_query_recrutment_to_close(self, delay):
    #     return """SELECT id FROM hr_recruitment_request
    #                 WHERE (CURRENT_DATE :: date - start_date_recruitment_rq :: date )>=%s;""" (delay, )

    def get_query_doc_expired(self, delay):
        # return """SELECT *
        #     FROM hr_employee
        #     WHERE (CURRENT_DATE :: date - passport_expiry_date :: date) >= '%s'""" % (delay,)
        return """SELECT *
                    FROM hr_employee """

    def get_query_doc_cni_expired(self, delay):
        return """SELECT *
            FROM hr_employee
            WHERE (expiry_date_ssnid :: date - CURRENT_DATE :: date) <= '%s'""" % (delay,)

    def get_query_doc_passport_expired(self, delay):
        return """SELECT *
            FROM hr_employee
            WHERE (passport_expiry_date :: date - CURRENT_DATE :: date) <= '%s'""" % (delay,)

    def get_query_doc_visa_expired(self, delay):
        return """SELECT *
            FROM hr_employee
            WHERE (visa_expire :: date - CURRENT_DATE :: date) <= '%s'""" % (delay,)

    @api.model
    def mail_old_employee(self):
        template = self.env.ref('hr_employee.email_template_old_employee')
        cr = self.env.cr
        max_age = int(self.env['ir.config_parameter'].sudo().get_param('hr_employee.max_age'))
        delay_max_age = int(self.env['ir.config_parameter'].sudo().get_param('hr_employee.delay_max_age'))
        query = """SELECT id, name, (%s - (CURRENT_DATE - birthday)) as duration
        FROM hr_employee WHERE (date_part('YEAR', AGE(birthday)) + %s) >= %s;""" % (max_age, delay_max_age/365.0, max_age)
        cr.execute(query)
        rq_exp = cr.dictfetchall()
        employees = [(0, 0, {'employee_id': rq['id'], 'duration': rq['duration']}) for rq in rq_exp]

        email = ','.join([x.partner_id.email for x in self.env.ref('hr.group_hr_user').sudo().users])
        value = {
            "name": "Old employee %ss" % (fields.date.today(),),
            "line_ids": employees,
            "email": email,
        }
        old_object = self.env['hr.employee.old'].create(value)
        template.send_mail(old_object.id, force_send=True, raise_exception=True)
