from odoo import fields, models, api, _, exceptions
from datetime import datetime, timedelta


class HrEmployee (models.Model):
    _inherit = 'hr.department'


