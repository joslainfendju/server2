from odoo import fields, models, api, exceptions, _

"""
    class use to manage upload file
    inherit to specify type of document upload in hr purpose
"""


class IrAttachment (models.Model):
    _inherit = 'ir.attachment'

    @api.multi
    @api.depends('res_id')
    def _get_employee(self):
        employee_env = self.env['hr.employee']
        for attach in self:
            if attach.res_model == 'hr.employee':
                attach.employee_id = employee_env.search([('id', '=', attach.res_id)])
                attach.user_id = attach.employee_id.user_id

    document_template_id = fields.Many2one(comodel_name='hr.document.template', string='Type of document', store=True)
    is_required = fields.Boolean(string='Is Required ?', related='document_template_id.required')
    employee_id = fields.Many2one(comodel_name='hr.employee', string="Employee", compute='_get_employee', store=True)
    user_id = fields.Many2one(comodel_name='res.users', string="user", compute='_get_employee', store=True)
    job_id = fields.Many2one(comodel_name='hr.job', string="Job", related='employee_id.job_id')

    @api.onchange('employee_id')
    def onchange_employee(self):
        self.ensure_one()
        self.res_model = 'hr.employee'
        self.res_id = self.employee_id.id

    # @api.multi
    # def update_required_document(self):
    #     self.ensure_one()
    #     cr = self.env.cr
    #     employee_env = self.env['hr.employee']
    #     if self.res_model == 'hr.employee':
    #         emp = employee_env.search([('id', '=', self.res_id)])
    #         if not emp.job_id:
    #             raise exceptions.Warning(_('Please set job for this employee'))
    #         query_attachment_emp = """SELECT template_id FROM ir_attachment
    #                     WHERE res_model = 'hr.employee'
    #                     AND res_id = %s"""
    #         cr.execute(query_attachment_emp, (emp.id,))
    #         attachments = cr.dictfetchall()
    #
    #         query_required_docs_job_emp = """SELECT doc.id as id
    #                     FROM hr_document_template_hr_job_rel as docrel
    #                     JOIN hr_document_template as doc
    #                     ON doc.id = docrel.hr_document_template_id
    #                     WHERE docrel.hr_job_id = %s
    #                     AND doc.required = true"""
    #         cr.execute(query_required_docs_job_emp, (emp.job_id.id,))
    #         required_docs_job_emp = cr.dictfetchall()
    #
    #         attach_ids = [x['template_id'] for x in attachments]
    #         val_attchs = set(attach_ids)
    #         required_ids = [x['id'] for x in required_docs_job_emp]
    #         val_required = set(required_ids)
    #
    #         vals = list(val_required.difference(val_attchs))
    #
    #         query = "DELETE FROM hr_document_template_employee WHERE employee_id = %s"
    #         cr.execute(query, (emp.id,))
    #         query = "INSERT INTO hr_document_template_employee (template_id, employee_id) VALUES"
    #         result = []
    #         for val in vals:
    #             result.append(' (%d, %d)' % (emp.id, val))
    #         query += ','.join(result)
    #         if vals:
    #             cr.execute(query)

    @api.model
    def create(self, vals):
        attach = super(IrAttachment, self).create(vals)
        # attach.update_required_document()
        return attach
