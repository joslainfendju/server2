# -*- coding: utf-8 -*-

import json
import logging
from datetime import datetime
from lxml import etree

from odoo import api, fields, models, _
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class Grievance(models.Model):
    _name = "hr.grievance"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nature of Grievance', required=True)
    sequence = fields.Char(string='Number')
    employee_id = fields.Many2one(
        'hr.employee', string='Employee Aggrieved', readonly=False)
    description = fields.Text(string='Aggrieved Description')
    against = fields.Boolean(string="Against procedure/policy")
    against_id = fields.Many2one(
        'hr.employee', string='Employee Against')
    response = fields.Text(string='Against Description')
    manager_id = fields.Many2one('hr.employee', string='Department Head')
    policy = fields.Char(string="Procedure or Policy")
    resolution = fields.Text()
    turnaround = fields.Float()
    legal_dispute = fields.Boolean(string='With Legal institute')
    attorney = fields.Char(string='Attorney')
    department_id = fields.Many2one(
        'hr.department', string='Employee Department', related="employee_id.department_id")
    state = fields.Selection(
        [('draft', 'Draft'), ('invest', 'Invest'), ('progress', 'Being processed'),
         ('close', 'Out come')], default='draft')

    @api.model
    def create(self, vals):
        vals['sequence'] = self.env['ir.sequence'].next_by_code(
            'hr.grievance')
        return super(Grievance, self).create(vals)

    def set_draft(self):
        return self.write({'state': 'draft'})

    def set_invest(self):
        return self.write({'state': 'invest'})

    def set_progress(self):
        return self.write({'state': 'progress'})

    def set_close(self):
        return self.write({'state': 'close'})
