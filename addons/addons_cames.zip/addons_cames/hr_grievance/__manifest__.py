# -*- coding: utf-8 -*-
###############################################################################
# Author      : Kanak Infosystems LLP. (<http://kanakinfosystems.com/>)
# Copyright(c): 2012-Present Kanak Infosystems LLP.
# All Rights Reserved.
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <http://kanakinfosystems.com/license>
###############################################################################

{
    'name': 'Grievance',
    'summary': 'It is a Grievance form',
    'version': '1.0',
    'category': 'Grievance',
    'description': """
We provide a solution, which helps to achieve complete integration of business functions cost-effectively.
The features gives insight into operations requirements, thus allowing them visibility to assess capacity options,
boost supply chain efficiencies, etc.
==================================================================================================================
Key Features:
    * Notification At Every State, When application moves from one state to another state, an email & notification is sent to the approver.
    * Security For All Users, an employee can't see the other employee complaint they registered.
    * Officer and manager can only see those employee complaints which are there employee's or which are under them.
    * Line Manager, Department Head get email & notification when a complaint is filed.
    * Only those line manager and Department Head can approve or reject the complaint whom the complaint has been sent.
    """,
    'depends': ['base', 'hr'],
    'author': 'Cedric FOWOUE.',
    'images': ['static/description/banner.png'],
    'license': 'OPL-1',
    'website': '',
    'data': [
        'views/grievance.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/mail_template.xml',
        'views/sequence.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
