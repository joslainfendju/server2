# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Email Handle',
    'category': 'Human Resources',
    'version': '1.0',
    'author': 'IT Services, Cedric FOWOUE',
    'summary': 'Extend features of recruitment process',
    'description': "",
    'depends': [
        'base',
        'mail',
    ],
    'data': [
        'security/ir.model.access.csv',
    ],
    'demo': [
        # 'data/hr_job_demo.xml',
    ],
    'installable': True,
}
