from odoo import fields, models, api
from odoo.tools import email_split
from datetime import timedelta, datetime
import re


class EmailHandle(models.Model):
    _name = 'hr.email.handle'
    _inherit = ["mail.alias.mixin", 'mail.thread', 'resource.mixin']

    name = fields.Char()

    @api.model
    def message_new(self, msg_dict, custom_values=None):
        print("BEGIN")
