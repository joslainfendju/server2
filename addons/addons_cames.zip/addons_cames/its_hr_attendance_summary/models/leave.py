from datetime import timedelta,datetime

from odoo import fields, models, api, _
from odoo.exceptions import UserError
import datetime
from odoo.addons.its_hr_attendance_summary.utils.weekend_manager import WeekendManager,WEEKENDS, DATE_FORMAT, _SATURDAY,DATE_TIME_FORMAT,_SUNDAY


class Leave(models.Model):
    _inherit = 'hr.holidays'

    weekend_ids = fields.Many2many('its.hr.weekend', string='Weekends include on the holidays',compute='_get_weekends',store=True)
    # weekend_ids = fields.Many2many('its.hr.weekend', string='Weekends include on the holidays')
    # date_to = fields.Datetime(string="End Date", store=True,
    #                           compute='_get_end_date', inverse='_set_end_date')
    date_to = fields.Datetime(string="End Date", store=True,
                              compute='_get_end_date')

    date_from = fields.Datetime(string="End Date",copy=False, readonly=True,
                                                                   states={'draft': [('readonly', False)], 'confirm': [('readonly', False)]},)

    duration = fields.Float('Duration',digits=(6, 0))

    number_of_days_temp = fields.Float(
        'Allocation', copy=False, readonly=True,store=True,
        states={'draft': [('readonly', False)], 'confirm': [('readonly', False)]},
        help='Number of days of the leave request according to your working schedule.', compute='_get_number_of_days_temp')

    # @api.constrains('date_from', 'date_to', 'weekend_ids')
    # def _check_is_wekend_included_in_holidays(self):
    #     for day in self.weekend_ids:
    #         if day.date > self.date_to or day.date < self.date_from:
    #             raise UserError(_('The weekend must be include in the leave interval'))

    @api.one
    def update_weekends(self):
        if self.holiday_status_id and self.holiday_status_id.consider_weekend_as_presence:
            weekend_obj = self.env['its.hr.weekend']
            weekends = WeekendManager.weekend_between_two_date(self.date_from, self.date_to)
            created_ids = []
            for weekend in weekends:
                if self.holiday_status_id.no_consider_saturday_as_weekend and weekend.weekday() == _SATURDAY:
                    continue
                weekend_as_string = weekend.strftime(DATE_FORMAT)
                sys_weekends = weekend_obj.search([('date', '=', weekend_as_string)])
                if not sys_weekends or not sys_weekends.ids:
                    week_id = weekend_obj.create({
                        'date': weekend_as_string
                    })
                    created_ids += [week_id.id]
                else:
                    created_ids += sys_weekends.ids
            for id in created_ids:
                self.write({'weekend_ids': [(4, id)]})
        else:
            self.write({'weekend_ids': [(5,)]})

    @api.multi
    def write(self, vals):
        res = super(Leave, self).write(vals)
        # if 'date_from' in vals or 'date_to' in vals:
        #     for record in self:
        #         record.update_weekends()
        return res

    @api.model
    def create(self, values):
        res = super(Leave, self).create(values)
        if 'date_from' in values:
            res.write({'date_from': values['date_from']})
        return res

    def _get_number_of_days(self, date_from, date_to, employee_id):
        res = super(Leave, self)._get_number_of_days(date_from, date_to, employee_id)
        if self.holiday_status_id.no_consider_saturday_as_weekend:
            weekends = WeekendManager.weekend_between_two_date(self.date_from, self.date_to)
            for week in weekends:
                if week.weekday() == 5:
                    res += 1
        return res

    @api.one
    @api.depends('duration')
    def _get_number_of_days_temp(self):
        if self.duration:
            self.number_of_days_temp = self.duration

    @api.one
    @api.depends('date_to','date_from')
    def _get_weekends(self):
        """
        Set the weekends days.
        """
        for r in self:
            if not self.date_from or not self.date_to:
                continue
            if r.holiday_status_id.consider_weekend_as_presence:# compter les weekends
                weekends = WeekendManager.weekend_between_two_date(self.date_from, self.date_to)
                sat = []
                sun = []
                for week in weekends:
                    if week.weekday() == 5:
                        sat.append((0,0,{'date':datetime.datetime.strftime(week,'%Y-%m-%d')}))
                    else:
                        sun.append((0,0,{'date':datetime.datetime.strftime(week,'%Y-%m-%d')}))
                if r.holiday_status_id.no_consider_saturday_as_weekend:
                    r.weekend_ids = sun
                else:
                    r.weekend_ids = sun + sat
        return

    @api.one
    @api.depends('date_from', 'duration','holiday_status_id')
    def _get_end_date(self):
        """
        Determine le date de fin de période.
        """
        for r in self:
            if not (self.date_from and self.holiday_status_id):
                continue
            jrs_c = 0
            cur_date = datetime.datetime.strptime(self.date_from,'%Y-%m-%d %H:%M:%S')
            while self.duration - 1 > jrs_c:
                cur_date = cur_date + timedelta(days=1,seconds=-1)
                if self.is_free_day_in_relation_to_holiday_status(cur_date):
                    jrs_c +=1


            if jrs_c + 1 > self.duration - 1:
                self.date_to = datetime.datetime.strftime(cur_date,'%Y-%m-%d %H:%M:%S')
            else:
                self.date_to = self.date_from
        return


    def is_free_day_in_relation_to_holiday_status(self,date_time):
        """

        Vérifit si la date en parametre peut etre consideré comme un jour de congé par rapport au type de congé.
        """
        res = True

        if self.holiday_status_id.exclude_public_holidays or self.holiday_status_id.consider_weekend_as_presence:
            public_holidays = self.env['hr.holidays.public.line'].search([('year_id.year','=',date_time.year),('date','=',date_time.date().__str__())])
            if date_time.weekday() == _SATURDAY and not self.holiday_status_id.no_consider_saturday_as_weekend:
                res = False
            elif date_time.weekday() == _SUNDAY and self.holiday_status_id.consider_weekend_as_presence:
                res = False
            elif public_holidays and self.holiday_status_id.exclude_public_holidays:
                res = False
        return res


    # def control_end_date_holiday(self):
    #     """
    #     Controle la valeur de la date de fin en décalant si necessaire.
    #     Le controle est fait lorsque la date de fin est soit samedi, soit dimanche soit un jour férié.
    #     """
    #     if self.date_to:
    #         hr_holidays_pub_line_obj = self.env['hr.holidays.public.line']
    #         end = datetime.datetime.strptime(self.date_to,DATE_TIME_FORMAT)
    #         public_holidays = hr_holidays_pub_line_obj.search([('year_id.year','=',end.year),('date','=',end.date().__str__())])
    #         if end.weekday() in WEEKENDS or public_holidays:
    #             if not self.holiday_status_id.exclude_public_holidays or self.holiday_status_id.consider_weekend_as_presence:
    #                 next = True
    #                 while next:
    #                     if end.weekday() in WEEKENDS and not self.holiday_status_id.consider_weekend_as_presence:
    #                         next = False
    #                     elif end.weekday() == _SATURDAY and self.holiday_status_id.no_consider_saturday_as_weekend:
    #                         next = False
    #                     elif end.weekday() == _SUNDAY and not self.holiday_status_id.consider_weekend_as_presence:
    #                         next = False
    #                     elif public_holidays and  not self.holiday_status_id.exclude_public_holidays:
    #                         next = False
    #                     elif end.weekday() not in WEEKENDS and not public_holidays:
    #                         next = False
    #
    #                     if next:
    #                         end = end + timedelta(days=1)
    #                         public_holidays = hr_holidays_pub_line_obj.search([('year_id.year','=',end.year),('date','=',end.date().__str__())])
    #
    #                 self.date_to = datetime.datetime.strftime(end,DATE_TIME_FORMAT)
    #     return




    # def _set_end_date(self):
    #     for r in self:
    #         if not (r.date_from and r.date_to):
    #             continue
    #
    #         # Compute the difference between dates, but: Friday - Monday = 4 days,
    #         # so add one day to get 5 days instead
    #         start_date = fields.Datetime.from_string(r.date_from)
    #         end_date = fields.Datetime.from_string(r.date_to)
    #         r.duration = (end_date - start_date).days + 1

    def get_public_holidays_f_period(self,start_date,end_date):
        """
        Get public holidays from period.
        """
        if not start_date or not end_date: return True
        public_holidays_line_obj = self.env['hr.holidays.public.line']
        start = datetime.datetime.strptime(start_date, '%Y-%m-%d %H:%M:%S')
        end = datetime.datetime.strptime(end_date, '%Y-%m-%d %H:%M:%S')
        res = []
        for i in range((end - start).days+1):
            current_date = start + datetime.timedelta(days=i + 1)
            d = public_holidays_line_obj.search([('year_id.year','=',current_date.year),('date','=',current_date.date().__str__())])
            if d:
                    res.append(d)

        return res

    # def get_holidays_without_public_holiday_f_period(self,start_date,end_date):
    #     """
    #     Get public holidays from period, depends of type of holiday.
    #     Exclud saturday and sunday days depends of holiday type configuration.
    #     """
    #     list_public_holiday = self.get_public_holidays_f_period(start_date=start_date,end_date=end_date)
    #     res =[]
    #     if list_public_holiday:
    #         if self.holiday_status_id.consider_weekend_as_presence:
    #             list_pub = [h.date for h in list_public_holiday]
    #             if self.holiday_status_id.no_consider_saturday_as_weekend:
    #                 res = WeekendManager.exclud_sunday_days_f_period(list_date=list_pub)
    #             else:
    #                 res = WeekendManager.exclud_sunday_days_f_period(list_date=list_pub,with_saturday=False)
    #
    #     return res

    # def get_public_holidays_f_period_depends_of_leave_type(self,start_date,end_date):
    #     """
    #     Retourner la liste des jours fériés de la période en respectant la configuration du type de congé.
    #     Pour les fériés correspondant à Samedi ou dimanche, la règle suivante est appliquée:
    #         - le type de congé, considére Samedi et Dimanche comme des weekends: alors le férié ne sera pas retourné
    #         - le type de congé, considére Dimanche uniquement comme weekend : alors les Samedi fériés sont retournés
    #         - le type de congé, ne considére pas Samedi et Dimanche comme des weekends : le férié est retourné
    #         - le type de congé, ne considére pas les jours fériés: les fériés ne sont pas retournés.
    #     """
    #     list_public_holiday = self.get_public_holidays_f_period(start_date=start_date,end_date=end_date)
    #     res =[]
    #     if list_public_holiday:
    #         if not self.holiday_status_id.exclude_public_holidays:
    #             res = [h.date for h in list_public_holiday]
    #             if self.holiday_status_id.consider_weekend_as_presence:
    #                 if self.holiday_status_id.no_consider_saturday_as_weekend:
    #                     res = WeekendManager.exclud_sun_sat_days_f_list_of_date(list_date=res,with_saturday=False)
    #                 else:
    #                     res = WeekendManager.exclud_sun_sat_days_f_list_of_date(list_date=res)
    #
    #     return res


    # def is_weekend_of_holiday(self,day):
    #     """
    #     @param day: string format datetime
    #     Pre-requis : day is Saturday or Sunday, and includ in holidays instance.
    #     Check if day is a weekend according to the holiday.
    #     """
    #     res = False
    #     if WeekendManager.check_weekend_f_date(day):# is saturday or sunday day
    #         if self.date_to >= day and self.date_from <= day:
    #             if self.holiday_status_id.consider_weekend_as_presence:
    #                 res = True
    #                 d = datetime.datetime.strptime(day, DATE_TIME_FORMAT)
    #                 if d.weekday() == _SATURDAY and self.holiday_status_id.no_consider_saturday_as_weekend:
    #                     res = False
    #     return res




