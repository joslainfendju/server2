from odoo import fields, models, api, _
from datetime import datetime
from odoo.exceptions import UserError

_SATURDAY = 5
_SUNDAY = 6

WEEKENDS = [_SATURDAY, _SUNDAY]


class HrWeekend(models.Model):
    _name = 'its.hr.weekend'

    date = fields.Date("Day of the weekend", required=True)

    @api.constrains('date')
    def _check_is_weekend(self):
        date_format = '%Y-%m-%d'
        real_date = datetime.strptime(self.date, date_format)
        if real_date.weekday() not in WEEKENDS:
            raise UserError(_(' This selected day is not a weekend'))
