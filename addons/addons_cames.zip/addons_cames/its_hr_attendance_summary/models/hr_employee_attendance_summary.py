from odoo import fields, models, api, _
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from datetime import datetime, timedelta
from odoo.addons.its_hr_attendance_summary.utils.weekend_manager import WeekendManager, DATE_FORMAT, _SATURDAY

DATE_FORMAT = '%Y-%m-%d'
START_TIME = "00:00:00"
END_TIME = "23:59:59"


class HrEmployeeAttendanceSummary(models.Model):
    _name = 'hr.employee.attendance.summary'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']
    _description = _("Employee Attendance summary")
    _order = 'id desc'

    # meta data
    name = fields.Char(string=_('Number'), required=True, copy=False, default='/', readonly=True)
    start_date = fields.Date(string=_("Start Date"), required=True)
    end_date = fields.Date(string=_("End Date"), default=fields.Date.today(), required=True)
    summary_id = fields.Many2one(comodel_name='hr.entity.attendance.summary', string=_('Parent Summary'))
    summary_m_id = fields.Many2one(comodel_name='hr.entity.attendance.summary', string='Parent Summary')
    employee_id = fields.Many2one(comodel_name='hr.employee', string=_('Employee'))
    contract_id = fields.Many2one('hr.contract', string=_('Current Contract'), compute='_get_current_contract',
                                  readonly=True)
    contract_date_end = fields.Datetime(string=_("Contract end Date"), default=fields.Datetime.now, store=True,
                                        compute='_get_current_contract')

    # global periods
    total_days = fields.Float(string=_("Total Period days"), compute='_compute_total_days', store=True)
    work_hours_per_days = fields.Float(string=_("Work hour per day of work"), compute='_compute_total_days')
    total_weekend_days = fields.Float(string=_("Total Weekend days"), compute='_update_weekends', store=True)
    total_weekend_days_m = fields.Float(string=_("Total Weekend days"))

    # late and earlier exit
    total_earlier_exit_hours = fields.Float(string=_("Total earlier exit hours"),
                                            compute='_compute_late_and_earli_values', store=True)
    total_earlier_exit_hours_m = fields.Float(string=_("Total earlier exit hours"))
    total_earlier_exit_days = fields.Float(string=_("Total earlier exit days"),
                                           compute='_compute_late_and_earli_values', store=True)
    total_earlier_exit_days_m = fields.Float(string=_("Total earlier exit days"))
    total_late_hours = fields.Float(string=_("Total late hours"), compute='_compute_late_and_earli_values', store=True)
    total_late_hours_m = fields.Float(string=_("Total late hours"))
    total_late_days = fields.Float(string=_("Total late days"), compute='_compute_late_and_earli_values', store=True)
    total_late_days_m = fields.Float(string=_("Total late days"))

    # absence and presence
    total_presence_days = fields.Float(string=_("Total Presence days"), compute='_compute_absence_presences_values',
                                       store=True)
    total_presence_days_m = fields.Float(string=_("Total Presence days"))
    total_absences_days = fields.Float(string=_("Total Absence days"), compute='_compute_absence_presences_values',
                                       store=True)
    total_absences_days_m = fields.Float(string=_("Total Absence days"))
    total_justified_absences_days = fields.Float(string=_("Total Justified Absence days"),
                                                 compute='_compute_holidays',
                                                 store=True)
    total_justified_absences_days_m = fields.Float(string=_("Total Justified Absence days"))
    hr_holidays_ids = fields.One2many('hr.holidays',
                                      string=_('Holidays on period'),
                                      compute='_compute_holidays')
    justified_absence_ids = fields.One2many('hr.holidays',
                                            string=_('Justified absence on period'),
                                            compute='_compute_holidays')
    total_holidays_days = fields.Float(string=_("Total Leave days"), compute='_compute_holidays')
    total_holidays_days_m = fields.Float(string=_("Total Leave days"))
    hr_public_holidays_ids = fields.One2many('hr.holidays.public.line',
                                             string=_('Public Holidays on period'),
                                             compute='_compute_public_holidays')
    total_public_holidays_days = fields.Float(string=_("Total Public holidays"),
                                              compute='_compute_absence_presences_values', store=True)
    total_public_holidays_days_m = fields.Float(string=_("Total Public holidays"))

    line_ids = fields.One2many('hr.employee.attendance.summary.item', 'summary_id',
                               string=_('Lines'),
                               copy=True, compute='_get_attendance', store=True)
    # taux
    taux_presence = fields.Float(_("Presence rate (%)"), compute='_compute_absence_presences_values', store=True)
    taux_absence = fields.Float(_('Absence rate (%)'), compute='_compute_absence_presences_values', store=True)

    # goals
    # prorata = fields.Float(string="Prorata (Presence rate)")

    state = fields.Selection([('draft', 'Draft'), ('cancel', _('Cancel')), ('to approve', _('Approved')),
                              ('confirmed', _('Confirmed'))],
                             string=_('Status'),
                             required=True, readonly=True, copy=False, default='draft',
                             help=_('New entry is  at draft state then, approved before confirmed'))

    weekend_ids = fields.Many2many('its.hr.weekend', string=_('Weekends include on the holidays'),
                                   compute='_update_weekends', store=True)
    @api.model
    def _create(self, vals):
        res = super()._create(vals)
        return res

    @api.multi
    def action_cancel(self):
        self.write({
            'state': 'cancel',
        })

    @api.multi
    def action_draft(self):
        self.write({
            'state': 'draft',
        })

    @api.multi
    def action_submit(self):
        self.write({
            'state': 'to approve',
        })

    @api.multi
    def action_approve(self):
        self.write({
            'state': 'confirmed',
        })

    @api.model
    def create(self, vals):
        result = super(HrEmployeeAttendanceSummary, self).create(vals)
        if 'company_id' in vals:
            result.write({'name': self.env['ir.sequence'].with_context(force_company=vals['company_id']).next_by_code(
                'hr.entity.attendance.summary') or _('New')})
        else:
            result.write({'name': self.env['ir.sequence'].next_by_code(
                'hr.entity.attendance.summary') or _('New')})
        return result

    @api.one
    @api.depends('start_date', 'end_date')
    def _compute_total_days(self):
        if self.start_date and self.end_date:
            delta = datetime.strptime(self.end_date,
                                      DATE_FORMAT) - datetime.strptime(
                self.start_date, DATE_FORMAT) + timedelta(days=1)
            self.total_days = delta.total_seconds() / 86400.0

    @api.one
    @api.depends('start_date', 'end_date')
    def _compute_public_holidays(self):
        if self.start_date and self.end_date:
            start = self.start_date + ' ' + START_TIME
            end = self.end_date + ' ' + END_TIME
            holidays = self.env['hr.holidays'].get_public_holidays_f_period(start_date=start, end_date=end)
            if holidays:
                ids = [h.id for h in holidays]
                self.hr_public_holidays_ids = ids

    @api.one
    @api.depends('start_date', 'end_date', 'employee_id')
    def _compute_holidays(self):
        if self.start_date and self.end_date and self.employee_id:
            end = self.end_date + ' ' + END_TIME
            start = self.start_date + ' ' + START_TIME

            self.hr_holidays_ids = self.env['hr.holidays']. \
                search(
                [('type', '=', 'remove'), ('state', '=', 'validate'), '&', ('employee_id', '=', self.employee_id.id),
                 '&', ('holiday_status_id.consider_as_justified_absence', '=', False),
                 '|', '&', ('date_from', '>=', start), ('date_from', '<=', end),
                 '|', '&', ('date_to', '>=', start), ('date_to', '<=', end),
                 '|', '&', ('date_from', '<=', start), ('date_to', '>=', end),
                 '&', ('date_from', '>=', start), ('date_to', '<=', end),
                 ])
            self.justified_absence_ids = self.env['hr.holidays']. \
                search(
                [('type', '=', 'remove'), ('state', '=', 'validate'), '&', ('employee_id', '=', self.employee_id.id),
                 '&', ('holiday_status_id.consider_as_justified_absence', '=', True),
                 '|', '&', ('date_from', '>=', start), ('date_from', '<=', end),
                 '|', '&', ('date_to', '>=', start), ('date_to', '<=', end),
                 '|', '&', ('date_from', '<=', start), ('date_to', '>=', end),
                 '&', ('date_from', '>=', start), ('date_to', '<=', end),
                 ])
            if self.hr_holidays_ids:
                self.total_holidays_days = sum([holiday.number_of_days_temp
                                                for holiday in self.hr_holidays_ids])
            if self.justified_absence_ids:
                self.total_justified_absences_days = sum([holiday.number_of_days_temp
                                                          for holiday in self.justified_absence_ids])

    @api.one
    @api.depends('start_date', 'end_date', 'employee_id')
    def _get_current_contract(self):
        contracts = self.env['hr.contract'].search([
            '&', ('date_start', '<=', self.start_date),
            '&', ('employee_id', '=', self.employee_id.id),
            '&', ('state', '=', 'open'),
            '|', ('date_end', '=', False),
            ('date_end', '>=', self.start_date)
        ])
        if contracts and len(contracts.ids) > 0:
            self.contract_id = contracts[0]
            self.contract_date_end = self.contract_id.date_end

    @api.one
    def check_if_period_is_included_in_leave(self, start_date, end_date):
        leaves = self.env['hr.holidays'].search([
            ('employee_id', '=', self.employee_id.id),
            ('date_from', '<=', start_date),
            ('date_to', '>=', end_date)
        ])
        if leaves and len(leaves.ids) > 0:
            return True
        return False

    @api.one
    def check_if_day_is_work_day(self, date):
        """

        :param date: the given date
        :return: [True] if the given date is a day of work [False] otherwise
        """
        # date_as_object = datetime.datetime.strptime(date, '%Y-%m-%d')
        date_as_object = date
        wordays = self.env['resource.calendar.attendance'].search([
            ('calendar_id', '=', self.contract_id.resource_calendar_id.id),
            ('dayofweek', '=', date_as_object.weekday())
        ])
        if wordays and len(wordays.ids) > 0:
            return True
        return False

    @api.one
    def check_if_day_is_public_holidays(self, date):
        """

                :param date: the given date
                :return: [True] if the given date is a public holiday [False] otherwise
                """
        holidays = self.env['hr.holidays.public.line'].search([
            ('date', '=', date)
        ])
        if holidays and len(holidays.ids) > 0:
            return True
        return False

    @api.one
    def check_if_come_at(self, date):
        date_begin = date.replace(hour=0, minute=0, second=0, microsecond=0)
        date_end = date.replace(hour=23, minute=59, second=59, microsecond=0)
        date_begin = date_begin.strftime(DATE_FORMAT)
        date_end = date_end.strftime(DATE_FORMAT)
        attendances = self.env['hr.attendance'].search([('employee_id', '=', self.id),
                                                        ('check_in', '>=', date_begin + ' ' + START_TIME),
                                                        ('check_in', '<=', date_end + ' ' + END_TIME)])

        if attendances and len(attendances.ids) > 0:
            return True
        return False

    @api.one
    @api.depends('start_date', 'end_date', 'employee_id')
    def _update_weekends(self):
        """
        Update the weekends list.
        """
        if self.start_date and self.end_date and self.employee_id:
            start_date = self.start_date + ' ' + START_TIME
            end_date = self.end_date + ' ' + END_TIME
            # self.write({'weekend_ids': [(5,)]})
            if self.contract_id and self.contract_id.date_end and self.contract_id.date_end < end_date:
                end_date = self.contract_id.date_end
            weekends = WeekendManager.weekend_between_two_date_str_format(start=start_date, end=end_date)
            exclud_list_weekends = []
            if self.hr_holidays_ids:

                for w in weekends:
                    for holiday in self.hr_holidays_ids:
                        if holiday.date_to >= w and holiday.date_from <= w and not holiday.is_weekend_of_holiday(w):
                            exclud_list_weekends.append(w)
            if exclud_list_weekends:  # sub exclud weekends
                weekends = list(set(weekends) - set(exclud_list_weekends))
            weekends = [w.split(' ')[0] for w in weekends]  # keep only date format
            weeks = self.count_weekends_in_list_of_weekends(weekends=weekends)
            self.total_weekend_days = len(weeks)

    @api.one
    def update_weekends_old(self):
        start_date = self.start_date
        end_date = self.end_date
        self.write({'weekend_ids': [(5,)]})
        if self.contract_id and self.contract_id.date_end and self.contract_id.date_end < end_date:
            end_date = self.contract_id.date_end

        holidays = self.hr_holidays_ids
        intervals = [start_date, end_date]
        for holiday in holidays:  # TODO
            if holiday.date_from < start_date:
                intervals.append(holiday.date_from)
            if holiday.date_to < end_date:
                intervals.append(holiday.date_to)
        intervals.sort()
        i = 0
        while i + 1 < len(intervals):
            start = intervals[i]
            end = intervals[i + 1]

            if not self.check_if_period_is_included_in_leave(start, end)[0]:
                self.count_weekend_between(start, end)
            i += 1

        for holiday in holidays:
            for week in holiday.weekend_ids:
                if week.id not in self.weekend_ids.ids and start_date <= week.date <= end_date:
                    self.write({'weekend_ids': [(4, week.id)]})

    @api.one
    def count_weekend_between(self, start_date, end_date):
        """
        We admit that there is no leave between the start and the end date
        :param start_date:
        :param end_date:
        :return:
        """
        weekends = WeekendManager.weekend_between_two_date(start_date, end_date)
        created_ids = []
        weekend_obj = self.env['its.hr.weekend']
        for weekend in weekends:
            weekend_as_string = weekend.strftime(DATE_FORMAT)
            if not self.check_if_day_is_work_day(weekend)[0] and \
                    not self.check_if_day_is_public_holidays(weekend)[0]:
                sys_weekends = weekend_obj.search([('date', '=', weekend_as_string)])
                if not sys_weekends or not sys_weekends.ids:
                    week_id = weekend_obj.create({
                        'date': weekend_as_string
                    })
                    created_ids += [week_id.id]
                else:
                    created_ids += sys_weekends.ids

        for id in created_ids:
            self.write({'weekend_ids': [(4, id)]})

    # @api.one
    def count_weekends_in_list_of_weekends(self, weekends):
        """
        Count the weekends which are not public holiday.
        """
        created_ids = []
        list_date = []
        weekend_obj = self.env['its.hr.weekend']
        for weekend in weekends:
            if not self.check_if_day_is_public_holidays(weekend)[0]:
                sys_weekends = weekend_obj.search([('date', '=', weekend)])
                if not sys_weekends or not sys_weekends.ids:
                    list_date.append(weekend)
                    week_id = weekend_obj.create({
                        'date': weekend
                    })
                    created_ids += [week_id.id]
                elif sys_weekends[0].date not in list_date:  # empeche les doublons venant de la table its.hr.weekends
                    list_date.append(sys_weekends[0].date)
                    if len(sys_weekends) > 1:
                        created_ids += sys_weekends[0].ids
                    else:
                        created_ids += sys_weekends.ids
        self.weekend_ids = [(6, 0, created_ids)]
        # for id in created_ids:
        #     self.write({'weekend_ids': [(4, id)]})
        return list_date

    def get_employee_absence(self, date_start, date_end):
        delay_abs = 0.00
        # print(delay_abs)

        dayofweek = list(set(self.resource_calendar_id.attendance_ids.mapped('dayofweek')))

        work_day_quota = {x: sum([y.hour_to - y.hour_from for y in
                                  self.resource_calendar_id.attendance_ids.filtered(lambda att: att.dayofweek == x)])
                          for x in dayofweek}
        work_day_in_period = self.find_days(work_day_quota, date_start, date_end)
        # print('Work day ::', work_day_in_period)
        for w in work_day_in_period:
            attendance_ids = self.env['hr.attendance'].search([('employee_id', '=', self.id),
                                                               ('check_in', '>=', w + ' ' + START_TIME),
                                                               ('check_in', '<=', w + ' ' + END_TIME)])

            week_day = self.findDay(fields.Date.from_string(w))
            attendance_day = sum([x.worked_hours for x in attendance_ids])

            if attendance_day <= work_day_quota[week_day]:
                delay_abs = delay_abs + (work_day_quota[week_day] - attendance_day)

        # print("delay_abs : ", delay_abs/8)

        return delay_abs

    # @api.multi
    # def write(self, vals):
    #     if 'line_ids' in vals:
    #
    #     result = super(HrEmployeeAttendanceSummary, self).write(vals)
    #     for summary in self:
    #         summary._set_late_and_earli_values()
    #         summary._compute_absence_presences_values()
    #     return result

    # TODO exclude weekends,leaves to attendances
    @api.one
    @api.depends('start_date', 'end_date', 'employee_id')
    def _get_attendance(self):
        """
        Get attendances from period for employee.
        """
        if self.start_date and self.end_date and self.employee_id:
            end = self.end_date.split(' ')[0] + ' ' + END_TIME
            start = self.start_date.split(' ')[0] + ' ' + START_TIME
            if self.contract_id and self.contract_id.date_end and self.contract_id.date_end < end:
                end = self.contract_id.date_end

            query = """
                select check_in,check_out,worked_hours
                from hr_attendance att
                where att.employee_id = %s
                and 
                ((check_in  >= TO_TIMESTAMP('%s','YYYY-MM-DD HH24:MI:SS') and  check_out <= TO_TIMESTAMP('%s','YYYY-MM-DD HH24:MI:SS'))
                or ( check_in >= TO_TIMESTAMP('%s','YYYY-MM-DD HH24:MI:SS') and att.check_in <= TO_TIMESTAMP('%s','YYYY-MM-DD HH24:MI:SS') and att.check_out is null)
                or ( att.check_out >= TO_TIMESTAMP('%s','YYYY-MM-DD HH24:MI:SS') and att.check_out <= TO_TIMESTAMP('%s','YYYY-MM-DD HH24:MI:SS') and att.check_in is null))
                and id not in (
                select att.id
                from hr_attendance att, hr_holidays_public_line hp 
                where att.employee_id = %s
                and ( hp.date = att.check_in::timestamp::date or hp.date = att.check_out::timestamp::date))
                order by check_in asc
            """ % (self.employee_id.id, start, end, start, end, start, end, self.employee_id.id)
            self._cr.execute(query)
            line_ids = []
            for check_in, check_out, worked_hours in self._cr.fetchall():
                date = check_in.split(' ')[0] if check_in else check_out.split(' ')[0]
                line_ids.append(
                    (0, 0, {'arrival_time': check_in, 'departure_time': check_out, 'worked_hours': worked_hours,
                            'date': date}))
            if line_ids:
                self.line_ids = line_ids
        return

    @api.one
    @api.depends('line_ids')
    def _compute_late_and_earli_values(self):
        if self.line_ids:
            total_hour_early_exit = 0
            total_hour_late = 0
            for line in self.line_ids:
                total_hour_late += line.hours_late
                total_hour_early_exit += line.earlier_exit
            self.total_earlier_exit_hours = total_hour_early_exit
            self.total_late_hours = total_hour_late
            self.total_late_days = total_hour_late / 24
            self.total_earlier_exit_days = total_hour_early_exit / 24

        return

    @api.one
    @api.depends('total_days', 'line_ids')
    def _compute_absence_presences_values(self):

        total_public_holidays = len(self.hr_public_holidays_ids) if self.hr_public_holidays_ids else 0
        total_weekends = len(self.weekend_ids) if self.weekend_ids else 0
        self.total_presence_days = self._increase_nb_of_attendance(len_attendance=len(self.line_ids),
                                                                   total_days_period=self.total_days,
                                                                   total_nb_weekends=total_weekends,
                                                                   total_nb_pub_holidays=total_public_holidays) if self.line_ids else 0

        self.total_public_holidays_days = total_public_holidays
        self.total_absences_days = self.total_days - self.total_presence_days - self.total_weekend_days - self.total_holidays_days - total_public_holidays
        if self.contract_id:  # TODO we have to define all cases testing
            self.taux_presence = ((
                                              self.total_presence_days + self.total_weekend_days + total_public_holidays) -
                                  (self.total_late_days + self.total_earlier_exit_days)) / self.total_days
            self.taux_absence = ((self.total_late_days + self.total_earlier_exit_days + self.total_days) - (
                    self.total_presence_days + self.total_weekend_days + self.total_holidays_days + total_public_holidays)) / self.total_days
        if not self.contract_id: self.taux_absence = 1

        return

    @api.multi
    def name_get(self):
        res = []
        for att in self:
            res.append((att.id, _("%s [%s - %s]") % (att.name, att.start_date, att.end_date
                                                     )))
        return res

    def _increase_nb_of_attendance(self, len_attendance, total_days_period, total_nb_weekends, total_nb_pub_holidays):
        """
        increased the number of attendance according to the number of days of the period, the number of weekends and the
        total public holidays.
        @param len_attendance:integer , numbers of attendance.
        @param total_days_period:integer , total number of days period.
        @param total_nb_weekends:integer , total number of weekends.
        @param total_nb_pub_holidays:integer , total number of public holidays.
        """
        increase = total_days_period - total_nb_weekends - total_nb_pub_holidays
        return len_attendance if len_attendance < increase else increase
