from odoo import fields, models, api,_


class LeaveType(models.Model):
    _inherit = 'hr.holidays.status'


    consider_weekend_as_presence = fields.Boolean(_("Consider weekend as presence when evaluating prorata"))
    no_consider_saturday_as_weekend = fields.Boolean(_("Don't Consider Saturday as Weekend"))
    consider_as_justified_absence = fields.Boolean(_("Consider as justified absences"))
