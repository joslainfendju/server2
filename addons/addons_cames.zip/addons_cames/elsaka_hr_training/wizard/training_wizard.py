from odoo import fields, models, api


class RequestWizard(models.TransientModel):
    _name = 'training.request.wizard'
    _description = 'Description'

    schedule_id = fields.Many2one(comodel_name='course.schedule', string='Course Schedule')
    course_id = fields.Many2one(comodel_name='course.training', string='Course Training')
    request_id = fields.Many2one(comodel_name='training.request', string='Training Request')
    employee_ids = fields.Many2many(comodel_name='hr.employee', string='Training')

    def get_data(self, employee):
        return {
            'employee_id': employee.id,
            'course_name': self.schedule_id.id,
            'request_id': self.request_id.id,
            'state': 'draft',
        }

    def get_domain(self, employee):
        return [
            ('employee_id', '=', employee.id),
            ('course_name', '=', self.schedule_id.id),
            ('request_id', '=', self.request_id.id)
        ]

    @api.multi
    def execute(self):
        self.ensure_one()
        training_env = self.env['training.training']
        for employee in self.employee_ids:
            domain = self.get_domain(employee)
            res = training_env.search_count(domain)
            if res == 0:
                value = self.get_data(employee)
                training_env.create(value)
        self.request_id.schedule_id = self.schedule_id
