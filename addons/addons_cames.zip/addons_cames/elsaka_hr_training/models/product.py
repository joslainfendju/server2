from odoo import fields, models, api


class ProductProduct(models.Model):
    _inherit = 'product.product'
    _description = 'Description'

    is_training = fields.Boolean()
