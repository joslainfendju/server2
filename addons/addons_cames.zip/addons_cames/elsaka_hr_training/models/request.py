from odoo import fields, models, api


class TrainingRequest(models.Model):
    _name = 'training.request'
    _description = 'Description'

    name = fields.Char()
    survey_id = fields.Many2one(comodel_name='survey.survey', string='Survey Training')
    course_id = fields.Many2one(comodel_name='course.training', string='Course Training')
    schedule_id = fields.Many2one(comodel_name='course.schedule', string='Course Schedule')
    user_id = fields.Many2one(comodel_name='res.users', string='Requester', default=lambda s: s.env.user.id)
    department_id = fields.Many2one(comodel_name='hr.department', string='Department')
    employee_ids = fields.Many2many(comodel_name='hr.employee', string='Training')
    course_request_ids = fields.One2many(comodel_name='training.training', inverse_name='request_id', string='Course request')
    state = fields.Selection(selection=[
        ('draft', 'Draft'),
        ('submit', 'Submit'),
        ('agree', 'Agree'),
        ('cancel', 'Cancel')], default='draft')

    @api.multi
    def set_to_draft(self):
        return self.write({'state': 'draft'})

    @api.multi
    def set_to_submit(self):
        return self.write({'state': 'submit'})

    @api.multi
    def set_to_cancel(self):
        return self.write({'state': 'cancel'})

    @api.multi
    def set_to_agree(self):
        return self.write({'state': 'agree'})

    @api.multi
    def generate_course_request(self):
        view_id = self.env.ref("elsaka_hr_training.request_course_wizard")
        return {
            'name': 'Wizard',
            'res_model': 'training.request.wizard',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': view_id.id,
            'target': 'new',
            'type': 'ir.actions.act_window',
            'context': {
                'default_employee_ids': self.employee_ids.ids,
                'default_course_id': self.course_id.id,
                'default_request_id': self.id,
            }
        }


class Training(models.Model):
    _inherit = 'training.training'

    request_id = fields.Many2one(comodel_name='training.request', string='Training Request')
    survey_id = fields.Many2one(comodel_name='survey.survey', string='Survey Training', related='request_id.survey_id')

