# -*- coding: utf-8 -*-
{
    'name': "Employee's Training Management",
    'author': "Mahmoud Elsaka",
    'description': '''Managing Employee Trainings''',
    'website': "http://www.elsaka.com",
    'category': 'Human Resource',
    'version': '0.1',
    # any module necessary for this one to work correctly
    'depends': ['base', 'sale', 'mail', 'hr', 'survey', 'its_hr_employee', 'aspl_hr_travel_management', 'purchase', 'product'],
    'license': 'AGPL-3',
    # always loaded
    'data': [
        'data/product_data.xml',
        'security/training_security.xml',
        'security/ir.model.access.csv',
        'views/request_view.xml',
        'views/views.xml',
        'views/templates.xml',
        # 'views/sequence.xml',
        'views/training_employee.xml',
        'wizard/training_wizard_view.xml',
    ],
    'images': ['static/description/icon.jpg'],
    # only loaded in demonstration mode
    'demo': [
        # 'demo/demo.xml',
    ],
    'installable': True,
    'auto_install': False,
}
