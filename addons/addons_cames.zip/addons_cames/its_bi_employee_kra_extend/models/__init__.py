# -*- coding: utf-8 -*-

from . import employee
from . import employee_kra
from . import employee_value_rating
from . import res_config_settings
