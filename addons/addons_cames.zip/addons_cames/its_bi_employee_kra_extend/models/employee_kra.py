# -*- coding: utf-8 -*-
# Part of Browseinfo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api,_
from odoo.exceptions import UserError


class KRA(models.Model):
	_inherit = 'employee.kra'

	recommendation = fields.Text(string="Recommendation")
	state = fields.Selection(
		[('draft', 'Draft'), ('valid', 'Valid kra'), ('submit', 'Submit To Supervisor'), ('cancel', 'Cancel'), ('done', 'Done')],
		string='State', default="draft")

	@api.constrains('employee_id')
	def assessment_quota(self):
		quota = self.env['ir.config_parameter'].sudo().get_param('assessment_quota')
		year = self.env['year.list'].search([('name', '=', fields.date.today().year)])

		appraisal_kra = self.env['employee.kra'].search_count([('year_id', '=', year.id)])
		appraisal_value = self.env['employee.value'].search_count([('year_id', '=', year.id)])
		result = appraisal_kra + appraisal_value
		print('-_-_-_-_-_-_-_-__-_--__-result')
		print(result)
		if result >= quota:
			return False
		else:
			return True

	def valid_kra(self):
		# print('----------- Valid KRA :::::::::: ', self.employee_id.company_id.email)
		# print('----------- employee_id.email :::::::::: ', self.employee_id.work_email)
		# print('----------- parent_id.email :::::::::: ', self.employee_id.parent_id.work_email)
		print('----------- KRA_ID :::::::::: ', self.kra_id.name)
		template = self.env.ref('bi_employee_kra_extend.notification_valid_kra')
		template_manager = self.env.ref('bi_employee_kra_extend.notification_valid_kra_manager')
		self.write({'state': 'valid'})
		template.send_mail(self.id, force_send=True, raise_exception=True)
		template_manager.send_mail(self.id, force_send=True, raise_exception=True)
		return

	@api.multi
	def action_makeMeeting(self):
		""" This opens Meeting's calendar view to schedule meeting on current applicant
            @return: Dictionary value for created Meeting view
        """
		self.ensure_one()
		# partners = self.employee_id.partner_id | self.employee_id.user_id.partner_id | self.employee_id.department_id\
		# 	.manager_id.user_id.partner_id
		print('------------ : ', self.employee_id.department_id.manager_id.user_id.partner_id)
		partners = self.employee_id.user_id.partner_id | self.employee_id.department_id.manager_id.user_id.partner_id

		category = self.env.ref('bi_employee_kra_extend.notification_valid_kra')
		res = self.env['ir.actions.act_window'].for_xml_id('calendar', 'action_calendar_event')
		res['context'] = {
			'search_default_partner_ids': self.employee_id.name,
			'default_partner_ids': partners.ids,
			'default_user_id': self.env.uid,
			'default_name': self.kra_id.name,
			'default_categ_ids': category and [category.id] or False,
		}
		return res
