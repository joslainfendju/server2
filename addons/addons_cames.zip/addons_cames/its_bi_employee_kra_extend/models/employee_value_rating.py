# -*- coding: utf-8 -*-
# Part of Browseinfo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api,_
from odoo.exceptions import UserError


class EmployeeValue(models.Model):
	_inherit = 'employee.value'

	recommendation = fields.Text(string="Recommendation")

	@api.constrains('employee_id')
	def assessment_quota(self):
		quota = self.env['ir.config_parameter'].sudo().get_param('assessment_quota')
		year = self.env['year.list'].search([('name', '=', fields.date.today().year)])

		appraisal_kra = self.env['employee.kra'].search_count([('year_id', '=', year.id)])
		appraisal_value = self.env['employee.value'].search_count([('year_id', '=', year.id)])
		result = appraisal_kra + appraisal_value
		print('-_-_-_-_-_-_-_-__-_--__-result')
		print(result)
		if result >= quota:
			return False
		else:
			return True
