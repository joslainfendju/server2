# -*- coding: utf-8 -*-
# Part of Browseinfo. See LICENSE file for full copyright and licensing details.

from odoo import models, fields, api,_
from odoo.exceptions import UserError


class HREmployee(models.Model):
	_inherit = 'hr.employee'

	kra_ids = fields.One2many(comodel_name='employee.kra', inverse_name='employee_id')
	value_ids = fields.One2many(comodel_name='employee.value', inverse_name='employee_id')

	@api.multi
	def get_employee_to_unlink(self):
		to_delete = list()
		employees = super(HREmployee, self).get_employee_to_unlink()
		for emp in employees:
			if not len(emp.kra_ids) and not len(emp.value_ids):
				to_delete.append(emp.id)
		to_delete = self.env['hr.employee'].search([("id", 'in', to_delete)])
		return to_delete
