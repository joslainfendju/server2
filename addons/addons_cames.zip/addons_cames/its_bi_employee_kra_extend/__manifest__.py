# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

{
    "name": "its_bi_employee_kra_extend ",
    "version": "11.0.0.2",
    "category": "Human Resources",
    'summary': 'Employee Performance Evaluation with workflow customized and some specials rules',
    "description": """
    
    """,
    "author": "ITS Choupo",
    "website": "",
    "price": 000,
    "currency": 'EUR',
    "depends": ['bi_employee_kra'],
    "data": [
        'views/employee_kra_view.xml',
        'views/value_rating_views.xml',
        'views/res_config_settings_views.xml',
        'views/menu.xml',


        # data
        'data/mail_format_for_valid_kra.xml',
        'data/mail_format_valid_kra_manager.xml',
    ],

    'qweb': [
    ],
    "auto_install": False,
    "installable": True,
    "images": ["static/description/Banner.png"],
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
