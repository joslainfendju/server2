# -*- coding: utf-8 -*-

# import loan_payroll_report
# import loan_report
# from . import loan_details

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

