# Copyright 2018 elego Software Solutions GmbH - Yu Weng
# Copyright 2018 initOS GmbH - Nikolina Todorova
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
from datetime import datetime, timedelta

from odoo import _, api, fields, models
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT

from odoo.exceptions import UserError

COUNTRY_GENERATORS = []


class HrHolidayPublicLineWizard(models.TransientModel):
    _name = 'public.holiday.line.wizard'
    _description = 'Creates public holidays lines for ongoing year'

    name = fields.Char(
        'Name',
        required=True,
    )
    start_day = fields.Date(
        'Date From',
        required=True,
        default=(lambda self: datetime.today())
    )
    end_day = fields.Date(
        'Date To',
        required=True,
        default=(lambda self: datetime.today())
    )
    year_id = fields.Many2one(
        'hr.holidays.public',
        'Calendar Year',
        required=True,
    )
    variable_date = fields.Boolean('Date may change', oldname='variable',
                                   default=True)

    @api.multi
    def action_run(self):
        self.ensure_one()
        start = datetime.strptime(self.start_day, DEFAULT_SERVER_DATE_FORMAT)
        end = datetime.strptime(self.end_day, DEFAULT_SERVER_DATE_FORMAT)
        dates = self.get_date_list(start, end)
        for date in dates:
            body = {
                "name": self.name,
                "date": date,
                "year_id": self.year_id.id,
                "variable_date": True
            }
            self.env['hr.holidays.public.line'].create(body)
        return True

    # show dates between two dates

    def get_date_list(self, date1, date2):
        date_list = []
        loop_dt = date1
        date_list.append(loop_dt)

        while loop_dt < date2:
            loop_dt = loop_dt + timedelta(days=1)
            date_list.append(loop_dt)

        return date_list
