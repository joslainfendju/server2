This module is a technical module to handle public holidays.

The calculation of each leave can exclude rest public holiday, depending on
the leave type configuration.
