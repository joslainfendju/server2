# -*- coding: utf-8 -*-
{
    'name': "Contract Extend",

    'summary': """
        Manage Contract""",

    'description': """
        This module permit to manage:
        - Contracts
        - Contract Types
    """,

    'author': "IT Services, Alain BIYONG",
    'website': "http://www.its-nh.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/master/odoo/addons/base/module/module_data.xml
    # for the full list
    'category': 'Human Resources',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': [
        'base',
        'hr',
        'hr_employee_seniority',
        'hr_contract',
        'hr_contract_ref',
        'its_hr_convention',
    ],
    'images': [
        'static/description/icon.png',
    ],

    # always loaded
    'data': [
        # Views
        'security/security.xml',
        'security/ir.model.access.csv',
        # 'views/hr_applicant_view.xml',
        'views/hr_contract_view.xml',
        'views/hr_contract_template_view.xml',
        'views/hr_contract_type_form_view.xml',
        'views/hr_trial_length_view.xml',
        'views/reminder_template_view.xml',
        'views/res_config_view.xml',

        # wizard
        'views/hr_contract_template_wizard.xml',

        # menu
        'views/menu.xml',

        # reports
        'report/contract_template_report.xml',
        'report/renew_contract_report.xml',
        'report/report_menu.xml',

        # data
        'data/mail_contract_cron.xml',
        'data/mail_contract_template.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'application': True,
}
