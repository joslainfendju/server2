from odoo import fields, models, api


class HrJobTransferWizard (models.TransientModel):
    _name = 'hr.reminder.contract.wizard'

    name = fields.Char()

    def get_domain_renew(self, args=None):
        return [('state', '=', 'pending')]

    def get_domain_expire(self, args=None):
        return [('state', '=', 'close')]

    def get_query_renew(self, args=None):
        return """SELECT id, company_id FROM hr_contract WHERE state = 'pending'"""

    def get_query_expire(self, delay, args=None):
        # return """SELECT id
        #     FROM hr_contract
        #     WHERE state = 'open'
        #     AND (CURRENT_DATE + interval '%s days') >= date_end""" % (delay, )
        # return """SELECT id
        #             FROM hr_contract
        #             WHERE state = 'open'
        #             AND CURRENT_DATE >= date_end OR (date_end - CURRENT_DATE) <= '%s'""" % (delay,)
        return """SELECT id, company_id 
                    FROM hr_contract 
                    WHERE state = 'open' 
                    AND (date_end - CURRENT_DATE) <= '%s'""" % (delay,)

    def get_query_expired(self, delay, args=None):
        return """SELECT id, company_id FROM hr_contract WHERE state = 'Expired'"""

    def get_query_cancel(self, delay, args=None):
        return """SELECT id, company_id FROM hr_contract WHERE state = 'Cancelled'"""

    def notif_contract(self, template, wizard, args=None):
        cr = self.env.cr
        # renew_domain = self.get_domain_expire(args)
        # renew = self.env['hr.contract'].search(renew_domain)
        # expire_domain = self.get_domain_expire(args)
        # exp = self.env['hr.contract'].search(expire_domain)

        renew_query = self.get_query_renew(args)
        cr.execute(renew_query)
        renew = cr.dictfetchall()

        delay = int(self.env['ir.config_parameter'].sudo().get_param('hr_contract_extend.contract_renew'))
        expire_query = self.get_query_expire(delay, args)
        cr.execute(expire_query)
        exp = cr.dictfetchall()

        expired_query = self.get_query_expired(delay, args)
        cr.execute(expired_query)
        expired = cr.dictfetchall()

        cancelled_query = self.get_query_expired(delay, args)
        cr.execute(cancelled_query)
        cancelled = cr.dictfetchall()

        for renew_tmp in renew:
            cr.execute("""INSERT INTO hr_renew_contract_rel (hr_reminder_contract_id, 
                                hr_contract_id) VALUES (%s, %s)""", (wizard.id, renew_tmp['id']))

        for exp_tmp in exp:
            cr.execute("""INSERT INTO hr_expire_contract_rel (hr_reminder_contract_id, 
                                hr_contract_id) VALUES (%s, %s)""", (wizard.id, exp_tmp['id']))

        for exp_tmp in expired:
            cr.execute("""INSERT INTO hr_expired_contract_rel (hr_reminder_contract_id, 
                                hr_contract_id) VALUES (%s, %s)""", (wizard.id, exp_tmp['id']))

        for exp_tmp in cancelled:
            cr.execute("""INSERT INTO hr_expired_contract_rel (hr_reminder_contract_id, 
                                hr_contract_id) VALUES (%s, %s)""", (wizard.id, exp_tmp['id']))

        if len(renew) != 0 or len(exp) != 0:
            # template.attachment_ids = [(4, wizard.id)]
            template\
                .with_context(lang=self.env.user.company_id.partner_id.lang)\
                .send_mail(wizard.id, force_send=True, raise_exception=True)


    @api.model
    def sending_mail_for_contract_not_in_progress(self):
        template = self.env.ref('its_hr_contract_extend.notification_email_contract_not_in_progress')
        wizard = self.env['hr.reminder.contract.template'].create({'name': 'name'})
        self.notif_contract(template, wizard)
