from . import hr_reminder_contract_wizard
from . import hr_contract_template_wizard
