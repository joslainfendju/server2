from odoo import fields, models, api


class HrContractTemplate (models.TransientModel):
    _name = 'hr.contract.template.wizard'

    employee_id = fields.Many2one('hr.employee', string='Employee', required=True)
    job_id = fields.Many2one('hr.job', related="contract_id.job_id", string='Job')
    contract_id = fields.Many2one('hr.contract', string='Contract', required=True)
    department_id = fields.Many2one('hr.department', related="contract_id.department_id", string='Department')
    template_id = fields.Many2one('hr.contract.template', string='Contract Template', required=True)

    def get_parser_data(self):
        employee = self.employee_id
        contract = self.contract_id
        job = self.job_id
        department = self.department_id

        parse_employee = dict()
        parse_contract = dict()
        parse_job = dict()
        parse_department = dict()

        for key_property in list(set(employee._fields)):
            key = 'employee.%s' % (key_property,)
            if isinstance(employee[key_property], (float, int, bool, str)):
                parse_employee.update({key: str(employee[key_property])})

        for key_property in list(set(contract._fields)):
            key = 'contract.%s' % (key_property,)
            if isinstance(contract[key_property], (float, int, bool, str)):
                parse_contract.update({key: str(contract[key_property])})

        for key_property in list(set(job._fields)):
            key = 'job.%s' % (key_property,)
            if isinstance(job[key_property], (float, int, bool, str)):
                parse_job.update({key: str(job[key_property])})

        for key_property in list(set(department._fields)):
            key = 'department.%s' % (key_property,)
            if isinstance(department[key_property], (float, int, bool, str)):
                parse_department.update({key: str(department[key_property])})
        res = dict()
        res.update(parse_contract)
        res.update(parse_department)
        res.update(parse_employee)
        res.update(parse_job)
        return res

    @api.multi
    def get_ready_contract(self):
        self.ensure_one()
        content = self.template_id.content
        parse_data = self.get_parser_data()
        # content = "{size} widget that {verb} {noun}".format(size='Tiny',verb='pounds',noun='nails')
        print("---------------------------------------- content")
        print(content)
        print("---------------------------------------- employee parser")
        print(parse_data)

        content = content % parse_data
        print(content)
        return content

    @api.multi
    def print_contract(self):
        self.ensure_one()
        data = dict()
        data['ids'] = self.ids
        data['model'] = self._name
        data['content'] = self.get_ready_contract()

        return self.env.ref('hr_contract_extend.report_contract_template_menu').report_action(self, data=data)



