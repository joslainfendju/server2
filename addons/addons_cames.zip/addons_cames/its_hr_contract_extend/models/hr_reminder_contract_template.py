from odoo import fields, models, api


class HrReminderContractTemplate (models.Model):
    _name = 'hr.reminder.contract.template'

    name = fields.Char()
    company_id = fields.Many2one('res.company', string='Company', default=lambda s: s.env.user.company_id.id)
    expire_ids = fields.Many2many(
        comodel_name='hr.contract',
        relation='hr_expire_contract_rel',
        column1='hr_reminder_contract_id',
        column2='hr_contract_id',
        string="Expired Contracts",
        ondelete='cascade')

    renew_ids = fields.Many2many(
        comodel_name='hr.contract',
        relation='hr_renew_contract_rel',
        column1='hr_reminder_contract_id',
        column2='hr_contract_id',
        string="Renewed Contracts",
        ondelete='cascade')

    expired_ids = fields.Many2many(
        comodel_name='hr.contract',
        relation='hr_expired_contract_rel',
        column1='hr_reminder_contract_id',
        column2='hr_contract_id',
        string="Contracts was Expired",
        ondelete='cascade')
