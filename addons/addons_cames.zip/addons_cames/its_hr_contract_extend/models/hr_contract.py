from odoo import fields, models, api
from dateutil.relativedelta import relativedelta


class HrContract(models.Model):
    _inherit = 'hr.contract'

    duration = fields.Integer(compute='_get_duration')

    category_id = fields.Many2one(comodel_name='hr.payslip.category', string='Salary Category')
    convention_id = fields.Many2one(comodel_name='hr.convention', related='company_id.convention_id')

    @api.onchange('category_id')
    def onchange_category(self):
        self.wage = self.category_id.salary

    @api.multi
    def _get_duration(self):
        for contract in self:
            if contract.trial_date_end:
                start = contract.trial_date_end
            else:
                start = contract.date_start
            if contract.date_end:
                delta = fields.Date.from_string(contract.date_end) - fields.Date.from_string(start)
                contract.duration = delta.days + 1
            else:
                contract.duration = -1

    def get_query_expire(self, delay):
        return """SELECT *
            FROM hr_contract
            WHERE state = 'open'
            AND (CURRENT_DATE + interval '%s days') >= date_end""" % (delay, )
        # return """SELECT *
        #             FROM hr_contract
        #             WHERE state = 'open'
        #             AND CURRENT_DATE >= date_end OR (date_end - CURRENT_DATE) <= '%s'""" % (delay, )

    @api.multi
    def mail_for_expired_contract(self):
        # contracts = self.env['hr.contract'].search([('state', '=', 'close')])
        template = self.env.ref('hr_contract_extend.notification_expired_contract')
        cr = self.env.cr
        delay = int(self.env['ir.config_parameter'].sudo().get_param('hr_contract_extend.contract_renew'))
        expire_query = self.get_query_expire(delay)
        cr.execute(expire_query)
        contracts_exp = cr.dictfetchall()

        for exp in contracts_exp:
            template.send_mail(exp['id'], force_send=True, raise_exception=True)

    def get_domain(self):
        return [
            ('contract_type_id', '=', self.type_id.id),
            ('convention_id', '=', self.employee_id.convention_id.id),
            ('grade_id', '=', self.category_id.id)
        ]

    @api.onchange('category_id', 'type_id')
    def _onchange_trial_date_end(self):
        if self.type_id and self.category_id and self.date_start:
            cr = self.env['hr.grade.trial']
            domain = self.get_domain()
            job_grade = cr.search(domain, limit=1)
            date_end = fields.Date.from_string(self.date_start) + relativedelta(days=job_grade.trial_id.trial_length)
            self.trial_date_end = fields.Date.to_string(date_end)

