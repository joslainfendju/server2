from odoo import fields, models, api


class HrContractType(models.Model):
    _inherit = 'hr.contract.type'

    grade_trial_ids = fields.One2many(
        comodel_name='hr.grade.trial',
        inverse_name='contract_type_id',
        string="Trial By Grade"
    )