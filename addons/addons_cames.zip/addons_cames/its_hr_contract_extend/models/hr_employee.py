from odoo import fields, models, api


class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    contract_type_id = fields.Many2one(comodel_name='hr.contract.type', related='contract_id.type_id')
    date_end = fields.Date(related='contract_id.date_end')

    @api.multi
    def get_employee_to_unlink(self):
        to_delete = super(HrEmployee, self).get_employee_to_unlink()
        to_ids = list()
        for emp in to_delete:
            if not emp.contract_ids:
                to_ids.append(emp.id)
        to_delete = self.env['hr.employee'].search([("id", 'in', to_ids)])
        return to_delete
