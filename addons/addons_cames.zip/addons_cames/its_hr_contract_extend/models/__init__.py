# -*- coding: utf-8 -*-

from . import res_config_settings
from . import hr_contract
from . import hr_employee
from . import hr_reminder_contract_template
from . import hr_contract_template
from . import hr_contract_type
from . import hr_trial_period
from . import hr_grade_trial
