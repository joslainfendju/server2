from odoo import fields, models, api


class HrTrialPeriod(models.Model):
    _name = 'hr.trial.period'
    _rec_name = 'trial_length'

    trial_length = fields.Integer(string="Trial length (Days)", required=True)
