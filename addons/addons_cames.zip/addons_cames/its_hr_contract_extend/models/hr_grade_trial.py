from odoo import fields, models, api


class HrGradeTrial(models.Model):
    _name = 'hr.grade.trial'

    grade_id = fields.Many2one(comodel_name='hr.payslip.category', string='Grade')
    trial_id = fields.Many2one(comodel_name='hr.trial.period', string='Trial Length')
    contract_type_id = fields.Many2one(comodel_name='hr.contract.type', string='Contract type')
    convention_id = fields.Many2one(comodel_name='hr.convention', string='Convention')
