from odoo import fields, models, api


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    contract_renew = fields.Integer(
        string="Alert renewal contract",
        help="Define number of days to alert about contract due for renewal",
        default=1
    )
    contract_delay = fields.Integer(
        string="Frequency to check and notify",
        help="Define number of days after notify to check and notify again",
        default=1
    )

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        cron = self.env.ref('its_hr_contract_extend.reminder_contract_cron_status')
        cron.interval_number = self.contract_delay
        # self.env.cr.query('UPDATE ir_cron set interval_number=%s where id=%s' % (self.contract_delay, cron.id))
        cron = self.env.ref('its_hr_contract_extend.reminder_contract_cron')
        # self.env.cr.query('UPDATE ir_cron set interval_number=%s where id=%s' % (self.contract_delay, cron.id))
        cron.interval_number = self.contract_delay
        parameter = self.env['ir.config_parameter'].sudo()
        parameter.set_param('its_hr_contract_extend.contract_renew', self.contract_renew or 30)
        parameter.set_param('its_hr_contract_extend.contract_delay', self.contract_delay or 3)

    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        parameter = self.env['ir.config_parameter'].sudo()
        res.update(
            contract_renew=int(parameter.get_param('its_hr_contract_extend.contract_renew')) or 30,
            contract_delay=int(parameter.get_param('its_hr_contract_extend.contract_delay')) or 3
        )
        return res
