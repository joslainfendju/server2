from odoo import fields, models, api


class HrContractTemplate (models.Model):
    _name = 'hr.contract.template'

    name = fields.Char()
    job_id = fields.Many2one('hr.job', string='Job', required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda s: s.env.user.company_id.id)
    content = fields.Text(help="Use contract or employee to define customization value",
                          default='''
                                              # Available variables:
                                              #----------------------
                                              # employee: hr.employee object
                                              # contract: hr.contract object
                                              # job: hr.job object
                                              # department: hr.department object
                                              # e.g:
                                              # - %(employee.name)s
                                              # - %(department.name)s
                                              # - %(contract.name)s
                                              # - %(job.name)s
                        '''
                          )


