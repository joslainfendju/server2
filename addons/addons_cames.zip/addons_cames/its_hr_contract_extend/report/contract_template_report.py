# -*- coding: utf-8 -*-
from odoo import models, fields, api, exceptions, _
import calendar


class ApplicantByRecruiter(models.AbstractModel):
    _name = 'report.its_hr_contract_extend.report_contract_template'

    @api.model
    def get_report_values(self, docids, data=None):
        docargs = {
            'content': data['content'],
            'doc_ids': data['ids'],
            'doc_model': data['model'],
        }
        return docargs
