This module allows you to manage your employees skills.
