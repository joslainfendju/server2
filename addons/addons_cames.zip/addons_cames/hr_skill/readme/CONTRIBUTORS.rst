* Savoir-faire Linux
* Daniel Reis
* Ivan Yelizariev
* Julien Laloux
* Duc, Dao Dong <duc.dd@komit-consulting.com> (https://komit-consulting.com)
