* Go to Employee > Configuration > Skills
* Create the skills
