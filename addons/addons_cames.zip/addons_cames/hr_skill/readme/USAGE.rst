* Go to Employee
* Create or select an employee
* Go to the Skills tab to enter his skills and levels
